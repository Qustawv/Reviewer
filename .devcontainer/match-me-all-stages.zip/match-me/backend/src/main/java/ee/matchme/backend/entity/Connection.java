package ee.matchme.backend.entity;

import ee.matchme.backend.util.UuidUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

/**
 * Relationship between two users, whatever its state. There is at most one row per pair; the pair
 * is stored in canonical order ({@code userOneId} is the lower id by PostgreSQL's UUID ordering).
 */
@Entity
@Table(name = "connections")
public class Connection {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "user_one_id", nullable = false)
    private UUID userOneId;

    @Column(name = "user_two_id", nullable = false)
    private UUID userTwoId;

    @Column(name = "requester_id", nullable = false)
    private UUID requesterId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ConnectionStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected Connection() {
        // for JPA
    }

    /** New PENDING request from {@code requesterId} to {@code targetId}, stored in canonical pair order. */
    public static Connection request(UUID requesterId, UUID targetId) {
        Connection c = new Connection();
        c.userOneId = UuidUtil.lower(requesterId, targetId);
        c.userTwoId = UuidUtil.higher(requesterId, targetId);
        c.requesterId = requesterId;
        c.status = ConnectionStatus.PENDING;
        c.createdAt = Instant.now();
        c.updatedAt = c.createdAt;
        return c;
    }

    /** The participant that is not {@code me}. */
    public UUID otherUser(UUID me) {
        return me.equals(userOneId) ? userTwoId : userOneId;
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public UUID getUserOneId() {
        return userOneId;
    }

    public UUID getUserTwoId() {
        return userTwoId;
    }

    public UUID getRequesterId() {
        return requesterId;
    }

    public ConnectionStatus getStatus() {
        return status;
    }

    public void setStatus(ConnectionStatus status) {
        this.status = status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
