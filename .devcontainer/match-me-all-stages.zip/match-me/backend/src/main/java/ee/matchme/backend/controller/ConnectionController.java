package ee.matchme.backend.controller;

import ee.matchme.backend.dto.ConnectionResponse;
import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.service.ConnectionService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/**
 * Ids are raw strings in the path: a malformed id must give the same 404 as an unknown one.
 *
 * <pre>
 *   GET    /connections                       ["uuid", ...]   connected users
 *   GET    /connections/requests/incoming     ["uuid", ...]   users who asked me
 *   GET    /connections/requests/outgoing     ["uuid", ...]   users I asked
 *   POST   /connections/requests/{userId}                     send a request (201)
 *   POST   /connections/requests/{userId}/accept              accept their request
 *   POST   /connections/requests/{userId}/reject              reject their request
 *   DELETE /connections/{userId}                              disconnect (204)
 * </pre>
 */
@RestController
@RequestMapping("/connections")
public class ConnectionController {

    private final ConnectionService connectionService;

    public ConnectionController(ConnectionService connectionService) {
        this.connectionService = connectionService;
    }

    /** JSON array of connected user ids only, e.g. {@code ["uuid1", "uuid3"]}. */
    @GetMapping
    public List<UUID> connections(@AuthenticationPrincipal AuthenticatedUser user) {
        return connectionService.connectedUserIds(user.id());
    }

    @GetMapping("/requests/incoming")
    public List<UUID> incoming(@AuthenticationPrincipal AuthenticatedUser user) {
        return connectionService.incomingRequestIds(user.id());
    }

    @GetMapping("/requests/outgoing")
    public List<UUID> outgoing(@AuthenticationPrincipal AuthenticatedUser user) {
        return connectionService.outgoingRequestIds(user.id());
    }

    @PostMapping("/requests/{userId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ConnectionResponse sendRequest(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String userId) {
        return connectionService.sendRequest(user.id(), userId);
    }

    @PostMapping("/requests/{userId}/accept")
    public ConnectionResponse accept(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String userId) {
        return connectionService.accept(user.id(), userId);
    }

    @PostMapping("/requests/{userId}/reject")
    public ConnectionResponse reject(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String userId) {
        return connectionService.reject(user.id(), userId);
    }

    @DeleteMapping("/{userId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void disconnect(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String userId) {
        connectionService.disconnect(user.id(), userId);
    }
}
