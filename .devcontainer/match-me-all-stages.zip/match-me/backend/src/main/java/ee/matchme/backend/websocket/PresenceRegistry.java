package ee.matchme.backend.websocket;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Who is online right now. A user may have several WebSocket sessions (tabs, devices) and counts
 * as online while at least one is open. State is in memory, so with several backend instances
 * presence would need a shared store.
 */
@Component
public class PresenceRegistry {

    private final ConcurrentHashMap<UUID, Set<String>> sessionsByUser = new ConcurrentHashMap<>();

    /** Registers a session; true if this made the user come online (first session). */
    public boolean sessionOpened(UUID userId, String sessionId) {
        AtomicBoolean cameOnline = new AtomicBoolean();
        sessionsByUser.compute(userId, (id, sessions) -> {
            Set<String> set = sessions == null ? ConcurrentHashMap.newKeySet() : sessions;
            cameOnline.set(set.isEmpty());
            set.add(sessionId);
            return set;
        });
        return cameOnline.get();
    }

    /** Removes a session; true if this made the user go offline (last session closed). */
    public boolean sessionClosed(UUID userId, String sessionId) {
        AtomicBoolean wentOffline = new AtomicBoolean();
        sessionsByUser.computeIfPresent(userId, (id, sessions) -> {
            boolean removed = sessions.remove(sessionId);
            if (removed && sessions.isEmpty()) {
                wentOffline.set(true);
                return null;
            }
            return sessions;
        });
        return wentOffline.get();
    }

    public boolean isOnline(UUID userId) {
        return sessionsByUser.containsKey(userId);
    }

    /** The subset of {@code userIds} that is currently online. */
    public List<UUID> onlineAmong(Collection<UUID> userIds) {
        List<UUID> online = new ArrayList<>();
        for (UUID id : userIds) {
            if (isOnline(id)) {
                online.add(id);
            }
        }
        return online;
    }
}
