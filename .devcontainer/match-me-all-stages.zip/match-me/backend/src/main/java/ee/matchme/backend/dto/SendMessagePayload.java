package ee.matchme.backend.dto;

/** STOMP payload of {@code /app/chats/{connectionId}/send}. */
public record SendMessagePayload(String content) {
}
