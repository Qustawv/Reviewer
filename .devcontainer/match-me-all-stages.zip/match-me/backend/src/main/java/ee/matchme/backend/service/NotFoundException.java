package ee.matchme.backend.service;

/**
 * Deliberately message-less. "Does not exist" and "you may not see it" must be indistinguishable
 * to the caller, so both are reported with this exception and render as the same HTTP 404.
 */
public class NotFoundException extends RuntimeException {

    public NotFoundException() {
        super(null, null, false, false);
    }
}
