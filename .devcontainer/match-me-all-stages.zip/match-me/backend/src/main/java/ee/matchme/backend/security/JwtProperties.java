package ee.matchme.backend.security;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties(prefix = "matchme.jwt")
public record JwtProperties(String secret, @DefaultValue("1440") long expirationMinutes) {
}
