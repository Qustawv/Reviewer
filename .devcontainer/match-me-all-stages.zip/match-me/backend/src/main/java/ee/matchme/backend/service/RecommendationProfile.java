package ee.matchme.backend.service;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.Profile;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

/**
 * Immutable snapshot of what the recommendation engine needs to know about one user. Keeping the
 * engine on plain values (no JPA entities, no database) makes it deterministic and unit-testable.
 */
public record RecommendationProfile(
        UUID userId,
        boolean profileComplete,
        Set<PreferredLanguage> preferredLanguages,
        StudyArea studyArea,
        StudyLevel studyLevel,
        WorkStyle workStyle,
        double latitude,
        double longitude,
        int maximumDistanceKm,
        Set<String> skills,
        Set<CollaborationGoal> goals,
        Set<AvailabilitySlot> availability,
        Set<PriorityField> priorityFields,
        Instant updatedAt) {

    public RecommendationProfile {
        preferredLanguages = Set.copyOf(preferredLanguages);
        skills = Set.copyOf(skills);
        goals = Set.copyOf(goals);
        availability = Set.copyOf(availability);
        priorityFields = Set.copyOf(priorityFields);
    }

    /** Snapshot of a (complete) profile entity; must be called inside a transaction (lazy sets). */
    public static RecommendationProfile from(Profile p) {
        return new RecommendationProfile(
                p.getUserId(), p.isProfileComplete(), p.getPreferredLanguages(), p.getStudyArea(),
                p.getStudyLevel(), p.getWorkStyle(), p.getLatitude(), p.getLongitude(),
                p.getMaximumDistanceKm(), p.getSkills(), p.getCollaborationGoals(), p.getAvailability(),
                p.getPriorityFields(), p.getUpdatedAt());
    }
}
