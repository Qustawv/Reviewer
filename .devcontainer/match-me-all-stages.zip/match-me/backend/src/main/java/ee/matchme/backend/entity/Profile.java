package ee.matchme.backend.entity;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.springframework.data.domain.Persistable;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Profile of a user; shares its primary key with {@link User}. Created empty at registration and
 * filled in over time. {@code profileComplete} is derived server-side (see
 * {@code ee.matchme.backend.util.ProfileRules}) and is never taken from client input.
 */
@Entity
@Table(name = "profiles")
public class Profile implements Persistable<UUID> {

    @Id
    @Column(name = "user_id")
    private UUID userId;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "about_me")
    private String aboutMe;

    @Enumerated(EnumType.STRING)
    @Column(name = "study_area")
    private StudyArea studyArea;

    @Enumerated(EnumType.STRING)
    @Column(name = "study_level")
    private StudyLevel studyLevel;

    @Enumerated(EnumType.STRING)
    @Column(name = "work_style")
    private WorkStyle workStyle;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "maximum_distance_km")
    private Integer maximumDistanceKm;

    @Column(name = "city")
    private String city;

    @Column(name = "profile_image_url")
    private String profileImageUrl;

    @Column(name = "profile_complete", nullable = false)
    private boolean profileComplete;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @ElementCollection
    @CollectionTable(name = "profile_skills", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "skill_code", nullable = false)
    private Set<String> skills = new HashSet<>();

    @ElementCollection
    @CollectionTable(name = "profile_languages", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "language_code", nullable = false)
    @Enumerated(EnumType.STRING)
    private Set<PreferredLanguage> preferredLanguages = new HashSet<>();

    @ElementCollection
    @CollectionTable(name = "profile_collaboration_goals", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "goal_code", nullable = false)
    @Enumerated(EnumType.STRING)
    private Set<CollaborationGoal> collaborationGoals = new HashSet<>();

    @ElementCollection
    @CollectionTable(name = "profile_availability", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "slot_code", nullable = false)
    @Enumerated(EnumType.STRING)
    private Set<AvailabilitySlot> availability = new HashSet<>();

    @ElementCollection
    @CollectionTable(name = "profile_priority_fields", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "field_code", nullable = false)
    @Enumerated(EnumType.STRING)
    private Set<PriorityField> priorityFields = new HashSet<>();

    /** Lets Spring Data call persist() (not merge()) for a brand-new row whose id we assign ourselves. */
    @Transient
    private boolean newEntity = true;

    protected Profile() {
        // for JPA
    }

    public Profile(UUID userId) {
        this.userId = userId;
        this.updatedAt = Instant.now();
    }

    @Override
    public UUID getId() {
        return userId;
    }

    @Override
    public boolean isNew() {
        return newEntity;
    }

    @PostLoad
    @PostPersist
    void markNotNew() {
        this.newEntity = false;
    }

    public UUID getUserId() {
        return userId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public StudyArea getStudyArea() {
        return studyArea;
    }

    public void setStudyArea(StudyArea studyArea) {
        this.studyArea = studyArea;
    }

    public StudyLevel getStudyLevel() {
        return studyLevel;
    }

    public void setStudyLevel(StudyLevel studyLevel) {
        this.studyLevel = studyLevel;
    }

    public WorkStyle getWorkStyle() {
        return workStyle;
    }

    public void setWorkStyle(WorkStyle workStyle) {
        this.workStyle = workStyle;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Integer getMaximumDistanceKm() {
        return maximumDistanceKm;
    }

    public void setMaximumDistanceKm(Integer maximumDistanceKm) {
        this.maximumDistanceKm = maximumDistanceKm;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public boolean isProfileComplete() {
        return profileComplete;
    }

    public void setProfileComplete(boolean profileComplete) {
        this.profileComplete = profileComplete;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void touch() {
        this.updatedAt = Instant.now();
    }

    public Set<String> getSkills() {
        return skills;
    }

    public Set<PreferredLanguage> getPreferredLanguages() {
        return preferredLanguages;
    }

    public Set<CollaborationGoal> getCollaborationGoals() {
        return collaborationGoals;
    }

    public Set<AvailabilitySlot> getAvailability() {
        return availability;
    }

    public Set<PriorityField> getPriorityFields() {
        return priorityFields;
    }
}
