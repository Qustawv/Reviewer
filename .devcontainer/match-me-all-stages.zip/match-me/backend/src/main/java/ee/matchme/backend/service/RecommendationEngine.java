package ee.matchme.backend.service;

import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;
import ee.matchme.backend.util.GeoUtil;
import ee.matchme.backend.util.UuidUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The matching algorithm: hard filters, weighted scoring, cutoff, ranking and the final
 * "top 3 pinned, ranks 4-20 shuffled" arrangement. Pure functions over {@link RecommendationProfile}
 * snapshots; no database, no Spring.
 *
 * <h3>Score (max 100, then capped at 100 after the bonus)</h3>
 * <pre>
 *   shared goals          30 * shared / my goals
 *   overlapping slots     25 * shared / my slots
 *   shared skills         20 * shared / my skills
 *   study area            10 equal | 6 related (SOFTWARE_DEVELOPMENT + WEB_DEVELOPMENT) | 0
 *   study level            5 equal | 3 adjacent | 0
 *   work style             5 equal | 3 compatible | 0
 *   proximity              5 within 25% of the radius | 3 within 50% | 1 otherwise
 *   priority bonus        +5 per matching priority field of mine (max 2 fields)
 * </pre>
 * The radius is the smaller of the two users' maximum distances.
 *
 * <h3>Interpretations the spec leaves open</h3>
 * <ul>
 *   <li><b>Compatible work styles:</b> FLEXIBLE with any other style, and STRUCTURED with
 *       INDEPENDENT_WITH_CHECK_INS (both plan-driven).</li>
 *   <li><b>A priority field "matches"</b> when the candidate earns at least half of that
 *       dimension's points (equal, related, adjacent and compatible all qualify; for the set-based
 *       fields at least half of my entries must be shared).</li>
 * </ul>
 */
public final class RecommendationEngine {

    public static final double MIN_SCORE = 60.0;
    public static final int PINNED = 3;
    public static final int POOL_SIZE = 20;
    public static final int MAX_RESULTS = 10;
    public static final double PRIORITY_BONUS_PER_FIELD = 5.0;
    public static final double MAX_SCORE = 100.0;

    private RecommendationEngine() {
    }

    /** A candidate that passed every hard filter, with its final score. */
    public record Scored(RecommendationProfile candidate, double score, double distanceKm) {
        public UUID userId() {
            return candidate.userId();
        }
    }

    // ---- hard filters --------------------------------------------------------------------

    /**
     * Hard filters. {@code excluded} holds ids that must never be recommended (dismissals and any
     * existing relationship row: PENDING, ACCEPTED, REJECTED, DISCONNECTED).
     */
    public static boolean isEligible(RecommendationProfile me, RecommendationProfile c, Set<UUID> excluded) {
        return c.profileComplete()
                && !c.userId().equals(me.userId())
                && !excluded.contains(c.userId())
                && sharedCount(me.preferredLanguages(), c.preferredLanguages()) > 0
                && sharedCount(me.goals(), c.goals()) > 0
                && sharedCount(me.availability(), c.availability()) > 0
                && distanceKm(me, c) <= radiusKm(me, c);
    }

    public static double distanceKm(RecommendationProfile a, RecommendationProfile b) {
        return GeoUtil.haversineKm(a.latitude(), a.longitude(), b.latitude(), b.longitude());
    }

    /** The smaller of both users' maximum distances. */
    public static int radiusKm(RecommendationProfile a, RecommendationProfile b) {
        return Math.min(a.maximumDistanceKm(), b.maximumDistanceKm());
    }

    // ---- scoring -------------------------------------------------------------------------

    /** Final score (base + priority bonus, capped at 100) rounded to 6 decimals. Assumes {@link #isEligible}. */
    public static double score(RecommendationProfile me, RecommendationProfile c) {
        double goals = 30.0 * sharedCount(me.goals(), c.goals()) / me.goals().size();
        double slots = 25.0 * sharedCount(me.availability(), c.availability()) / me.availability().size();
        double skills = me.skills().isEmpty() ? 0.0 : 20.0 * sharedCount(me.skills(), c.skills()) / me.skills().size();
        double area = studyAreaPoints(me.studyArea(), c.studyArea());
        double level = studyLevelPoints(me.studyLevel(), c.studyLevel());
        double style = workStylePoints(me.workStyle(), c.workStyle());
        double proximity = proximityPoints(distanceKm(me, c), radiusKm(me, c));

        double base = goals + slots + skills + area + level + style + proximity;

        int matches = 0;
        for (PriorityField field : me.priorityFields()) {
            boolean matched = switch (field) {
                case SKILLS -> skills * 2 >= 20.0 && !me.skills().isEmpty();
                case COLLABORATION_GOALS -> goals * 2 >= 30.0;
                case AVAILABILITY -> slots * 2 >= 25.0;
                case STUDY_AREA -> area * 2 >= 10.0;
                case WORK_STYLE -> style * 2 >= 5.0;
                case STUDY_LEVEL -> level * 2 >= 5.0;
            };
            if (matched) {
                matches++;
            }
        }
        double total = Math.min(MAX_SCORE, base + PRIORITY_BONUS_PER_FIELD * Math.min(matches, 2));
        return round6(total);
    }

    static double studyAreaPoints(StudyArea a, StudyArea b) {
        if (a == b) {
            return 10.0;
        }
        boolean softwareAndWeb = (a == StudyArea.SOFTWARE_DEVELOPMENT && b == StudyArea.WEB_DEVELOPMENT)
                || (a == StudyArea.WEB_DEVELOPMENT && b == StudyArea.SOFTWARE_DEVELOPMENT);
        return softwareAndWeb ? 6.0 : 0.0;
    }

    static double studyLevelPoints(StudyLevel a, StudyLevel b) {
        if (a == b) {
            return 5.0;
        }
        return Math.abs(a.ordinal() - b.ordinal()) == 1 ? 3.0 : 0.0;
    }

    static double workStylePoints(WorkStyle a, WorkStyle b) {
        if (a == b) {
            return 5.0;
        }
        boolean flexible = a == WorkStyle.FLEXIBLE || b == WorkStyle.FLEXIBLE;
        boolean planDriven = (a == WorkStyle.STRUCTURED && b == WorkStyle.INDEPENDENT_WITH_CHECK_INS)
                || (a == WorkStyle.INDEPENDENT_WITH_CHECK_INS && b == WorkStyle.STRUCTURED);
        return flexible || planDriven ? 3.0 : 0.0;
    }

    static double proximityPoints(double distanceKm, int radiusKm) {
        double ratio = distanceKm / radiusKm;
        if (ratio <= 0.25) {
            return 5.0;
        }
        return ratio <= 0.50 ? 3.0 : 1.0;
    }

    private static <T> int sharedCount(Set<T> a, Set<T> b) {
        int n = 0;
        for (T t : a) {
            if (b.contains(t)) {
                n++;
            }
        }
        return n;
    }

    private static double round6(double v) {
        return Math.round(v * 1_000_000d) / 1_000_000d;
    }

    // ---- ranking and arrangement ---------------------------------------------------------

    /** Score → shorter distance → most recently updated profile → id (for a stable total order). */
    static final Comparator<Scored> RANKING = Comparator
            .comparingDouble(Scored::score).reversed()
            .thenComparingDouble(Scored::distanceKm)
            .thenComparing((Scored s) -> s.candidate().updatedAt(), Comparator.reverseOrder())
            .thenComparing(Scored::userId, UuidUtil::compareUnsigned);

    /** Eligible candidates scoring at least {@value #MIN_SCORE}, best first, at most {@value #POOL_SIZE}. */
    public static List<Scored> rank(RecommendationProfile me, List<RecommendationProfile> candidates,
                                    Set<UUID> excluded) {
        List<Scored> scored = new ArrayList<>();
        for (RecommendationProfile c : candidates) {
            if (!isEligible(me, c, excluded)) {
                continue;
            }
            double s = score(me, c);
            if (s >= MIN_SCORE) {
                scored.add(new Scored(c, s, distanceKm(me, c)));
            }
        }
        scored.sort(RANKING);
        return scored.size() > POOL_SIZE ? new ArrayList<>(scored.subList(0, POOL_SIZE)) : scored;
    }

    /**
     * Ranks 1-3 stay fixed; the remaining slots (up to {@value #MAX_RESULTS} in total) are filled by
     * a random draw, in random order, from ranks 4-20.
     */
    public static List<UUID> arrange(List<Scored> ranked, Random random) {
        List<Scored> pool = ranked.size() > POOL_SIZE ? ranked.subList(0, POOL_SIZE) : ranked;
        List<UUID> result = new ArrayList<>();
        int pinned = Math.min(PINNED, pool.size());
        for (int i = 0; i < pinned; i++) {
            result.add(pool.get(i).userId());
        }
        List<Scored> rest = new ArrayList<>(pool.subList(pinned, pool.size()));
        Collections.shuffle(rest, random);
        for (int i = 0; i < rest.size() && result.size() < MAX_RESULTS; i++) {
            result.add(rest.get(i).userId());
        }
        return result;
    }

    public static List<UUID> recommend(RecommendationProfile me, List<RecommendationProfile> candidates,
                                       Set<UUID> excluded, Random random) {
        return arrange(rank(me, candidates, excluded), random);
    }

    /** Convenience for callers that want to inspect a single pair. */
    public static Optional<Scored> evaluate(RecommendationProfile me, RecommendationProfile c, Set<UUID> excluded) {
        if (!isEligible(me, c, excluded)) {
            return Optional.empty();
        }
        double s = score(me, c);
        return s >= MIN_SCORE ? Optional.of(new Scored(c, s, distanceKm(me, c))) : Optional.empty();
    }
}
