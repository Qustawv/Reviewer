package ee.matchme.backend.security;

import java.security.Principal;
import java.util.UUID;

/** The authenticated principal: just the user id taken from the verified JWT. */
public record AuthenticatedUser(UUID id) implements Principal {

    @Override
    public String getName() {
        return id.toString();
    }
}
