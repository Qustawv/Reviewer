package ee.matchme.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.UUID;

/** The conversation of one connection (1-to-1); created when the request is accepted. */
@Entity
@Table(name = "chats")
public class Chat {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "connection_id", nullable = false, unique = true)
    private UUID connectionId;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected Chat() {
        // for JPA
    }

    public Chat(UUID connectionId) {
        this.connectionId = connectionId;
        this.createdAt = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public UUID getConnectionId() {
        return connectionId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
