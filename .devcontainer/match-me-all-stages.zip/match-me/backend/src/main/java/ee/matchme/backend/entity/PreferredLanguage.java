package ee.matchme.backend.entity;

public enum PreferredLanguage {
    ENGLISH,
    ESTONIAN,
    RUSSIAN,
    OTHER
}
