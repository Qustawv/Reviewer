package ee.matchme.backend.entity;

public enum WorkStyle {
    STRUCTURED,
    FLEXIBLE,
    PAIR_PROGRAMMING,
    INDEPENDENT_WITH_CHECK_INS
}
