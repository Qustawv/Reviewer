package ee.matchme.backend.websocket;

import ee.matchme.backend.service.ConnectionService;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.security.Principal;
import java.util.UUID;

/** Turns WebSocket session lifecycle into online/offline events for the user's connections. */
@Component
public class PresenceEventListener {

    private final PresenceRegistry registry;
    private final ConnectionService connectionService;
    private final RealtimeNotifier notifier;

    public PresenceEventListener(PresenceRegistry registry, ConnectionService connectionService,
                                 RealtimeNotifier notifier) {
        this.registry = registry;
        this.connectionService = connectionService;
        this.notifier = notifier;
    }

    @EventListener
    public void onConnected(SessionConnectedEvent event) {
        UUID userId = userId(event.getUser());
        if (userId == null) {
            return;
        }
        String sessionId = StompHeaderAccessor.wrap(event.getMessage()).getSessionId();
        if (registry.sessionOpened(userId, sessionId)) {
            announce(userId, true);
        }
    }

    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        UUID userId = userId(event.getUser());
        if (userId == null) {
            return;
        }
        if (registry.sessionClosed(userId, event.getSessionId())) {
            announce(userId, false);
        }
    }

    private void announce(UUID userId, boolean online) {
        for (UUID connected : connectionService.connectedUserIds(userId)) {
            notifier.toUser(connected, "presence", RealtimeEvents.Presence.update(userId, online));
        }
    }

    static UUID userId(Principal principal) {
        if (principal == null) {
            return null;
        }
        try {
            return UUID.fromString(principal.getName());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
