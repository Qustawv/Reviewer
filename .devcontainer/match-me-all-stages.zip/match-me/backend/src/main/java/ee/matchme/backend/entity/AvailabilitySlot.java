package ee.matchme.backend.entity;

public enum AvailabilitySlot {
    WEEKDAY_MORNING,
    WEEKDAY_AFTERNOON,
    WEEKDAY_EVENING,
    WEEKEND_MORNING,
    WEEKEND_AFTERNOON,
    WEEKEND_EVENING
}
