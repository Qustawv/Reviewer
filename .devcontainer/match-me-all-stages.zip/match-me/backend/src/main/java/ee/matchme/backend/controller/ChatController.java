package ee.matchme.backend.controller;

import ee.matchme.backend.dto.ChatSummary;
import ee.matchme.backend.dto.MessagePage;
import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.service.ChatService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Chat history over REST. Sending, typing, presence and unread counters are STOMP only (no polling). */
@RestController
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    /** My chats (one per accepted connection) with unread counts and the last message. */
    @GetMapping("/chats")
    public List<ChatSummary> chats(@AuthenticationPrincipal AuthenticatedUser user) {
        return chatService.chatsOf(user.id());
    }

    /** Paginated history: page 0 = newest {@code size} messages, each page oldest-first. */
    @GetMapping("/chats/{connectionId}/messages")
    public MessagePage messages(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String connectionId,
                                @RequestParam(defaultValue = "0") int page,
                                @RequestParam(defaultValue = "50") int size) {
        return chatService.history(user.id(), connectionId, page, size);
    }
}
