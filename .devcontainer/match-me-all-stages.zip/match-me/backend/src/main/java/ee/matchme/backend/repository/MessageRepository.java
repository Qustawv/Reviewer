package ee.matchme.backend.repository;

import ee.matchme.backend.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.UUID;

public interface MessageRepository extends JpaRepository<Message, UUID> {

    Page<Message> findByChatId(UUID chatId, Pageable pageable);

    /** Messages in the chat that {@code recipientId} has not read yet (i.e. sent by the other side). */
    long countByChatIdAndSenderIdNotAndReadAtIsNull(UUID chatId, UUID recipientId);

    /** Marks everything the other side sent as read; returns how many messages changed. */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Message m set m.readAt = :now "
            + "where m.chatId = :chatId and m.senderId <> :readerId and m.readAt is null")
    int markRead(@Param("chatId") UUID chatId, @Param("readerId") UUID readerId, @Param("now") Instant now);
}
