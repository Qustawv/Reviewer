package ee.matchme.backend.service;

import ee.matchme.backend.dto.BioResponse;
import ee.matchme.backend.dto.MeResponse;
import ee.matchme.backend.dto.ProfileResponse;
import ee.matchme.backend.dto.ProfileUpdateRequest;
import ee.matchme.backend.dto.PublicUserResponse;
import ee.matchme.backend.dto.SettingsResponse;
import ee.matchme.backend.entity.Profile;
import ee.matchme.backend.entity.Skill;
import ee.matchme.backend.entity.User;
import ee.matchme.backend.repository.ProfileRepository;
import ee.matchme.backend.repository.SkillRepository;
import ee.matchme.backend.repository.UserRepository;
import ee.matchme.backend.util.ProfileRules;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Reads and writes profiles and maps them to the exact public/private payload shapes. This class
 * performs NO authorisation: callers must have established that the viewer may see the target
 * (see {@link UserAccessService}).
 */
@Service
public class ProfileService {

    private static final Pattern HTTP_URL = Pattern.compile("^https?://\\S+$");

    private final ProfileRepository profileRepository;
    private final UserRepository userRepository;
    private final SkillRepository skillRepository;
    private final RecommendationService recommendationService;

    public ProfileService(ProfileRepository profileRepository, UserRepository userRepository,
                          SkillRepository skillRepository, RecommendationService recommendationService) {
        this.profileRepository = profileRepository;
        this.userRepository = userRepository;
        this.skillRepository = skillRepository;
        this.recommendationService = recommendationService;
    }

    // ---- reads ---------------------------------------------------------------------------

    @Transactional(readOnly = true)
    public MeResponse me(UUID userId) {
        User user = userRepository.findById(userId).orElseThrow(NotFoundException::new);
        Profile p = load(userId);
        return new MeResponse(userId, user.getEmail(), p.getDisplayName(), p.getProfileImageUrl());
    }

    @Transactional(readOnly = true)
    public PublicUserResponse publicUser(UUID userId) {
        Profile p = load(userId);
        return new PublicUserResponse(userId, p.getDisplayName(), p.getProfileImageUrl());
    }

    @Transactional(readOnly = true)
    public ProfileResponse profile(UUID userId) {
        return new ProfileResponse(userId, load(userId).getAboutMe());
    }

    @Transactional(readOnly = true)
    public BioResponse bio(UUID userId) {
        return toBio(load(userId));
    }

    @Transactional(readOnly = true)
    public SettingsResponse settings(UUID userId) {
        return toSettings(load(userId));
    }

    // ---- write ---------------------------------------------------------------------------

    @Transactional
    public SettingsResponse update(UUID userId, ProfileUpdateRequest req) {
        validate(req);
        Profile p = load(userId);

        p.setDisplayName(req.displayName());
        p.setAboutMe(req.aboutMe());
        p.setStudyArea(req.studyArea());
        p.setStudyLevel(req.studyLevel());
        p.setWorkStyle(req.workStyle());
        p.setLatitude(req.latitude());
        p.setLongitude(req.longitude());
        p.setMaximumDistanceKm(req.maximumDistanceKm());
        p.setCity(req.city());
        p.setProfileImageUrl(req.profileImageUrl());
        replace(p.getSkills(), req.skills());
        replace(p.getPreferredLanguages(), req.preferredLanguages());
        replace(p.getCollaborationGoals(), req.collaborationGoals());
        replace(p.getAvailability(), req.availability());
        replace(p.getPriorityFields(), req.priorityFields());

        // The gate is always recomputed here; clients can never set it.
        p.setProfileComplete(ProfileRules.isComplete(p));
        p.touch();
        SettingsResponse saved = toSettings(profileRepository.save(p));
        // The candidate pool and my filters depend on the profile: what was served is now stale.
        recommendationService.invalidate(userId);
        return saved;
    }

    // ---- helpers -------------------------------------------------------------------------

    private Profile load(UUID userId) {
        return profileRepository.findById(userId).orElseThrow(NotFoundException::new);
    }

    private static <T> void replace(Set<T> target, Set<T> source) {
        target.clear();
        if (source != null) {
            target.addAll(source);
        }
    }

    private void validate(ProfileUpdateRequest r) {
        Map<String, String> errors = new LinkedHashMap<>();

        if (r.displayName() != null && !ProfileRules.lengthBetween(
                r.displayName(), ProfileRules.DISPLAY_NAME_MIN, ProfileRules.DISPLAY_NAME_MAX)) {
            errors.put("displayName", "must be between " + ProfileRules.DISPLAY_NAME_MIN + " and "
                    + ProfileRules.DISPLAY_NAME_MAX + " characters");
        }
        if (r.aboutMe() != null && !ProfileRules.lengthBetween(
                r.aboutMe(), ProfileRules.ABOUT_ME_MIN, ProfileRules.ABOUT_ME_MAX)) {
            errors.put("aboutMe", "must be between " + ProfileRules.ABOUT_ME_MIN + " and "
                    + ProfileRules.ABOUT_ME_MAX + " characters");
        }
        if (r.city() != null && ProfileRules.length(r.city()) > ProfileRules.CITY_MAX) {
            errors.put("city", "must be at most " + ProfileRules.CITY_MAX + " characters");
        }
        if (r.profileImageUrl() != null && (ProfileRules.length(r.profileImageUrl()) > ProfileRules.IMAGE_URL_MAX
                || !HTTP_URL.matcher(r.profileImageUrl()).matches())) {
            errors.put("profileImageUrl", "must be an http(s) URL of at most "
                    + ProfileRules.IMAGE_URL_MAX + " characters");
        }

        checkSet(errors, "skills", r.skills(), ProfileRules.SKILLS_MAX);
        checkSet(errors, "collaborationGoals", r.collaborationGoals(), ProfileRules.GOALS_MAX);
        checkSet(errors, "preferredLanguages", r.preferredLanguages(), ProfileRules.LANGUAGES_MAX);
        checkSet(errors, "availability", r.availability(), ProfileRules.AVAILABILITY_MAX);
        checkSet(errors, "priorityFields", r.priorityFields(), ProfileRules.PRIORITY_FIELDS_MAX);

        if (!errors.containsKey("skills") && r.skills() != null && !r.skills().isEmpty()) {
            Set<String> known = skillRepository.findAllById(r.skills()).stream()
                    .map(Skill::getCode).collect(Collectors.toSet());
            Set<String> unknown = new TreeSet<>(r.skills());
            unknown.removeAll(known);
            if (!unknown.isEmpty()) {
                errors.put("skills", "unknown skills: " + String.join(", ", unknown));
            }
        }

        if (r.latitude() != null && !ProfileRules.validLatitude(r.latitude())) {
            errors.put("latitude", "must be between -90 and 90");
        }
        if (r.longitude() != null && !ProfileRules.validLongitude(r.longitude())) {
            errors.put("longitude", "must be between -180 and 180");
        }
        if (r.maximumDistanceKm() != null
                && !ProfileRules.ALLOWED_DISTANCES_KM.contains(r.maximumDistanceKm())) {
            errors.put("maximumDistanceKm", "must be one of 5, 10, 25, 50, 100");
        }

        if (!errors.isEmpty()) {
            throw new ValidationFailedException(errors);
        }
    }

    private static void checkSet(Map<String, String> errors, String field, Collection<?> values, int max) {
        if (values == null) {
            return;
        }
        if (values.stream().anyMatch(Objects::isNull)) {
            errors.put(field, "must not contain null entries");
        } else if (values.size() > max) {
            errors.put(field, "must contain at most " + max + " entries");
        }
    }

    private static BioResponse toBio(Profile p) {
        return new BioResponse(
                p.getUserId(),
                p.getStudyArea(),
                p.getStudyLevel(),
                p.getSkills().stream().sorted().toList(),
                p.getCollaborationGoals().stream().sorted().toList(),
                p.getAvailability().stream().sorted().toList(),
                p.getWorkStyle(),
                p.getPreferredLanguages().stream().sorted().toList(),
                p.getCity());
    }

    private static SettingsResponse toSettings(Profile p) {
        return new SettingsResponse(
                p.isProfileComplete(),
                p.getLatitude(),
                p.getLongitude(),
                p.getMaximumDistanceKm(),
                p.getPriorityFields().stream().sorted().toList());
    }
}
