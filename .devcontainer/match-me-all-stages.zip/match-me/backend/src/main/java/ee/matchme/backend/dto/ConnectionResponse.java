package ee.matchme.backend.dto;

import ee.matchme.backend.entity.ConnectionStatus;

import java.util.UUID;

/** Result of a connection action; {@code userId} is the other party. */
public record ConnectionResponse(UUID connectionId, UUID userId, ConnectionStatus status) {
}
