package ee.matchme.backend.service;

import ee.matchme.backend.dto.LookupsResponse;
import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;
import ee.matchme.backend.repository.SkillRepository;
import ee.matchme.backend.util.ProfileRules;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LookupService {

    private final SkillRepository skillRepository;

    public LookupService(SkillRepository skillRepository) {
        this.skillRepository = skillRepository;
    }

    @Transactional(readOnly = true)
    public LookupsResponse lookups() {
        return new LookupsResponse(
                skillRepository.findAllByOrderByLabelAsc().stream()
                        .map(s -> new LookupsResponse.SkillOption(s.getCode(), s.getLabel()))
                        .toList(),
                List.of(CollaborationGoal.values()),
                List.of(AvailabilitySlot.values()),
                List.of(StudyArea.values()),
                List.of(StudyLevel.values()),
                List.of(WorkStyle.values()),
                List.of(PreferredLanguage.values()),
                List.of(PriorityField.values()),
                ProfileRules.ALLOWED_DISTANCES_KM.stream().sorted().toList());
    }
}
