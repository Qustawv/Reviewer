package ee.matchme.backend.entity;

public enum StudyArea {
    SOFTWARE_DEVELOPMENT,
    WEB_DEVELOPMENT,
    DATA_SCIENCE,
    CYBER_SECURITY,
    MOBILE_DEVELOPMENT,
    DESIGN,
    OTHER
}
