package ee.matchme.backend.websocket;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.UUID;

/**
 * Payloads pushed to clients on their private {@code /user/queue/*} destinations.
 *
 * <pre>
 *   /user/queue/messages     MessageDto             a new message (also echoed to the sender's other tabs)
 *   /user/queue/typing       Typing                 the other person started/stopped typing
 *   /user/queue/presence     Presence               a connection went online/offline
 *   /user/queue/unread       Unread                 unread counters changed
 *   /user/queue/read         Read                   the other person read my messages
 *   /user/queue/connections  ConnectionEvent        request received / accepted / disconnected
 *   /user/queue/errors       ErrorEvent             a frame I sent was rejected
 *   /app/presence/snapshot   Presence (SNAPSHOT)    reply to subscribing: who is online right now
 * </pre>
 */
public final class RealtimeEvents {

    private RealtimeEvents() {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Presence(String type, UUID userId, Boolean online, List<UUID> onlineUserIds) {

        public static Presence snapshot(List<UUID> onlineUserIds) {
            return new Presence("SNAPSHOT", null, null, onlineUserIds);
        }

        public static Presence update(UUID userId, boolean online) {
            return new Presence("UPDATE", userId, online, null);
        }
    }

    public record Typing(UUID connectionId, UUID userId, boolean typing) {
    }

    public record Unread(UUID connectionId, long unreadCount, long totalUnread) {
    }

    public record Read(UUID connectionId, UUID readerId) {
    }

    public record ConnectionEvent(String type, UUID userId, UUID connectionId) {

        public static final String REQUEST_RECEIVED = "REQUEST_RECEIVED";
        public static final String REQUEST_ACCEPTED = "REQUEST_ACCEPTED";
        public static final String DISCONNECTED = "DISCONNECTED";
    }

    public record ErrorEvent(String code) {
    }
}
