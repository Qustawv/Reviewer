package ee.matchme.backend.repository;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;
import ee.matchme.backend.service.RecommendationProfile;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

/**
 * Loads the candidate pool for one user in five queries (no N+1): the profile rows, then the language, goal,
 * availability and skill sets of those rows.
 *
 * <p>The first query already applies the cheap hard filters in SQL so the pool stays small: complete
 * profile, at least one shared preferred language, not the user, not dismissed by the user, no existing
 * relationship row in either direction (PENDING / ACCEPTED / REJECTED / DISCONNECTED), and at least
 * one shared goal and one overlapping availability slot. The distance filter, the score and
 * everything after it are done by {@code RecommendationEngine}, which re-checks all hard filters.
 */
@Repository
public class RecommendationCandidateRepository {

    static final String CANDIDATES_SQL = """
            SELECT p.user_id, p.study_area, p.study_level, p.work_style,
                   p.latitude, p.longitude, p.maximum_distance_km, p.updated_at
            FROM profiles p
            WHERE p.profile_complete
              AND p.user_id <> :me
              AND NOT EXISTS (SELECT 1 FROM recommendation_dismissals d
                               WHERE d.user_id = :me AND d.dismissed_user_id = p.user_id)
              AND NOT EXISTS (SELECT 1 FROM connections c
                               WHERE (c.user_one_id = :me AND c.user_two_id = p.user_id)
                                  OR (c.user_two_id = :me AND c.user_one_id = p.user_id))
              AND EXISTS (SELECT 1 FROM profile_languages l1
                            JOIN profile_languages l2 ON l2.language_code = l1.language_code
                           WHERE l1.user_id = :me AND l2.user_id = p.user_id)
              AND EXISTS (SELECT 1 FROM profile_collaboration_goals g1
                            JOIN profile_collaboration_goals g2 ON g2.goal_code = g1.goal_code
                           WHERE g1.user_id = :me AND g2.user_id = p.user_id)
              AND EXISTS (SELECT 1 FROM profile_availability a1
                            JOIN profile_availability a2 ON a2.slot_code = a1.slot_code
                           WHERE a1.user_id = :me AND a2.user_id = p.user_id)
            """;

    static final String LANGUAGES_SQL =
            "SELECT user_id, language_code AS code FROM profile_languages WHERE user_id IN (:ids)";
    static final String GOALS_SQL =
            "SELECT user_id, goal_code AS code FROM profile_collaboration_goals WHERE user_id IN (:ids)";
    static final String SLOTS_SQL =
            "SELECT user_id, slot_code AS code FROM profile_availability WHERE user_id IN (:ids)";
    static final String SKILLS_SQL =
            "SELECT user_id, skill_code AS code FROM profile_skills WHERE user_id IN (:ids)";

    private record Row(UUID userId, StudyArea area, StudyLevel level,
                       WorkStyle style, double latitude, double longitude, int maximumDistanceKm,
                       java.time.Instant updatedAt) {
    }

    private final NamedParameterJdbcTemplate jdbc;

    public RecommendationCandidateRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<RecommendationProfile> findCandidates(RecommendationProfile me) {
        List<Row> rows = jdbc.query(CANDIDATES_SQL,
                Map.of("me", me.userId()),
                (rs, i) -> new Row(
                        rs.getObject("user_id", UUID.class),
                        StudyArea.valueOf(rs.getString("study_area")),
                        StudyLevel.valueOf(rs.getString("study_level")),
                        WorkStyle.valueOf(rs.getString("work_style")),
                        rs.getDouble("latitude"),
                        rs.getDouble("longitude"),
                        rs.getInt("maximum_distance_km"),
                        rs.getObject("updated_at", OffsetDateTime.class).toInstant()));
        if (rows.isEmpty()) {
            return List.of();
        }

        List<UUID> ids = rows.stream().map(Row::userId).toList();
        Map<UUID, Set<PreferredLanguage>> languages = loadSets(LANGUAGES_SQL, ids, PreferredLanguage::valueOf);
        Map<UUID, Set<CollaborationGoal>> goals = loadSets(GOALS_SQL, ids, CollaborationGoal::valueOf);
        Map<UUID, Set<AvailabilitySlot>> slots = loadSets(SLOTS_SQL, ids, AvailabilitySlot::valueOf);
        Map<UUID, Set<String>> skills = loadSets(SKILLS_SQL, ids, Function.identity());

        return rows.stream().map(r -> new RecommendationProfile(
                r.userId(), true, languages.getOrDefault(r.userId(), Set.of()), r.area(), r.level(), r.style(),
                r.latitude(), r.longitude(), r.maximumDistanceKm(),
                skills.getOrDefault(r.userId(), Set.of()),
                goals.getOrDefault(r.userId(), Set.of()),
                slots.getOrDefault(r.userId(), Set.of()),
                Set.of(), // a candidate's own priority fields never influence MY score
                r.updatedAt())).toList();
    }

    private <T> Map<UUID, Set<T>> loadSets(String sql, List<UUID> ids, Function<String, T> parse) {
        Map<UUID, Set<T>> result = new HashMap<>();
        jdbc.query(sql, Collections.singletonMap("ids", ids), rs -> {
            result.computeIfAbsent(rs.getObject("user_id", UUID.class), k -> new HashSet<>())
                    .add(parse.apply(rs.getString("code")));
        });
        return result;
    }
}
