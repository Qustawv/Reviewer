package ee.matchme.backend.controller;

import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.service.RecommendationService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
public class RecommendationController {

    private final RecommendationService recommendationService;

    public RecommendationController(RecommendationService recommendationService) {
        this.recommendationService = recommendationService;
    }

    /** JSON array of at most 10 user id strings only, e.g. {@code ["uuid1", "uuid2"]}. 403 while the profile is incomplete. */
    @GetMapping("/recommendations")
    public List<UUID> recommendations(@AuthenticationPrincipal AuthenticatedUser user) {
        return recommendationService.recommendationsFor(user.id());
    }

    /** "Not interested": the user is never recommended again. Only currently recommended users can be dismissed. */
    @PostMapping("/recommendations/{userId}/dismiss")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void dismiss(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable String userId) {
        recommendationService.dismiss(user.id(), userId);
    }
}
