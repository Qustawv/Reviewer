package ee.matchme.backend.util;

import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * UUID helpers.
 *
 * <p>PostgreSQL orders {@code uuid} values as <em>unsigned</em> bytes, whereas
 * {@link UUID#compareTo(UUID)} compares the two halves as <em>signed</em> longs. The two disagree for
 * any UUID whose first bit is set (e.g. {@code 0000…0001} vs {@code 8000…0002}). The
 * {@code connections_ordered_pair} CHECK constraint relies on PostgreSQL's order, so pairs must be
 * ordered with {@link #compareUnsigned(UUID, UUID)}, never with {@code compareTo}.
 */
public final class UuidUtil {

    private static final Pattern CANONICAL =
            Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    private UuidUtil() {
    }

    /** Compares like PostgreSQL's {@code uuid} operators (unsigned, most significant bits first). */
    public static int compareUnsigned(UUID a, UUID b) {
        int msb = Long.compareUnsigned(a.getMostSignificantBits(), b.getMostSignificantBits());
        if (msb != 0) {
            return msb;
        }
        return Long.compareUnsigned(a.getLeastSignificantBits(), b.getLeastSignificantBits());
    }

    /** The "lower" id of a pair, i.e. the one stored as {@code user_one_id}. */
    public static UUID lower(UUID a, UUID b) {
        return compareUnsigned(a, b) <= 0 ? a : b;
    }

    /** The "higher" id of a pair, i.e. the one stored as {@code user_two_id}. */
    public static UUID higher(UUID a, UUID b) {
        return compareUnsigned(a, b) <= 0 ? b : a;
    }

    /**
     * Strict parse of a canonical 8-4-4-4-12 UUID string. {@link UUID#fromString(String)} alone is too
     * lenient (it accepts things like {@code "1-1-1-1-1"}), which would let odd path variables through.
     */
    public static Optional<UUID> parse(String raw) {
        if (raw == null || !CANONICAL.matcher(raw).matches()) {
            return Optional.empty();
        }
        try {
            return Optional.of(UUID.fromString(raw));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
