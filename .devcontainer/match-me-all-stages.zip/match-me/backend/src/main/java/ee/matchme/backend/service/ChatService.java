package ee.matchme.backend.service;

import ee.matchme.backend.dto.ChatSummary;
import ee.matchme.backend.dto.MessageDto;
import ee.matchme.backend.dto.MessagePage;
import ee.matchme.backend.entity.Chat;
import ee.matchme.backend.entity.Connection;
import ee.matchme.backend.entity.ConnectionStatus;
import ee.matchme.backend.entity.Message;
import ee.matchme.backend.repository.ChatQueryRepository;
import ee.matchme.backend.repository.ChatRepository;
import ee.matchme.backend.repository.ConnectionRepository;
import ee.matchme.backend.repository.MessageRepository;
import ee.matchme.backend.util.UuidUtil;
import ee.matchme.backend.websocket.RealtimeEvents;
import ee.matchme.backend.websocket.RealtimeNotifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Chat rules: only the two participants of a connection can touch its chat (anyone else gets the
 * same 404 as for a chat that does not exist), and messages can only be sent while the connection is
 * ACCEPTED. History stays readable for the participants after a disconnect.
 */
@Service
public class ChatService {

    public static final int MAX_MESSAGE_LENGTH = 2000;
    public static final int MAX_PAGE_SIZE = 100;

    private final ConnectionRepository connections;
    private final ChatRepository chats;
    private final MessageRepository messages;
    private final ChatQueryRepository chatQueries;
    private final RealtimeNotifier notifier;

    public ChatService(ConnectionRepository connections, ChatRepository chats, MessageRepository messages,
                       ChatQueryRepository chatQueries, RealtimeNotifier notifier) {
        this.connections = connections;
        this.chats = chats;
        this.messages = messages;
        this.chatQueries = chatQueries;
        this.notifier = notifier;
    }

    @Transactional(readOnly = true)
    public List<ChatSummary> chatsOf(UUID me) {
        return chatQueries.chatsOf(me).stream()
                .map(r -> new ChatSummary(r.connectionId(), r.otherUserId(), r.unreadCount(),
                        r.lastMessage(), r.lastMessageAt(), r.lastSenderId()))
                .toList();
    }

    /** Page 0 = newest messages; each page is returned oldest-first. */
    @Transactional(readOnly = true)
    public MessagePage history(UUID me, String rawConnectionId, int page, int size) {
        Connection connection = requireParticipant(me, rawConnectionId);
        Chat chat = chats.findByConnectionId(connection.getId()).orElseThrow(NotFoundException::new);
        int safePage = Math.max(0, page);
        int safeSize = Math.min(Math.max(1, size), MAX_PAGE_SIZE);

        Sort newestFirst = Sort.by(Sort.Direction.DESC, "createdAt").and(Sort.by(Sort.Direction.DESC, "id"));
        Page<Message> result = messages.findByChatId(chat.getId(), PageRequest.of(safePage, safeSize, newestFirst));

        List<MessageDto> dtos = new ArrayList<>(result.getContent().stream()
                .map(m -> toDto(connection.getId(), m)).toList());
        Collections.reverse(dtos); // chronological within the page
        return new MessagePage(dtos, safePage, safeSize, result.getTotalElements(), result.hasNext());
    }

    @Transactional
    public MessageDto send(UUID me, String rawConnectionId, String content) {
        Connection connection = requireParticipant(me, rawConnectionId);
        if (connection.getStatus() != ConnectionStatus.ACCEPTED) {
            throw new NotFoundException();
        }
        Chat chat = chats.findByConnectionId(connection.getId()).orElseThrow(NotFoundException::new);
        String text = normalise(content);

        // Flush now so the unread counts below (plain SQL) can see the new row.
        Message saved = messages.saveAndFlush(new Message(chat.getId(), me, text));
        MessageDto dto = toDto(connection.getId(), saved);

        UUID other = connection.otherUser(me);
        RealtimeEvents.Unread unread = new RealtimeEvents.Unread(connection.getId(),
                messages.countByChatIdAndSenderIdNotAndReadAtIsNull(chat.getId(), other),
                chatQueries.totalUnread(other));
        notifier.afterCommit(() -> {
            notifier.toUser(me, "messages", dto);       // echo, so the sender's other tabs update too
            notifier.toUser(other, "messages", dto);
            notifier.toUser(other, "unread", unread);
        });
        return dto;
    }

    /** Marks everything the other side sent as read and updates both people's counters. */
    @Transactional
    public void markRead(UUID me, String rawConnectionId) {
        Connection connection = requireParticipant(me, rawConnectionId);
        Chat chat = chats.findByConnectionId(connection.getId()).orElseThrow(NotFoundException::new);
        int changed = messages.markRead(chat.getId(), me, Instant.now());
        if (changed == 0) {
            return;
        }
        UUID other = connection.otherUser(me);
        RealtimeEvents.Unread unread = new RealtimeEvents.Unread(connection.getId(), 0, chatQueries.totalUnread(me));
        RealtimeEvents.Read read = new RealtimeEvents.Read(connection.getId(), me);
        notifier.afterCommit(() -> {
            notifier.toUser(me, "unread", unread);
            notifier.toUser(other, "read", read);
        });
    }

    /** Relays "typing" to the other participant. Nothing is stored. */
    @Transactional(readOnly = true)
    public void typing(UUID me, String rawConnectionId, boolean typing) {
        Connection connection = requireParticipant(me, rawConnectionId);
        if (connection.getStatus() != ConnectionStatus.ACCEPTED) {
            throw new NotFoundException();
        }
        notifier.toUser(connection.otherUser(me), "typing",
                new RealtimeEvents.Typing(connection.getId(), me, typing));
    }

    // ---- helpers -------------------------------------------------------------------------

    /** The connection if {@code me} is one of its two users; otherwise the uniform 404. */
    private Connection requireParticipant(UUID me, String rawConnectionId) {
        UUID id = UuidUtil.parse(rawConnectionId).orElseThrow(NotFoundException::new);
        Connection connection = connections.findById(id).orElseThrow(NotFoundException::new);
        if (!me.equals(connection.getUserOneId()) && !me.equals(connection.getUserTwoId())) {
            throw new NotFoundException();
        }
        return connection;
    }

    private static String normalise(String content) {
        String text = content == null ? "" : content.strip();
        if (text.isEmpty()) {
            throw new ValidationFailedException(Map.of("content", "must not be blank"));
        }
        if (text.codePointCount(0, text.length()) > MAX_MESSAGE_LENGTH) {
            throw new ValidationFailedException(Map.of("content",
                    "must be at most " + MAX_MESSAGE_LENGTH + " characters"));
        }
        return text;
    }

    private static MessageDto toDto(UUID connectionId, Message m) {
        return new MessageDto(m.getId(), connectionId, m.getSenderId(), m.getContent(),
                m.getCreatedAt(), m.getReadAt());
    }
}
