package ee.matchme.backend.entity;

public enum CollaborationGoal {
    STUDY_PARTNER,
    PROJECT_TEAMMATE,
    CODE_REVIEW,
    EXAM_PREPARATION,
    ACCOUNTABILITY
}
