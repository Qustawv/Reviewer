package ee.matchme.backend.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/** Aggregate chat queries (chat list with last message and unread counts) in plain SQL. */
@Repository
public class ChatQueryRepository {

    public record ChatRow(UUID connectionId, UUID otherUserId, long unreadCount,
                          String lastMessage, Instant lastMessageAt, UUID lastSenderId) {
    }

    /** One row per ACCEPTED connection of the user that has a chat, most recent activity first. */
    static final String CHATS_SQL = """
            SELECT c.id AS connection_id,
                   CASE WHEN c.user_one_id = ? THEN c.user_two_id ELSE c.user_one_id END AS other_user_id,
                   (SELECT count(*) FROM messages m
                     WHERE m.chat_id = ch.id AND m.sender_id <> ? AND m.read_at IS NULL) AS unread,
                   lm.content AS last_content, lm.created_at AS last_at, lm.sender_id AS last_sender
            FROM connections c
            JOIN chats ch ON ch.connection_id = c.id
            LEFT JOIN LATERAL (SELECT content, created_at, sender_id FROM messages
                                WHERE chat_id = ch.id
                                ORDER BY created_at DESC, id DESC LIMIT 1) lm ON TRUE
            WHERE (c.user_one_id = ? OR c.user_two_id = ?) AND c.status = 'ACCEPTED'
            ORDER BY COALESCE(lm.created_at, ch.created_at) DESC, c.id
            """;

    static final String TOTAL_UNREAD_SQL = """
            SELECT count(*)
            FROM messages m
            JOIN chats ch ON ch.id = m.chat_id
            JOIN connections c ON c.id = ch.connection_id
            WHERE c.status = 'ACCEPTED'
              AND (c.user_one_id = ? OR c.user_two_id = ?)
              AND m.sender_id <> ? AND m.read_at IS NULL
            """;

    private final JdbcTemplate jdbc;

    public ChatQueryRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<ChatRow> chatsOf(UUID userId) {
        return jdbc.query(CHATS_SQL, (rs, i) -> {
            OffsetDateTime at = rs.getObject("last_at", OffsetDateTime.class);
            return new ChatRow(
                    rs.getObject("connection_id", UUID.class),
                    rs.getObject("other_user_id", UUID.class),
                    rs.getLong("unread"),
                    rs.getString("last_content"),
                    at == null ? null : at.toInstant(),
                    rs.getObject("last_sender", UUID.class));
        }, userId, userId, userId, userId);
    }

    public long totalUnread(UUID userId) {
        Long n = jdbc.queryForObject(TOTAL_UNREAD_SQL, Long.class, userId, userId, userId);
        return n == null ? 0 : n;
    }
}
