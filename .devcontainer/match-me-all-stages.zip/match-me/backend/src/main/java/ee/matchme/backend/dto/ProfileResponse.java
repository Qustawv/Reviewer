package ee.matchme.backend.dto;

import java.util.UUID;

/** {@code GET /users/{id}/profile} and {@code GET /me/profile}. */
public record ProfileResponse(UUID id, String aboutMe) {
}
