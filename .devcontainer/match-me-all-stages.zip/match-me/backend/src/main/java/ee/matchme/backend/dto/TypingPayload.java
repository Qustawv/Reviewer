package ee.matchme.backend.dto;

/** STOMP payload of {@code /app/chats/{connectionId}/typing}. */
public record TypingPayload(boolean typing) {
}
