package ee.matchme.backend.service;

import java.util.Map;

public class ValidationFailedException extends RuntimeException {

    private final transient Map<String, String> fields;

    public ValidationFailedException(Map<String, String> fields) {
        super("Validation failed: " + fields);
        this.fields = Map.copyOf(fields);
    }

    public Map<String, String> getFields() {
        return fields;
    }
}
