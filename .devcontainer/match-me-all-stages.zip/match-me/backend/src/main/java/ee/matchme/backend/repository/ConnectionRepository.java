package ee.matchme.backend.repository;

import ee.matchme.backend.entity.Connection;
import ee.matchme.backend.entity.ConnectionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ConnectionRepository extends JpaRepository<Connection, UUID> {

    /** Lookup by canonical pair: {@code userOneId} must be the lower id (see {@code UuidUtil}). */
    Optional<Connection> findByUserOneIdAndUserTwoId(UUID userOneId, UUID userTwoId);

    boolean existsByUserOneIdAndUserTwoIdAndStatusIn(UUID userOneId, UUID userTwoId,
                                                     Collection<ConnectionStatus> statuses);

    @Query("select c from Connection c "
            + "where c.status = :status and (c.userOneId = :userId or c.userTwoId = :userId) "
            + "order by c.createdAt")
    List<Connection> findByUserAndStatus(@Param("userId") UUID userId,
                                         @Param("status") ConnectionStatus status);
}
