package ee.matchme.backend.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.UUID;

/** Sends events to one user's private queues, and defers sending until the database commit. */
@Component
public class RealtimeNotifier {

    private static final Logger log = LoggerFactory.getLogger(RealtimeNotifier.class);

    private final SimpMessagingTemplate template;

    public RealtimeNotifier(SimpMessagingTemplate template) {
        this.template = template;
    }

    /** Delivers {@code payload} to every open session of {@code userId} on {@code /user/queue/<queue>}. */
    public void toUser(UUID userId, String queue, Object payload) {
        template.convertAndSendToUser(userId.toString(), "/queue/" + queue, payload);
    }

    /**
     * Runs {@code action} after the surrounding transaction commits (immediately when there is none),
     * so clients are never told about something that was rolled back. A failure while pushing is
     * logged and never undoes the committed change.
     */
    public void afterCommit(Runnable action) {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    runSafely(action);
                }
            });
        } else {
            runSafely(action);
        }
    }

    private static void runSafely(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException e) {
            log.warn("Realtime notification failed", e);
        }
    }
}
