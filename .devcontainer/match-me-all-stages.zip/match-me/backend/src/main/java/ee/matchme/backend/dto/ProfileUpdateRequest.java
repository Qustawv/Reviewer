package ee.matchme.backend.dto;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;

import java.util.Set;

/**
 * {@code PUT /me/profile}: full replacement of the editable profile. A missing/null field clears
 * it, so drafts can be saved; {@code profileComplete} is NOT an input and is always recomputed
 * server-side. Blank strings are normalised to null. Limits are checked in {@code ProfileService}.
 */
public record ProfileUpdateRequest(
        String displayName,
        String aboutMe,
        StudyArea studyArea,
        StudyLevel studyLevel,
        Set<String> skills,
        Set<CollaborationGoal> collaborationGoals,
        Set<AvailabilitySlot> availability,
        WorkStyle workStyle,
        Set<PreferredLanguage> preferredLanguages,
        Double latitude,
        Double longitude,
        Integer maximumDistanceKm,
        String city,
        String profileImageUrl,
        Set<PriorityField> priorityFields) {

    public ProfileUpdateRequest {
        displayName = blankToNull(displayName);
        aboutMe = blankToNull(aboutMe);
        city = blankToNull(city);
        profileImageUrl = blankToNull(profileImageUrl);
    }

    private static String blankToNull(String s) {
        if (s == null) {
            return null;
        }
        String t = s.strip();
        return t.isEmpty() ? null : t;
    }
}
