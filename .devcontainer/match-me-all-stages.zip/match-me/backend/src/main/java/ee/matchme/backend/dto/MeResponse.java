package ee.matchme.backend.dto;

import java.util.UUID;

/** {@code GET /me}: the only payload that contains the account email, and only for its owner. */
public record MeResponse(UUID id, String email, String displayName, String profileImageUrl) {
}
