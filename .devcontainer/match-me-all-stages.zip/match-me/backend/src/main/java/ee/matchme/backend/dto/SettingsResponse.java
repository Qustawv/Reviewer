package ee.matchme.backend.dto;

import ee.matchme.backend.entity.PriorityField;

import java.util.List;

/**
 * {@code GET /me/settings} (owner only): the private profile fields plus the server-computed
 * {@code profileComplete} flag. Never reachable for other users.
 */
public record SettingsResponse(
        boolean profileComplete,
        Double latitude,
        Double longitude,
        Integer maximumDistanceKm,
        List<PriorityField> priorityFields) {
}
