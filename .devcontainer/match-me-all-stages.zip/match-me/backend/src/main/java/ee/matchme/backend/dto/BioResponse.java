package ee.matchme.backend.dto;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;

import java.util.List;
import java.util.UUID;

/**
 * {@code GET /users/{id}/bio} and {@code GET /me/bio}. Exactly these nine fields: latitude,
 * longitude, maximumDistanceKm and priorityFields are private and are NOT part of it.
 */
public record BioResponse(
        UUID id,
        StudyArea studyArea,
        StudyLevel studyLevel,
        List<String> skills,
        List<CollaborationGoal> collaborationGoals,
        List<AvailabilitySlot> availability,
        WorkStyle workStyle,
        List<PreferredLanguage> preferredLanguages,
        String city) {
}
