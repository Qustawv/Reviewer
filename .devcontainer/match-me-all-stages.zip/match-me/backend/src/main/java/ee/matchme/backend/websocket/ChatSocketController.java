package ee.matchme.backend.websocket;

import ee.matchme.backend.dto.SendMessagePayload;
import ee.matchme.backend.dto.TypingPayload;
import ee.matchme.backend.service.ChatService;
import ee.matchme.backend.service.ConnectionService;
import ee.matchme.backend.service.NotFoundException;
import ee.matchme.backend.service.ValidationFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

/**
 * STOMP endpoints (all under the {@code /app} prefix):
 * <pre>
 *   SUBSCRIBE /app/presence/snapshot          -> who among my connections is online now
 *   SEND      /app/chats/{connectionId}/send    {"content": "..."}
 *   SEND      /app/chats/{connectionId}/typing  {"typing": true}
 *   SEND      /app/chats/{connectionId}/read    (no body) mark the chat as read
 * </pre>
 * The snapshot is a subscribe-reply on purpose: it is delivered to that subscription directly, so it
 * cannot be lost to the race between "SUBSCRIBE processed" and "server pushes".
 */
@Controller
public class ChatSocketController {

    private static final Logger log = LoggerFactory.getLogger(ChatSocketController.class);

    private final ChatService chatService;
    private final ConnectionService connectionService;
    private final PresenceRegistry presenceRegistry;

    public ChatSocketController(ChatService chatService, ConnectionService connectionService,
                                PresenceRegistry presenceRegistry) {
        this.chatService = chatService;
        this.connectionService = connectionService;
        this.presenceRegistry = presenceRegistry;
    }

    @SubscribeMapping("/presence/snapshot")
    public RealtimeEvents.Presence presenceSnapshot(Principal principal) {
        UUID me = requireUser(principal);
        List<UUID> online = presenceRegistry.onlineAmong(connectionService.connectedUserIds(me));
        return RealtimeEvents.Presence.snapshot(online);
    }

    @MessageMapping("/chats/{connectionId}/send")
    public void send(@DestinationVariable("connectionId") String connectionId,
                     @Payload SendMessagePayload payload, Principal principal) {
        chatService.send(requireUser(principal), connectionId, payload == null ? null : payload.content());
    }

    @MessageMapping("/chats/{connectionId}/typing")
    public void typing(@DestinationVariable("connectionId") String connectionId,
                       @Payload TypingPayload payload, Principal principal) {
        chatService.typing(requireUser(principal), connectionId, payload != null && payload.typing());
    }

    @MessageMapping("/chats/{connectionId}/read")
    public void read(@DestinationVariable("connectionId") String connectionId, Principal principal) {
        chatService.markRead(requireUser(principal), connectionId);
    }

    /** A rejected frame is reported only to the session that sent it. */
    @MessageExceptionHandler
    @SendToUser(destinations = "/queue/errors", broadcast = false)
    public RealtimeEvents.ErrorEvent handleException(Exception e) {
        if (e instanceof NotFoundException) {
            return new RealtimeEvents.ErrorEvent("not_found");
        }
        if (e instanceof ValidationFailedException) {
            return new RealtimeEvents.ErrorEvent("validation_failed");
        }
        log.warn("Unhandled error in a STOMP handler", e);
        return new RealtimeEvents.ErrorEvent("error");
    }

    private static UUID requireUser(Principal principal) {
        UUID id = PresenceEventListener.userId(principal);
        if (id == null) {
            throw new NotFoundException();
        }
        return id;
    }
}
