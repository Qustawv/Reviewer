package ee.matchme.backend.dto;

import java.time.Instant;
import java.util.UUID;

/** {@code GET /chats}: one entry per accepted connection that has a chat. */
public record ChatSummary(UUID connectionId, UUID userId, long unreadCount,
                          String lastMessage, Instant lastMessageAt, UUID lastSenderId) {
}
