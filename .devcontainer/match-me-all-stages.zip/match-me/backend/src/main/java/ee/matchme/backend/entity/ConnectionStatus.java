package ee.matchme.backend.entity;

public enum ConnectionStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    DISCONNECTED
}
