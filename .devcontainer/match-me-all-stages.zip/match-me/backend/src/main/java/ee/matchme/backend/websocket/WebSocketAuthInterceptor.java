package ee.matchme.backend.websocket;

import ee.matchme.backend.repository.UserRepository;
import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.security.JwtService;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Security for the STOMP channel.
 *
 * <ul>
 *   <li><b>CONNECT</b> must carry {@code Authorization: Bearer <jwt>} as a STOMP header. (Not in the
 *       URL: query strings end up in logs.) The verified user becomes the session principal.</li>
 *   <li>Every other frame needs that principal.</li>
 *   <li><b>SUBSCRIBE</b> is limited to the caller's own {@code /user/queue/**} and the presence
 *       snapshot, so nobody can listen on another user's queue.</li>
 *   <li><b>SEND</b> is limited to {@code /app/**}. Without this a client could SEND straight to
 *       {@code /user/<someone-else>/queue/messages} and forge events for that person.</li>
 * </ul>
 */
@Component
public class WebSocketAuthInterceptor implements ChannelInterceptor {

    private static final String BEARER = "Bearer ";

    private final JwtService jwtService;
    private final UserRepository userRepository;

    public WebSocketAuthInterceptor(JwtService jwtService, UserRepository userRepository) {
        this.jwtService = jwtService;
        this.userRepository = userRepository;
    }

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        if (accessor == null || accessor.getCommand() == null) {
            return message; // heart-beat
        }
        StompCommand command = accessor.getCommand();

        if (StompCommand.CONNECT.equals(command) || StompCommand.STOMP.equals(command)) {
            accessor.setUser(authenticate(accessor));
            return message;
        }
        if (StompCommand.DISCONNECT.equals(command)) {
            return message;
        }
        if (accessor.getUser() == null) {
            throw new MessagingException("Not authenticated");
        }
        String destination = accessor.getDestination();
        if (StompCommand.SUBSCRIBE.equals(command) && !isAllowedSubscription(destination)) {
            throw new MessagingException("Subscription not allowed");
        }
        if (StompCommand.SEND.equals(command) && (destination == null || !destination.startsWith("/app/"))) {
            throw new MessagingException("Destination not allowed");
        }
        return message;
    }

    static boolean isAllowedSubscription(String destination) {
        return destination != null
                && (destination.startsWith("/user/queue/") || destination.equals("/app/presence/snapshot"));
    }

    private AuthenticatedUser authenticate(StompHeaderAccessor accessor) {
        String header = accessor.getFirstNativeHeader("Authorization");
        if (header == null || !header.regionMatches(true, 0, BEARER, 0, BEARER.length())) {
            throw new MessagingException("Missing bearer token");
        }
        UUID userId = jwtService.parse(header.substring(BEARER.length()).trim())
                .filter(userRepository::existsById)
                .orElseThrow(() -> new MessagingException("Invalid token"));
        return new AuthenticatedUser(userId);
    }
}
