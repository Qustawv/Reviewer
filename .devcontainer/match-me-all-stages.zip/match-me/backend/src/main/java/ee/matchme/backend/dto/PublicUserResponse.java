package ee.matchme.backend.dto;

import java.util.UUID;

/** {@code GET /users/{id}}. Never contains email or any location data. */
public record PublicUserResponse(UUID id, String displayName, String profileImageUrl) {
}
