package ee.matchme.backend.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/** "Not interested" marks, stored in {@code recommendation_dismissals} (see V3). */
@Repository
public class DismissalRepository {

    private final JdbcTemplate jdbc;

    public DismissalRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Idempotent: dismissing the same user twice is not an error. */
    public void dismiss(UUID userId, UUID dismissedUserId) {
        jdbc.update("INSERT INTO recommendation_dismissals (user_id, dismissed_user_id) VALUES (?, ?) "
                + "ON CONFLICT DO NOTHING", userId, dismissedUserId);
    }
}
