package ee.matchme.backend.entity;

public enum PriorityField {
    SKILLS,
    COLLABORATION_GOALS,
    AVAILABILITY,
    STUDY_AREA,
    WORK_STYLE,
    STUDY_LEVEL
}
