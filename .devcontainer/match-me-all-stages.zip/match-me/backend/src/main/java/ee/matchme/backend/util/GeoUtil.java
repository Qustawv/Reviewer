package ee.matchme.backend.util;

public final class GeoUtil {

    /** Mean Earth radius in kilometres (IUGG). */
    public static final double EARTH_RADIUS_KM = 6371.0088;

    private GeoUtil() {
    }

    /** Great-circle distance between two WGS84 points, in kilometres (Haversine formula). */
    public static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double phi1 = Math.toRadians(lat1);
        double phi2 = Math.toRadians(lat2);
        double dPhi = Math.toRadians(lat2 - lat1);
        double dLambda = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dPhi / 2) * Math.sin(dPhi / 2)
                + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) * Math.sin(dLambda / 2);
        // Clamp: rounding can push `a` a hair above 1 for antipodal points.
        return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1.0, Math.sqrt(a)));
    }
}
