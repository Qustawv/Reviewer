package ee.matchme.backend.dto;

import java.util.List;

/**
 * One page of chat history. Page 0 holds the most recent messages, higher pages go further back;
 * inside every page the messages are in chronological order (oldest first), so a client renders a
 * page as-is and prepends older pages above it.
 */
public record MessagePage(List<MessageDto> messages, int page, int size, long totalMessages, boolean hasOlder) {
}
