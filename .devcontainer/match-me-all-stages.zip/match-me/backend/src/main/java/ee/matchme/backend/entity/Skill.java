package ee.matchme.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Row of the fixed {@code skills} lookup table (seeded by migration V2, read-only at runtime). */
@Entity
@Table(name = "skills")
public class Skill {

    @Id
    @Column(name = "code")
    private String code;

    @Column(name = "label", nullable = false)
    private String label;

    protected Skill() {
        // for JPA
    }

    public String getCode() {
        return code;
    }

    public String getLabel() {
        return label;
    }
}
