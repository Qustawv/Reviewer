package ee.matchme.backend.service;

import ee.matchme.backend.entity.Profile;
import ee.matchme.backend.repository.DismissalRepository;
import ee.matchme.backend.repository.ProfileRepository;
import ee.matchme.backend.repository.RecommendationCandidateRepository;
import ee.matchme.backend.util.UuidUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Computes recommendations on demand and remembers, per user, the ids it last served: the user's
 * <em>active recommendations</em>. Those are what the access guard uses to decide whether
 * {@code /users/{id}} may be viewed, and the only users one may send a connection request to or
 * dismiss. Because the list is partly random, serving and authorising must use the same snapshot.
 *
 * <p>The active sets live in memory (default lifetime 24 h). With several backend instances behind
 * a load balancer they would have to move to a shared store; for one instance this is exact.
 */
@Service
public class RecommendationService {

    private record Served(Set<UUID> ids, Instant expiresAt) {
        boolean expired(Instant now) {
            return !expiresAt.isAfter(now);
        }
    }

    private static final int PRUNE_THRESHOLD = 1_000;

    private final ProfileRepository profileRepository;
    private final RecommendationCandidateRepository candidateRepository;
    private final DismissalRepository dismissalRepository;
    private final Duration activeTtl;
    private final Map<UUID, Served> active = new ConcurrentHashMap<>();

    public RecommendationService(ProfileRepository profileRepository,
                                 RecommendationCandidateRepository candidateRepository,
                                 DismissalRepository dismissalRepository,
                                 @Value("${matchme.recommendations.active-ttl-minutes:1440}") long activeTtlMinutes) {
        this.profileRepository = profileRepository;
        this.candidateRepository = candidateRepository;
        this.dismissalRepository = dismissalRepository;
        this.activeTtl = Duration.ofMinutes(activeTtlMinutes);
    }

    /**
     * {@code GET /recommendations}: at most 10 user ids. Throws {@link ProfileIncompleteException}
     * for an incomplete profile (the completion gate).
     */
    @Transactional(readOnly = true)
    public List<UUID> recommendationsFor(UUID userId) {
        Profile profile = profileRepository.findById(userId).orElseThrow(NotFoundException::new);
        if (!profile.isProfileComplete()) {
            throw new ProfileIncompleteException();
        }
        RecommendationProfile me = RecommendationProfile.from(profile);
        List<RecommendationProfile> candidates = candidateRepository.findCandidates(me);
        List<UUID> result = RecommendationEngine.recommend(me, candidates, Set.of(), ThreadLocalRandom.current());
        remember(userId, result);
        return result;
    }

    /** {@code POST /recommendations/{id}/dismiss}: only users currently recommended can be dismissed. */
    @Transactional
    public void dismiss(UUID userId, String rawTargetId) {
        UUID target = UuidUtil.parse(rawTargetId).orElseThrow(NotFoundException::new);
        if (!isActive(userId, target)) {
            throw new NotFoundException();
        }
        dismissalRepository.dismiss(userId, target);
        Served served = active.get(userId);
        if (served != null) {
            Set<UUID> remaining = new java.util.HashSet<>(served.ids());
            remaining.remove(target);
            active.put(userId, new Served(Set.copyOf(remaining), served.expiresAt()));
        }
    }

    // ---- the active set ------------------------------------------------------------------

    /** The ids most recently served to {@code userId} (empty if none, or if they expired). */
    public Set<UUID> activeRecommendationIds(UUID userId) {
        Served served = active.get(userId);
        if (served == null || served.expired(Instant.now())) {
            return Set.of();
        }
        return served.ids();
    }

    public boolean isActive(UUID userId, UUID candidateId) {
        return activeRecommendationIds(userId).contains(candidateId);
    }

    /** Forget what was served, e.g. after the user edited their profile and the pool changes. */
    public void invalidate(UUID userId) {
        active.remove(userId);
    }

    private void remember(UUID userId, List<UUID> ids) {
        Instant now = Instant.now();
        if (active.size() > PRUNE_THRESHOLD) {
            active.values().removeIf(s -> s.expired(now));
        }
        active.put(userId, new Served(Set.copyOf(ids), now.plus(activeTtl)));
    }
}
