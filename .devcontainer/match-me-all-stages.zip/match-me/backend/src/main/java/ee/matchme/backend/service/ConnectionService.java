package ee.matchme.backend.service;

import ee.matchme.backend.dto.ConnectionResponse;
import ee.matchme.backend.entity.Chat;
import ee.matchme.backend.entity.Connection;
import ee.matchme.backend.entity.ConnectionStatus;
import ee.matchme.backend.entity.Profile;
import ee.matchme.backend.repository.ChatRepository;
import ee.matchme.backend.repository.ConnectionRepository;
import ee.matchme.backend.repository.ProfileRepository;
import ee.matchme.backend.util.UuidUtil;
import ee.matchme.backend.websocket.PresenceRegistry;
import ee.matchme.backend.websocket.RealtimeEvents;
import ee.matchme.backend.websocket.RealtimeNotifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Connection lifecycle: PENDING --accept--> ACCEPTED --disconnect--> DISCONNECTED, or
 * PENDING --reject--> REJECTED. A pair has at most one row for good, so rejected and disconnected
 * pairs are never recommended again and cannot re-request.
 */
@Service
public class ConnectionService {

    private final ConnectionRepository connections;
    private final ProfileRepository profiles;
    private final ChatRepository chats;
    private final RecommendationService recommendations;
    private final RealtimeNotifier notifier;
    private final PresenceRegistry presence;

    public ConnectionService(ConnectionRepository connections, ProfileRepository profiles, ChatRepository chats,
                             RecommendationService recommendations, RealtimeNotifier notifier,
                             PresenceRegistry presence) {
        this.connections = connections;
        this.profiles = profiles;
        this.chats = chats;
        this.recommendations = recommendations;
        this.notifier = notifier;
        this.presence = presence;
    }

    // ---- lists ---------------------------------------------------------------------------

    /** Ids of the users {@code userId} is currently connected to (ACCEPTED connections only). */
    @Transactional(readOnly = true)
    public List<UUID> connectedUserIds(UUID userId) {
        return connections.findByUserAndStatus(userId, ConnectionStatus.ACCEPTED).stream()
                .map(c -> c.otherUser(userId))
                .toList();
    }

    /** Users who sent {@code userId} a request that is still pending. */
    @Transactional(readOnly = true)
    public List<UUID> incomingRequestIds(UUID userId) {
        return connections.findByUserAndStatus(userId, ConnectionStatus.PENDING).stream()
                .filter(c -> !c.getRequesterId().equals(userId))
                .map(Connection::getRequesterId)
                .toList();
    }

    /** Users {@code userId} sent a request to that is still pending. */
    @Transactional(readOnly = true)
    public List<UUID> outgoingRequestIds(UUID userId) {
        return connections.findByUserAndStatus(userId, ConnectionStatus.PENDING).stream()
                .filter(c -> c.getRequesterId().equals(userId))
                .map(c -> c.otherUser(userId))
                .toList();
    }

    // ---- actions -------------------------------------------------------------------------

    /**
     * Send a request. Needs a complete profile, and the target must be one of the users currently
     * recommended to the sender (the same rule that makes their profile visible).
     */
    @Transactional
    public ConnectionResponse sendRequest(UUID me, String rawTargetId) {
        requireCompleteProfile(me);
        UUID target = UuidUtil.parse(rawTargetId).orElseThrow(NotFoundException::new);
        if (target.equals(me) || !recommendations.isActive(me, target)) {
            throw new NotFoundException();
        }
        if (find(me, target).isPresent()) {
            throw new ConflictException("A request or connection with this user already exists");
        }
        // A concurrent duplicate hits the unique (user_one_id, user_two_id) constraint and becomes a 409.
        Connection saved = connections.save(Connection.request(me, target));
        notifier.afterCommit(() -> notifier.toUser(target, "connections",
                new RealtimeEvents.ConnectionEvent(RealtimeEvents.ConnectionEvent.REQUEST_RECEIVED, me, saved.getId())));
        return new ConnectionResponse(saved.getId(), target, ConnectionStatus.PENDING);
    }

    /** Accept a pending request that {@code requesterId} sent to {@code me}; opens the chat. */
    @Transactional
    public ConnectionResponse accept(UUID me, String rawRequesterId) {
        UUID requester = UuidUtil.parse(rawRequesterId).orElseThrow(NotFoundException::new);
        Connection connection = requirePendingRequestFrom(me, requester);
        connection.setStatus(ConnectionStatus.ACCEPTED);
        // Flush BEFORE creating the chat: Hibernate runs INSERTs before UPDATEs, and the database
        // trigger on `chats` only accepts a connection that is already ACCEPTED.
        connections.saveAndFlush(connection);
        chats.findByConnectionId(connection.getId())
                .orElseGet(() -> chats.save(new Chat(connection.getId())));

        notifier.afterCommit(() -> {
            notifier.toUser(requester, "connections", new RealtimeEvents.ConnectionEvent(
                    RealtimeEvents.ConnectionEvent.REQUEST_ACCEPTED, me, connection.getId()));
            // They can see each other now, so tell each side if the other is already online.
            if (presence.isOnline(me)) {
                notifier.toUser(requester, "presence", RealtimeEvents.Presence.update(me, true));
            }
            if (presence.isOnline(requester)) {
                notifier.toUser(me, "presence", RealtimeEvents.Presence.update(requester, true));
            }
        });
        return new ConnectionResponse(connection.getId(), requester, ConnectionStatus.ACCEPTED);
    }

    /** Reject a pending request that {@code requesterId} sent to {@code me}. The sender is not notified. */
    @Transactional
    public ConnectionResponse reject(UUID me, String rawRequesterId) {
        UUID requester = UuidUtil.parse(rawRequesterId).orElseThrow(NotFoundException::new);
        Connection connection = requirePendingRequestFrom(me, requester);
        connection.setStatus(ConnectionStatus.REJECTED);
        connections.save(connection);
        return new ConnectionResponse(connection.getId(), requester, ConnectionStatus.REJECTED);
    }

    /** End an ACCEPTED connection (either side). The row stays, so the pair is never re-recommended. */
    @Transactional
    public void disconnect(UUID me, String rawOtherId) {
        UUID other = UuidUtil.parse(rawOtherId).orElseThrow(NotFoundException::new);
        Connection connection = find(me, other)
                .filter(c -> c.getStatus() == ConnectionStatus.ACCEPTED)
                .orElseThrow(NotFoundException::new);
        connection.setStatus(ConnectionStatus.DISCONNECTED);
        connections.save(connection);
        notifier.afterCommit(() -> notifier.toUser(other, "connections", new RealtimeEvents.ConnectionEvent(
                RealtimeEvents.ConnectionEvent.DISCONNECTED, me, connection.getId())));
    }

    // ---- helpers -------------------------------------------------------------------------

    private java.util.Optional<Connection> find(UUID a, UUID b) {
        return connections.findByUserOneIdAndUserTwoId(UuidUtil.lower(a, b), UuidUtil.higher(a, b));
    }

    /** {@code me} must be the addressee of a PENDING request from {@code requester}; else the uniform 404. */
    private Connection requirePendingRequestFrom(UUID me, UUID requester) {
        return find(me, requester)
                .filter(c -> c.getStatus() == ConnectionStatus.PENDING && c.getRequesterId().equals(requester))
                .orElseThrow(NotFoundException::new);
    }

    private void requireCompleteProfile(UUID userId) {
        boolean complete = profiles.findById(userId).map(Profile::isProfileComplete).orElse(false);
        if (!complete) {
            throw new ProfileIncompleteException();
        }
    }
}
