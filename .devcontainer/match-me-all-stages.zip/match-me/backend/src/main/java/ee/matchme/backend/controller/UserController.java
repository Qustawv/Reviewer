package ee.matchme.backend.controller;

import ee.matchme.backend.dto.BioResponse;
import ee.matchme.backend.dto.ProfileResponse;
import ee.matchme.backend.dto.PublicUserResponse;
import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.service.ProfileService;
import ee.matchme.backend.service.UserAccessService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Other users' public data. Every endpoint runs the access guard first; a user that does not exist,
 * is not visible to the caller, or has a malformed id yields the same HTTP 404.
 *
 * <p>The id is taken as a raw string on purpose: a typed UUID parameter would turn a malformed id
 * into a 400, which would be distinguishable from the 404 for an unknown id.
 */
@RestController
@RequestMapping("/users/{id}")
public class UserController {

    private final UserAccessService accessService;
    private final ProfileService profileService;

    public UserController(UserAccessService accessService, ProfileService profileService) {
        this.accessService = accessService;
        this.profileService = profileService;
    }

    @GetMapping
    public PublicUserResponse user(@AuthenticationPrincipal AuthenticatedUser viewer, @PathVariable String id) {
        return profileService.publicUser(accessService.requireViewable(viewer.id(), id));
    }

    @GetMapping("/profile")
    public ProfileResponse profile(@AuthenticationPrincipal AuthenticatedUser viewer, @PathVariable String id) {
        return profileService.profile(accessService.requireViewable(viewer.id(), id));
    }

    @GetMapping("/bio")
    public BioResponse bio(@AuthenticationPrincipal AuthenticatedUser viewer, @PathVariable String id) {
        return profileService.bio(accessService.requireViewable(viewer.id(), id));
    }
}
