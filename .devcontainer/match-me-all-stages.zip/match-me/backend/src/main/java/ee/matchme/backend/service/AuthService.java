package ee.matchme.backend.service;

import ee.matchme.backend.dto.AuthResponse;
import ee.matchme.backend.dto.LoginRequest;
import ee.matchme.backend.dto.RegisterRequest;
import ee.matchme.backend.entity.Profile;
import ee.matchme.backend.entity.User;
import ee.matchme.backend.repository.ProfileRepository;
import ee.matchme.backend.repository.UserRepository;
import ee.matchme.backend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
public class AuthService {

    private static final int BCRYPT_MAX_PASSWORD_BYTES = 72;

    private final UserRepository userRepository;
    private final ProfileRepository profileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    /** Compared against when the email is unknown, so login timing does not reveal which emails exist. */
    private final String dummyHash;

    public AuthService(UserRepository userRepository, ProfileRepository profileRepository,
                       PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.dummyHash = passwordEncoder.encode("not-a-real-password");
    }

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (request.password().getBytes(StandardCharsets.UTF_8).length > BCRYPT_MAX_PASSWORD_BYTES) {
            throw new ValidationFailedException(Map.of("password",
                    "must be at most " + BCRYPT_MAX_PASSWORD_BYTES + " bytes"));
        }
        String email = User.normalizeEmail(request.email());
        if (userRepository.existsByEmail(email)) {
            throw new ConflictException("Email is already registered");
        }
        // A concurrent duplicate registration is caught by the unique constraint and surfaces as 409.
        User user = userRepository.save(new User(email, passwordEncoder.encode(request.password())));
        profileRepository.save(new Profile(user.getId()));
        return new AuthResponse(jwtService.issueToken(user.getId()));
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(User.normalizeEmail(request.email())).orElse(null);
        String hash = user != null ? user.getPasswordHash() : dummyHash;
        boolean matches = passwordEncoder.matches(request.password(), hash);
        if (user == null || !matches) {
            throw new InvalidCredentialsException();
        }
        return new AuthResponse(jwtService.issueToken(user.getId()));
    }
}
