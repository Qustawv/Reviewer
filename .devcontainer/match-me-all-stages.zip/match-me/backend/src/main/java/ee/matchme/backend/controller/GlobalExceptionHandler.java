package ee.matchme.backend.controller;

import ee.matchme.backend.dto.ErrorResponse;
import ee.matchme.backend.service.ConflictException;
import ee.matchme.backend.service.InvalidCredentialsException;
import ee.matchme.backend.service.ProfileIncompleteException;
import ee.matchme.backend.service.NotFoundException;
import ee.matchme.backend.service.ValidationFailedException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    /** One fixed body for every 404, so "missing" and "forbidden" are byte-for-byte identical. */
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> notFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ErrorResponse.of("not_found"));
    }

    /** The profile completion gate: no recommendations or connection requests until the profile is complete. */
    @ExceptionHandler(ProfileIncompleteException.class)
    public ResponseEntity<ErrorResponse> profileIncomplete() {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ErrorResponse.of("profile_incomplete"));
    }

    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<ErrorResponse> invalidCredentials() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ErrorResponse.of("invalid_credentials"));
    }

    @ExceptionHandler({ConflictException.class, DataIntegrityViolationException.class})
    public ResponseEntity<ErrorResponse> conflict() {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ErrorResponse.of("conflict"));
    }

    @ExceptionHandler(ValidationFailedException.class)
    public ResponseEntity<ErrorResponse> validationFailed(ValidationFailedException e) {
        return ResponseEntity.badRequest().body(new ErrorResponse("validation_failed", e.getFields()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> beanValidation(MethodArgumentNotValidException e) {
        Map<String, String> fields = new LinkedHashMap<>();
        for (FieldError fe : e.getBindingResult().getFieldErrors()) {
            fields.putIfAbsent(fe.getField(), fe.getDefaultMessage());
        }
        return ResponseEntity.badRequest().body(new ErrorResponse("validation_failed", fields));
    }

    /** Malformed JSON, or an unknown enum constant such as {@code "studyArea": "COOKING"}. */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> unreadable() {
        return ResponseEntity.badRequest().body(ErrorResponse.of("malformed_request"));
    }
}
