package ee.matchme.backend.entity;

public enum StudyLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
