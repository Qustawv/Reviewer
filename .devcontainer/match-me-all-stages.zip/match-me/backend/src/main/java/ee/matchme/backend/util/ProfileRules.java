package ee.matchme.backend.util;

import ee.matchme.backend.entity.Profile;

import java.util.Set;

/**
 * Single source of truth for the profile limits and for the profile completion gate.
 *
 * <p>String lengths are measured in Unicode code points, matching PostgreSQL's {@code char_length}
 * (Java's {@code String.length()} counts UTF-16 units, so an emoji would count twice).
 */
public final class ProfileRules {

    public static final int DISPLAY_NAME_MIN = 2;
    public static final int DISPLAY_NAME_MAX = 40;
    public static final int ABOUT_ME_MIN = 30;
    public static final int ABOUT_ME_MAX = 500;
    public static final int CITY_MAX = 100;
    public static final int IMAGE_URL_MAX = 500;

    public static final int SKILLS_MIN = 1;
    public static final int SKILLS_MAX = 8;
    public static final int GOALS_MIN = 1;
    public static final int GOALS_MAX = 3;
    public static final int AVAILABILITY_MIN = 1;
    public static final int AVAILABILITY_MAX = 14;
    public static final int LANGUAGES_MIN = 1;
    public static final int LANGUAGES_MAX = 4;
    public static final int PRIORITY_FIELDS_MAX = 2;

    public static final Set<Integer> ALLOWED_DISTANCES_KM = Set.of(5, 10, 25, 50, 100);

    private ProfileRules() {
    }

    public static int length(String s) {
        return s == null ? 0 : s.codePointCount(0, s.length());
    }

    public static boolean lengthBetween(String s, int min, int max) {
        int len = length(s);
        return s != null && len >= min && len <= max;
    }

    public static boolean validLatitude(Double v) {
        return v != null && Double.isFinite(v) && v >= -90.0 && v <= 90.0;
    }

    public static boolean validLongitude(Double v) {
        return v != null && Double.isFinite(v) && v >= -180.0 && v <= 180.0;
    }

    /**
     * The profile completion gate: true only if all 12 mandatory fields are present and valid.
     * Optional fields ({@code profileImageUrl}, {@code priorityFields}) never affect the result.
     */
    public static boolean isComplete(Profile p) {
        return lengthBetween(p.getDisplayName(), DISPLAY_NAME_MIN, DISPLAY_NAME_MAX)                 // 1
                && lengthBetween(p.getAboutMe(), ABOUT_ME_MIN, ABOUT_ME_MAX)                          // 2
                && p.getStudyArea() != null                                                           // 3
                && p.getStudyLevel() != null                                                          // 4
                && sizeBetween(p.getSkills().size(), SKILLS_MIN, SKILLS_MAX)                          // 5
                && sizeBetween(p.getCollaborationGoals().size(), GOALS_MIN, GOALS_MAX)                // 6
                && sizeBetween(p.getAvailability().size(), AVAILABILITY_MIN, AVAILABILITY_MAX)        // 7
                && p.getWorkStyle() != null                                                           // 8
                && sizeBetween(p.getPreferredLanguages().size(), LANGUAGES_MIN, LANGUAGES_MAX)         // 9
                && validLatitude(p.getLatitude()) && validLongitude(p.getLongitude())                 // 10
                && p.getMaximumDistanceKm() != null
                && ALLOWED_DISTANCES_KM.contains(p.getMaximumDistanceKm())                            // 11
                && p.getCity() != null && !p.getCity().isBlank();                                     // 12
    }

    private static boolean sizeBetween(int size, int min, int max) {
        return size >= min && size <= max;
    }
}
