package ee.matchme.backend.controller;

import ee.matchme.backend.dto.BioResponse;
import ee.matchme.backend.dto.MeResponse;
import ee.matchme.backend.dto.ProfileResponse;
import ee.matchme.backend.dto.ProfileUpdateRequest;
import ee.matchme.backend.dto.SettingsResponse;
import ee.matchme.backend.security.AuthenticatedUser;
import ee.matchme.backend.service.ProfileService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** The authenticated user's own data. Only {@code GET /me} includes the email. */
@RestController
@RequestMapping("/me")
public class MeController {

    private final ProfileService profileService;

    public MeController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @GetMapping
    public MeResponse me(@AuthenticationPrincipal AuthenticatedUser user) {
        return profileService.me(user.id());
    }

    @GetMapping("/profile")
    public ProfileResponse profile(@AuthenticationPrincipal AuthenticatedUser user) {
        return profileService.profile(user.id());
    }

    @GetMapping("/bio")
    public BioResponse bio(@AuthenticationPrincipal AuthenticatedUser user) {
        return profileService.bio(user.id());
    }

    /** Private fields (location, search radius, priority fields) and the {@code profileComplete} flag. */
    @GetMapping("/settings")
    public SettingsResponse settings(@AuthenticationPrincipal AuthenticatedUser user) {
        return profileService.settings(user.id());
    }

    /** Replace the editable profile; returns the recomputed settings including {@code profileComplete}. */
    @PutMapping("/profile")
    public SettingsResponse updateProfile(@AuthenticationPrincipal AuthenticatedUser user,
                                          @RequestBody ProfileUpdateRequest request) {
        return profileService.update(user.id(), request);
    }
}
