package ee.matchme.backend.service;

import ee.matchme.backend.entity.ConnectionStatus;
import ee.matchme.backend.repository.ConnectionRepository;
import ee.matchme.backend.repository.UserRepository;
import ee.matchme.backend.util.UuidUtil;
import org.springframework.stereotype.Service;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * The 404 security guard for {@code /users/{id}}, {@code /users/{id}/profile} and
 * {@code /users/{id}/bio}.
 *
 * <p>A viewer may see a target only if the target is in the viewer's active recommendations, has a
 * PENDING request with the viewer (either direction) or is connected (ACCEPTED). Everything else, including ids that do not
 * exist and malformed ids, throws the same {@link NotFoundException}, so a caller can never tell "no
 * such user" from "not allowed".
 */
@Service
public class UserAccessService {

    private static final Set<ConnectionStatus> VISIBLE_STATUSES =
            EnumSet.of(ConnectionStatus.PENDING, ConnectionStatus.ACCEPTED);

    private final UserRepository userRepository;
    private final ConnectionRepository connectionRepository;
    private final RecommendationService recommendationService;

    public UserAccessService(UserRepository userRepository, ConnectionRepository connectionRepository,
                             RecommendationService recommendationService) {
        this.userRepository = userRepository;
        this.connectionRepository = connectionRepository;
        this.recommendationService = recommendationService;
    }

    /** Returns the target's id if {@code viewerId} may see it; otherwise throws {@link NotFoundException}. */
    public UUID requireViewable(UUID viewerId, String rawTargetId) {
        UUID targetId = UuidUtil.parse(rawTargetId).orElseThrow(NotFoundException::new);
        if (targetId.equals(viewerId)) {
            return targetId; // your own data
        }
        if (!userRepository.existsById(targetId)) {
            throw new NotFoundException();
        }
        boolean linked = connectionRepository.existsByUserOneIdAndUserTwoIdAndStatusIn(
                UuidUtil.lower(viewerId, targetId), UuidUtil.higher(viewerId, targetId), VISIBLE_STATUSES);
        if (linked || recommendationService.activeRecommendationIds(viewerId).contains(targetId)) {
            return targetId;
        }
        throw new NotFoundException();
    }
}
