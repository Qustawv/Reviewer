package ee.matchme.backend.dto;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;

import java.util.List;

/** {@code GET /lookups}: the fixed option lists the profile form needs. */
public record LookupsResponse(
        List<SkillOption> skills,
        List<CollaborationGoal> collaborationGoals,
        List<AvailabilitySlot> availabilitySlots,
        List<StudyArea> studyAreas,
        List<StudyLevel> studyLevels,
        List<WorkStyle> workStyles,
        List<PreferredLanguage> preferredLanguages,
        List<PriorityField> priorityFields,
        List<Integer> maximumDistanceKmOptions) {

    public record SkillOption(String code, String label) {
    }
}
