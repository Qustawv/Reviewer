package ee.matchme.backend.controller;

import ee.matchme.backend.dto.LookupsResponse;
import ee.matchme.backend.service.LookupService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LookupController {

    private final LookupService lookupService;

    public LookupController(LookupService lookupService) {
        this.lookupService = lookupService;
    }

    @GetMapping("/lookups")
    public LookupsResponse lookups() {
        return lookupService.lookups();
    }
}
