package ee.matchme.backend.dto;

public record AuthResponse(String token) {
}
