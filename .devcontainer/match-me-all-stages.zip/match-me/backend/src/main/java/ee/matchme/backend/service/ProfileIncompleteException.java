package ee.matchme.backend.service;

/** The profile completion gate: incomplete profiles cannot get recommendations or send requests. */
public class ProfileIncompleteException extends RuntimeException {

    public ProfileIncompleteException() {
        super("Complete your profile first");
    }
}
