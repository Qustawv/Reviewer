-- One row per user pair, whatever its state. The pair is stored in canonical order
-- (user_one_id < user_two_id, using PostgreSQL's unsigned byte-wise UUID ordering) so
-- (A,B) and (B,A) can never both exist. `requester_id` records who sent the request.
CREATE TABLE connections (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_one_id  UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    user_two_id  UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    requester_id UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    status       VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT connections_status         CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED', 'DISCONNECTED')),
    CONSTRAINT connections_ordered_pair   CHECK (user_one_id < user_two_id),
    CONSTRAINT connections_requester_pair CHECK (requester_id IN (user_one_id, user_two_id)),
    CONSTRAINT connections_pair_unique    UNIQUE (user_one_id, user_two_id)
);

-- "Not interested" marks: the dismissed user never appears in the dismisser's recommendations.
CREATE TABLE recommendation_dismissals (
    user_id           UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    dismissed_user_id UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, dismissed_user_id),
    CONSTRAINT recommendation_dismissals_not_self CHECK (user_id <> dismissed_user_id)
);
