-- Accounts. Profile data lives in `profiles` (V2).
CREATE TABLE users (
    id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    email         VARCHAR(255) NOT NULL,
    password_hash VARCHAR(100) NOT NULL, -- BCrypt (salted) hash, never the raw password
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT users_email_unique    UNIQUE (email),
    CONSTRAINT users_email_lowercase CHECK (email = lower(email))
);
