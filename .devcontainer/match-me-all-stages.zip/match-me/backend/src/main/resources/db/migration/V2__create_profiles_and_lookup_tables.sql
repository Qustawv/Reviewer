-- Fixed lookup tables -------------------------------------------------------------------------
CREATE TABLE skills (
    code  VARCHAR(40) PRIMARY KEY,
    label VARCHAR(80) NOT NULL
);

CREATE TABLE collaboration_goals (
    code  VARCHAR(30) PRIMARY KEY,
    label VARCHAR(80) NOT NULL
);

CREATE TABLE availability_slots (
    code  VARCHAR(30) PRIMARY KEY,
    label VARCHAR(80) NOT NULL
);

INSERT INTO skills (code, label) VALUES
    ('JAVA',               'Java'),
    ('PYTHON',             'Python'),
    ('JAVASCRIPT',         'JavaScript'),
    ('TYPESCRIPT',         'TypeScript'),
    ('REACT',              'React'),
    ('NODE_JS',            'Node.js'),
    ('SPRING_BOOT',        'Spring Boot'),
    ('SQL',                'SQL'),
    ('GIT',                'Git'),
    ('DOCKER',             'Docker'),
    ('LINUX',              'Linux'),
    ('HTML_CSS',           'HTML & CSS'),
    ('C_CPP',              'C / C++'),
    ('CSHARP',             'C#'),
    ('KOTLIN',             'Kotlin'),
    ('SWIFT',              'Swift'),
    ('GO',                 'Go'),
    ('RUST',               'Rust'),
    ('ALGORITHMS',         'Algorithms & data structures'),
    ('TESTING',            'Software testing'),
    ('MACHINE_LEARNING',   'Machine learning'),
    ('DATA_ANALYSIS',      'Data analysis'),
    ('NETWORK_SECURITY',   'Network security'),
    ('UI_UX_DESIGN',       'UI / UX design');

INSERT INTO collaboration_goals (code, label) VALUES
    ('STUDY_PARTNER',    'Study partner'),
    ('PROJECT_TEAMMATE', 'Project teammate'),
    ('CODE_REVIEW',      'Code review'),
    ('EXAM_PREPARATION', 'Exam preparation'),
    ('ACCOUNTABILITY',   'Accountability');

INSERT INTO availability_slots (code, label) VALUES
    ('WEEKDAY_MORNING',   'Weekday mornings'),
    ('WEEKDAY_AFTERNOON', 'Weekday afternoons'),
    ('WEEKDAY_EVENING',   'Weekday evenings'),
    ('WEEKEND_MORNING',   'Weekend mornings'),
    ('WEEKEND_AFTERNOON', 'Weekend afternoons'),
    ('WEEKEND_EVENING',   'Weekend evenings');

-- Profiles ------------------------------------------------------------------------------------
-- One row per user, created empty at registration and filled in over time. Every CHECK below
-- passes for NULL (draft profile); completeness of all 12 mandatory fields is computed by the
-- server into `profile_complete`.
CREATE TABLE profiles (
    user_id             UUID             PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
    display_name        VARCHAR(40),
    about_me            VARCHAR(500),
    study_area          VARCHAR(30),
    study_level         VARCHAR(20),
    work_style          VARCHAR(30),
    preferred_language  VARCHAR(20),
    latitude            DOUBLE PRECISION,
    longitude           DOUBLE PRECISION,
    maximum_distance_km INTEGER,
    city                VARCHAR(100),
    profile_image_url   VARCHAR(500),
    profile_complete    BOOLEAN          NOT NULL DEFAULT FALSE,
    updated_at          TIMESTAMPTZ      NOT NULL DEFAULT now(),

    CONSTRAINT profiles_display_name_len CHECK (char_length(display_name) BETWEEN 2 AND 40),
    CONSTRAINT profiles_about_me_len     CHECK (char_length(about_me) BETWEEN 30 AND 500),
    CONSTRAINT profiles_study_area       CHECK (study_area IN (
        'SOFTWARE_DEVELOPMENT', 'WEB_DEVELOPMENT', 'DATA_SCIENCE', 'CYBER_SECURITY',
        'MOBILE_DEVELOPMENT', 'DESIGN', 'OTHER')),
    CONSTRAINT profiles_study_level      CHECK (study_level IN ('BEGINNER', 'INTERMEDIATE', 'ADVANCED')),
    CONSTRAINT profiles_work_style       CHECK (work_style IN (
        'STRUCTURED', 'FLEXIBLE', 'PAIR_PROGRAMMING', 'INDEPENDENT_WITH_CHECK_INS')),
    CONSTRAINT profiles_language         CHECK (preferred_language IN ('ENGLISH', 'ESTONIAN', 'RUSSIAN', 'OTHER')),
    CONSTRAINT profiles_latitude_range   CHECK (latitude BETWEEN -90 AND 90),
    CONSTRAINT profiles_longitude_range  CHECK (longitude BETWEEN -180 AND 180),
    CONSTRAINT profiles_max_distance     CHECK (maximum_distance_km IN (5, 10, 25, 50, 100)),
    CONSTRAINT profiles_image_url_scheme CHECK (profile_image_url ~ '^https?://')
);

-- Selection (join) tables. Count limits (<= 8 skills, <= 3 goals, <= 14 slots, <= 2 priority
-- fields) are enforced by the service layer.
CREATE TABLE profile_skills (
    user_id    UUID        NOT NULL REFERENCES profiles (user_id) ON DELETE CASCADE,
    skill_code VARCHAR(40) NOT NULL REFERENCES skills (code),
    PRIMARY KEY (user_id, skill_code)
);

CREATE TABLE profile_collaboration_goals (
    user_id   UUID        NOT NULL REFERENCES profiles (user_id) ON DELETE CASCADE,
    goal_code VARCHAR(30) NOT NULL REFERENCES collaboration_goals (code),
    PRIMARY KEY (user_id, goal_code)
);

CREATE TABLE profile_availability (
    user_id   UUID        NOT NULL REFERENCES profiles (user_id) ON DELETE CASCADE,
    slot_code VARCHAR(30) NOT NULL REFERENCES availability_slots (code),
    PRIMARY KEY (user_id, slot_code)
);

CREATE TABLE profile_priority_fields (
    user_id    UUID        NOT NULL REFERENCES profiles (user_id) ON DELETE CASCADE,
    field_code VARCHAR(30) NOT NULL,
    PRIMARY KEY (user_id, field_code),
    CONSTRAINT profile_priority_fields_code CHECK (field_code IN (
        'SKILLS', 'COLLABORATION_GOALS', 'AVAILABILITY', 'STUDY_AREA', 'WORK_STYLE', 'STUDY_LEVEL'))
);
