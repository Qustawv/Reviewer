-- Recommendation candidate scan: only complete profiles are ever candidates.
CREATE INDEX idx_profiles_complete_language ON profiles (preferred_language) WHERE profile_complete;
CREATE INDEX idx_profiles_updated_at        ON profiles (updated_at DESC);

-- Overlap lookups (shared goals / slots / skills) from the "other side".
CREATE INDEX idx_profile_goals_goal         ON profile_collaboration_goals (goal_code, user_id);
CREATE INDEX idx_profile_availability_slot  ON profile_availability (slot_code, user_id);
CREATE INDEX idx_profile_skills_skill       ON profile_skills (skill_code, user_id);

-- "All connections of user X" (the unique (one,two) index already serves lookups by pair).
CREATE INDEX idx_connections_user_one       ON connections (user_one_id, status);
CREATE INDEX idx_connections_user_two       ON connections (user_two_id, status);
CREATE INDEX idx_dismissals_dismissed       ON recommendation_dismissals (dismissed_user_id);

-- Chat history pages and unread counters.
CREATE INDEX idx_messages_chat_created      ON messages (chat_id, created_at, id);
CREATE INDEX idx_messages_unread            ON messages (chat_id, sender_id) WHERE read_at IS NULL;
