-- A chat belongs 1-to-1 to a connection and may only exist for an ACCEPTED one.
CREATE TABLE chats (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID        NOT NULL UNIQUE REFERENCES connections (id) ON DELETE CASCADE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A CHECK constraint cannot look at another table, so a trigger guards chat creation.
CREATE FUNCTION chats_require_accepted_connection() RETURNS trigger AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM connections WHERE id = NEW.connection_id AND status = 'ACCEPTED') THEN
        RAISE EXCEPTION 'chat requires an ACCEPTED connection (connection %)', NEW.connection_id
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER chats_require_accepted_connection_trg
    BEFORE INSERT ON chats
    FOR EACH ROW EXECUTE FUNCTION chats_require_accepted_connection();

CREATE TABLE messages (
    id         UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id    UUID          NOT NULL REFERENCES chats (id) ON DELETE CASCADE,
    sender_id  UUID          NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    content    VARCHAR(2000) NOT NULL,
    created_at TIMESTAMPTZ   NOT NULL DEFAULT now(),
    read_at    TIMESTAMPTZ,  -- NULL = unread by the recipient
    CONSTRAINT messages_content_not_blank CHECK (char_length(btrim(content)) > 0)
);
