-- A profile can now list several preferred languages (1-4) instead of exactly one.
-- Existing single-language profiles are carried over unchanged.

CREATE TABLE profile_languages (
    user_id       UUID        NOT NULL REFERENCES profiles (user_id) ON DELETE CASCADE,
    language_code VARCHAR(20) NOT NULL,
    PRIMARY KEY (user_id, language_code),
    CONSTRAINT profile_languages_code CHECK (language_code IN ('ENGLISH', 'ESTONIAN', 'RUSSIAN', 'OTHER'))
);

INSERT INTO profile_languages (user_id, language_code)
SELECT user_id, preferred_language FROM profiles WHERE preferred_language IS NOT NULL;

DROP INDEX idx_profiles_complete_language;
ALTER TABLE profiles DROP CONSTRAINT profiles_language;
ALTER TABLE profiles DROP COLUMN preferred_language;

-- Overlap lookups from the "other side", like the other selection tables.
CREATE INDEX idx_profile_languages_language ON profile_languages (language_code, user_id);
