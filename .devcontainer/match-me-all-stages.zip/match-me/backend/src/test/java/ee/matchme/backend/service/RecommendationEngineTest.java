package ee.matchme.backend.service;

import ee.matchme.backend.entity.AvailabilitySlot;
import ee.matchme.backend.entity.CollaborationGoal;
import ee.matchme.backend.entity.PreferredLanguage;
import ee.matchme.backend.entity.PriorityField;
import ee.matchme.backend.entity.StudyArea;
import ee.matchme.backend.entity.StudyLevel;
import ee.matchme.backend.entity.WorkStyle;
import ee.matchme.backend.service.RecommendationEngine.Scored;
import ee.matchme.backend.util.GeoUtil;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RecommendationEngineTest {

    private static final double EPS = 1e-9;
    private static final Instant T0 = Instant.parse("2026-01-01T00:00:00Z");
    private static final double LAT = 59.437;
    private static final double LON = 24.7536;

    /** Mutable builder; defaults describe a profile that matches itself perfectly. */
    static final class B {
        UUID id = UUID.randomUUID();
        boolean complete = true;
        Set<PreferredLanguage> languages = Set.of(PreferredLanguage.ENGLISH);
        StudyArea area = StudyArea.WEB_DEVELOPMENT;
        StudyLevel level = StudyLevel.INTERMEDIATE;
        WorkStyle style = WorkStyle.FLEXIBLE;
        double lat = LAT;
        double lon = LON;
        int maxKm = 100;
        Set<String> skills = Set.of("JAVA", "REACT");
        Set<CollaborationGoal> goals = Set.of(CollaborationGoal.STUDY_PARTNER, CollaborationGoal.CODE_REVIEW);
        Set<AvailabilitySlot> slots = Set.of(AvailabilitySlot.WEEKDAY_EVENING, AvailabilitySlot.WEEKEND_MORNING);
        Set<PriorityField> priorities = Set.of();
        Instant updatedAt = T0;

        B id(UUID v) { id = v; return this; }
        B complete(boolean v) { complete = v; return this; }
        B languages(PreferredLanguage... v) { languages = Set.of(v); return this; }
        B area(StudyArea v) { area = v; return this; }
        B level(StudyLevel v) { level = v; return this; }
        B style(WorkStyle v) { style = v; return this; }
        B maxKm(int v) { maxKm = v; return this; }
        B skills(String... v) { skills = Set.of(v); return this; }
        B goals(CollaborationGoal... v) { goals = Set.of(v); return this; }
        B slots(AvailabilitySlot... v) { slots = Set.of(v); return this; }
        B priorities(PriorityField... v) { priorities = Set.of(v); return this; }
        B updatedAt(Instant v) { updatedAt = v; return this; }
        /** Placed {@code km} due north of the default location (exact on a meridian). */
        B northKm(double km) { lat = LAT + Math.toDegrees(km / GeoUtil.EARTH_RADIUS_KM); return this; }

        RecommendationProfile build() {
            return new RecommendationProfile(id, complete, languages, area, level, style, lat, lon, maxKm,
                    skills, goals, slots, priorities, updatedAt);
        }
    }

    private static B b() {
        return new B();
    }

    private static final Set<UUID> NONE = Set.of();

    private static double score(B me, B c) {
        return RecommendationEngine.score(me.build(), c.build());
    }

    private static boolean eligible(B me, B c) {
        return RecommendationEngine.isEligible(me.build(), c.build(), NONE);
    }

    // ---- hard filters --------------------------------------------------------------------

    @Test
    void identicalProfilesAreEligibleAndScoreExactly100() {
        assertTrue(eligible(b(), b()));
        assertEquals(100.0, score(b(), b()), EPS);
    }

    @Test
    void candidateWithIncompleteProfileIsExcluded() {
        assertFalse(eligible(b(), b().complete(false)));
    }

    @Test
    void userIsNeverRecommendedToThemselves() {
        UUID id = UUID.randomUUID();
        assertFalse(RecommendationEngine.isEligible(b().id(id).build(), b().id(id).build(), NONE));
    }

    @Test
    void dismissedAndRelatedUsersAreExcluded() {
        B c = b();
        assertFalse(RecommendationEngine.isEligible(b().build(), c.build(), Set.of(c.id)));
        assertTrue(RecommendationEngine.isEligible(b().build(), c.build(), Set.of(UUID.randomUUID())));
    }

    @Test
    void noSharedPreferredLanguageIsExcluded() {
        assertFalse(eligible(b(), b().languages(PreferredLanguage.ESTONIAN)));
        assertFalse(eligible(b().languages(PreferredLanguage.ENGLISH, PreferredLanguage.ESTONIAN),
                b().languages(PreferredLanguage.RUSSIAN, PreferredLanguage.OTHER)));
    }

    @Test
    void oneSharedLanguageIsEnoughWhenSeveralAreListed() {
        assertTrue(eligible(b().languages(PreferredLanguage.ENGLISH),
                b().languages(PreferredLanguage.ESTONIAN, PreferredLanguage.ENGLISH)));
        assertTrue(eligible(b().languages(PreferredLanguage.RUSSIAN, PreferredLanguage.ESTONIAN),
                b().languages(PreferredLanguage.ESTONIAN)));
    }

    @Test
    void languagesDoNotChangeTheScore() {
        double single = RecommendationEngine.score(b().build(), b().build());
        double several = RecommendationEngine.score(b().languages(PreferredLanguage.ENGLISH, PreferredLanguage.RUSSIAN).build(),
                b().languages(PreferredLanguage.ENGLISH, PreferredLanguage.ESTONIAN, PreferredLanguage.OTHER).build());
        assertEquals(single, several, 0.0);
    }

    @Test
    void zeroSharedGoalsIsExcluded() {
        assertFalse(eligible(b().goals(CollaborationGoal.STUDY_PARTNER), b().goals(CollaborationGoal.ACCOUNTABILITY)));
        assertTrue(eligible(b().goals(CollaborationGoal.STUDY_PARTNER),
                b().goals(CollaborationGoal.STUDY_PARTNER, CollaborationGoal.ACCOUNTABILITY)));
    }

    @Test
    void zeroOverlappingAvailabilityIsExcluded() {
        assertFalse(eligible(b().slots(AvailabilitySlot.WEEKDAY_MORNING), b().slots(AvailabilitySlot.WEEKEND_EVENING)));
    }

    @Test
    void distanceMustBeWithinTheSmallerOfBothRadii() {
        // 10 km apart: fine with a 25 km radius on both sides ...
        assertTrue(eligible(b().maxKm(25), b().maxKm(25).northKm(10)));
        // ... but not if either side only accepts 5 km, whichever side that is.
        assertFalse(eligible(b().maxKm(100), b().maxKm(5).northKm(10)));
        assertFalse(eligible(b().maxKm(5), b().maxKm(100).northKm(10)));
        assertEquals(5, RecommendationEngine.radiusKm(b().maxKm(100).build(), b().maxKm(5).build()));
    }

    // ---- score components ----------------------------------------------------------------

    @Test
    void goalsAndSlotsAreProportionalToMyOwnCounts() {
        assertEquals(85.0, score(b(), b().goals(CollaborationGoal.STUDY_PARTNER)), EPS);       // 15/30
        assertEquals(87.5, score(b(), b().slots(AvailabilitySlot.WEEKDAY_EVENING)), EPS);      // 12.5/25
    }

    @Test
    void skillsAreProportionalToMySkillsAndExtrasAreNotPenalised() {
        assertEquals(90.0, score(b(), b().skills("JAVA")), EPS);                   // 10/20
        assertEquals(80.0, score(b(), b().skills("SQL")), EPS);                    // 0/20
        assertEquals(100.0, score(b(), b().skills("JAVA", "REACT", "SQL", "GIT")), EPS);
    }

    @Test
    void studyAreaPoints() {
        assertEquals(96.0, score(b(), b().area(StudyArea.SOFTWARE_DEVELOPMENT)), EPS);   // related: 6
        assertEquals(96.0, score(b().area(StudyArea.SOFTWARE_DEVELOPMENT), b()), EPS);   // symmetric
        assertEquals(90.0, score(b(), b().area(StudyArea.DESIGN)), EPS);                 // unrelated: 0
        assertEquals(90.0, score(b().area(StudyArea.DATA_SCIENCE), b().area(StudyArea.CYBER_SECURITY)), EPS);
    }

    @Test
    void studyLevelPoints() {
        assertEquals(98.0, score(b(), b().level(StudyLevel.ADVANCED)), EPS);                        // adjacent: 3
        assertEquals(95.0, score(b().level(StudyLevel.BEGINNER), b().level(StudyLevel.ADVANCED)), EPS); // far: 0
    }

    @Test
    void workStylePoints() {
        assertEquals(98.0, score(b(), b().style(WorkStyle.STRUCTURED)), EPS);                       // flexible: 3
        assertEquals(98.0, score(b().style(WorkStyle.STRUCTURED), b().style(WorkStyle.INDEPENDENT_WITH_CHECK_INS)), EPS);
        assertEquals(95.0, score(b().style(WorkStyle.STRUCTURED), b().style(WorkStyle.PAIR_PROGRAMMING)), EPS);
    }

    @Test
    void proximityTiersUseTheSmallerRadius() {
        assertEquals(100.0, score(b(), b().northKm(24.9)), EPS);   // <= 25% of 100 km
        assertEquals(98.0, score(b(), b().northKm(25.1)), EPS);    // <= 50%
        assertEquals(98.0, score(b(), b().northKm(49.9)), EPS);
        assertEquals(96.0, score(b(), b().northKm(50.1)), EPS);    // otherwise 1 point
        // The other user's 40 km radius shrinks the radius: 19.9 km is just under 50% of it -> 3 points.
        assertEquals(98.0, score(b(), b().maxKm(40).northKm(19.9)), EPS);
    }

    // ---- priority bonus ------------------------------------------------------------------

    @Test
    void priorityBonusIsFivePerMatchingFieldAndOnlyForMatches() {
        // Weak candidate: no skills, unrelated area -> base 70, so nothing is capped yet.
        B weak = b().skills("SQL").area(StudyArea.DESIGN);
        assertEquals(70.0, score(b().priorities(PriorityField.SKILLS, PriorityField.STUDY_AREA), weak), EPS);

        // Skills now fully shared (base 90) and the first priority matches: +5.
        B skills = b().area(StudyArea.DESIGN);
        assertEquals(95.0, score(b().priorities(PriorityField.SKILLS, PriorityField.STUDY_AREA), skills), EPS);

        // Exactly half of my skills shared counts as a match (base 80 -> 85).
        B half = b().skills("JAVA").area(StudyArea.DESIGN);
        assertEquals(85.0, score(b().priorities(PriorityField.SKILLS), half), EPS);
    }

    @Test
    void relatedAreaAndCompatibleStyleCountAsPriorityMatches() {
        B c = b().skills("SQL").area(StudyArea.SOFTWARE_DEVELOPMENT).style(WorkStyle.STRUCTURED);
        // base = 30+25+0+6+5+3+5 = 74, +10 for both matching priorities
        assertEquals(84.0, score(b().priorities(PriorityField.STUDY_AREA, PriorityField.WORK_STYLE), c), EPS);
    }

    @Test
    void totalIsCappedAt100() {
        assertEquals(100.0, score(b().priorities(PriorityField.SKILLS, PriorityField.AVAILABILITY), b()), EPS);
    }

    // ---- cutoff, ranking, arrangement ----------------------------------------------------

    /** Goals 30 + slots 25 + proximity => 60 at best, because every other dimension scores 0. */
    private static B sixtyPointMe() {
        return b().area(StudyArea.WEB_DEVELOPMENT).level(StudyLevel.BEGINNER).style(WorkStyle.STRUCTURED);
    }

    private static B sixtyPointCandidate() {
        return b().area(StudyArea.DESIGN).level(StudyLevel.ADVANCED).style(WorkStyle.PAIR_PROGRAMMING).skills("SQL");
    }

    @Test
    void cutoffIsInclusiveAtSixty() {
        assertEquals(60.0, score(sixtyPointMe(), sixtyPointCandidate()), EPS);
        assertTrue(RecommendationEngine.evaluate(sixtyPointMe().build(), sixtyPointCandidate().build(), NONE).isPresent());

        // Proximity tier drops from 5 to 3 points -> 58 -> eliminated as a weak match.
        B farther = sixtyPointCandidate().northKm(40);
        assertEquals(58.0, score(sixtyPointMe(), farther), EPS);
        assertFalse(RecommendationEngine.evaluate(sixtyPointMe().build(), farther.build(), NONE).isPresent());
    }

    @Test
    void rankingIsScoreThenDistanceThenMostRecentlyUpdated() {
        B best = b();                                                                  // 100
        B near = b().area(StudyArea.DESIGN).northKm(5).updatedAt(T0);                  // 90, 5 km, old
        B nearNewer = b().area(StudyArea.DESIGN).northKm(5).updatedAt(T0.plusSeconds(86_400)); // 90, 5 km, new
        B far = b().area(StudyArea.DESIGN).northKm(10);                                // 90, 10 km

        List<Scored> ranked = RecommendationEngine.rank(b().build(),
                List.of(far.build(), near.build(), best.build(), nearNewer.build()), NONE);

        assertEquals(List.of(best.id, nearNewer.id, near.id, far.id),
                ranked.stream().map(Scored::userId).toList());
    }

    @Test
    void rankKeepsOnlyTheTop20() {
        List<RecommendationProfile> candidates = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            candidates.add(b().northKm(i * 0.1).build());
        }
        assertEquals(20, RecommendationEngine.rank(b().build(), candidates, NONE).size());
    }

    private static List<Scored> synthetic(int n) {
        List<Scored> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            list.add(new Scored(b().id(new UUID(0, i)).build(), 100.0 - i * 0.1, i));
        }
        return list;
    }

    private static UUID uuid(int i) {
        return new UUID(0, i);
    }

    @Test
    void arrangePinsTop3AndDrawsTheRestFromRanks4To20() {
        List<Scored> ranked = synthetic(30); // arrange() must ignore everything past rank 20
        Set<List<UUID>> distinctOrders = new HashSet<>();
        for (long seed = 0; seed < 300; seed++) {
            List<UUID> out = RecommendationEngine.arrange(ranked, new Random(seed));
            assertEquals(10, out.size());
            assertEquals(List.of(uuid(0), uuid(1), uuid(2)), out.subList(0, 3));
            assertEquals(10, new HashSet<>(out).size()); // no duplicates
            for (UUID id : out.subList(3, 10)) {
                long rank = id.getLeastSignificantBits() + 1; // 1-based rank
                assertTrue(rank >= 4 && rank <= 20, "rank " + rank + " must come from 4..20");
            }
            distinctOrders.add(out);
        }
        assertTrue(distinctOrders.size() > 50, "ranks 4-20 should actually be randomised");
    }

    @Test
    void arrangeWithFewCandidates() {
        assertEquals(List.of(), RecommendationEngine.arrange(synthetic(0), new Random(1)));
        assertEquals(List.of(uuid(0)), RecommendationEngine.arrange(synthetic(1), new Random(1)));
        assertEquals(List.of(uuid(0), uuid(1), uuid(2)), RecommendationEngine.arrange(synthetic(3), new Random(1)));

        List<UUID> five = RecommendationEngine.arrange(synthetic(5), new Random(1));
        assertEquals(List.of(uuid(0), uuid(1), uuid(2)), five.subList(0, 3));
        assertEquals(Set.of(uuid(3), uuid(4)), new HashSet<>(five.subList(3, 5)));

        List<UUID> ten = RecommendationEngine.arrange(synthetic(10), new Random(1));
        assertEquals(10, ten.size());
        List<UUID> eleven = RecommendationEngine.arrange(synthetic(11), new Random(1));
        assertEquals(10, eleven.size());
    }

    @Test
    void recommendRunsTheWholePipeline() {
        RecommendationProfile me = b().build();
        List<RecommendationProfile> candidates = List.of(
                b().build(),                                         // eligible, 100
                b().languages(PreferredLanguage.RUSSIAN).build(),     // wrong language
                b().complete(false).build(),                         // incomplete
                b().goals(CollaborationGoal.ACCOUNTABILITY).build(), // no shared goal
                sixtyPointCandidate().build());                      // scores 66 against this me -> eligible
        List<UUID> out = RecommendationEngine.recommend(me, candidates, NONE, new Random(7));
        assertEquals(2, out.size());
        assertEquals(candidates.get(0).userId(), out.get(0));
    }

    // ---- geometry ------------------------------------------------------------------------

    @Test
    void haversineMatchesKnownDistances() {
        assertEquals(0.0, GeoUtil.haversineKm(LAT, LON, LAT, LON), EPS);
        assertEquals(111.195, GeoUtil.haversineKm(0, 0, 1, 0), 0.01);          // 1 degree of latitude
        double tallinnTartu = GeoUtil.haversineKm(59.437, 24.7536, 58.378, 26.729);
        assertTrue(tallinnTartu > 160 && tallinnTartu < 170, "Tallinn-Tartu was " + tallinnTartu);
        assertEquals(GeoUtil.haversineKm(10, 20, 30, 40), GeoUtil.haversineKm(30, 40, 10, 20), EPS);
    }
}
