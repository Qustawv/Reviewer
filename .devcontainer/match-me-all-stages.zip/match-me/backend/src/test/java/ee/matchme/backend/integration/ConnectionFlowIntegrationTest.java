package ee.matchme.backend.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Recommendations -> request -> accept -> chat history -> disconnect, against a real PostgreSQL 16. */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Testcontainers(disabledWithoutDocker = true)
class ConnectionFlowIntegrationTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper json;

    record Account(UUID id, String token) {
    }

    private Account register() throws Exception {
        String body = mvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of(
                                "email", "u-" + UUID.randomUUID() + "@example.ee", "password", "correct horse battery"))))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        String token = json.readTree(body).get("token").asText();
        String me = mvc.perform(MockMvcRequestBuilders.get("/me").header("Authorization", "Bearer " + token))
                .andReturn().getResponse().getContentAsString();
        return new Account(UUID.fromString(json.readTree(me).get("id").asText()), token);
    }

    private ResultActions call(String method, Account who, String path) throws Exception {
        var b = switch (method) {
            case "POST" -> MockMvcRequestBuilders.post(path);
            case "DELETE" -> MockMvcRequestBuilders.delete(path);
            default -> MockMvcRequestBuilders.get(path);
        };
        return mvc.perform(b.header("Authorization", "Bearer " + who.token()));
    }

    private void completeProfile(Account who) throws Exception {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("displayName", "Student");
        m.put("aboutMe", "Second-year student who loves pair programming and exam prep groups.");
        m.put("studyArea", "WEB_DEVELOPMENT");
        m.put("studyLevel", "INTERMEDIATE");
        m.put("skills", List.of("JAVA", "REACT"));
        m.put("collaborationGoals", List.of("STUDY_PARTNER"));
        m.put("availability", List.of("WEEKDAY_EVENING"));
        m.put("workStyle", "FLEXIBLE");
        m.put("preferredLanguages", List.of("ENGLISH"));
        m.put("latitude", 59.437);
        m.put("longitude", 24.7536);
        m.put("maximumDistanceKm", 25);
        m.put("city", "Tallinn");
        m.put("priorityFields", List.of("SKILLS"));
        mvc.perform(MockMvcRequestBuilders.put("/me/profile")
                        .header("Authorization", "Bearer " + who.token())
                        .contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(m)))
                .andExpect(status().isOk()).andExpect(jsonPath("$.profileComplete").value(true));
    }

    private List<String> idList(String path, Account who) throws Exception {
        JsonNode n = json.readTree(call("GET", who, path).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString());
        List<String> out = new java.util.ArrayList<>();
        n.forEach(x -> out.add(x.asText()));
        return out;
    }

    @Test
    void recommendationsAreGatedByProfileCompletion() throws Exception {
        Account a = register();
        call("GET", a, "/recommendations").andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error").value("profile_incomplete"));
        call("POST", a, "/connections/requests/" + UUID.randomUUID()).andExpect(status().isForbidden());
    }

    @Test
    void fullLifecycle() throws Exception {
        Account a = register();
        Account b = register();
        Account stranger = register();
        completeProfile(a);
        completeProfile(b);
        completeProfile(stranger);

        // b shows up for a; at most 10 ids, plain strings.
        List<String> recs = idList("/recommendations", a);
        assertThat(recs).contains(b.id().toString()).hasSizeLessThanOrEqualTo(10);

        // Only recommended users can be requested: an unknown id is a 404.
        call("POST", a, "/connections/requests/" + UUID.randomUUID()).andExpect(status().isNotFound());
        call("POST", a, "/connections/requests/not-a-uuid").andExpect(status().isNotFound());

        call("POST", a, "/connections/requests/" + b.id()).andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("PENDING"));
        call("POST", a, "/connections/requests/" + b.id()).andExpect(status().isConflict());

        assertThat(idList("/connections/requests/outgoing", a)).containsExactly(b.id().toString());
        assertThat(idList("/connections/requests/incoming", b)).containsExactly(a.id().toString());

        // The sender cannot accept their own request; a third party cannot either.
        call("POST", a, "/connections/requests/" + b.id() + "/accept").andExpect(status().isNotFound());
        call("POST", stranger, "/connections/requests/" + a.id() + "/accept").andExpect(status().isNotFound());

        String accepted = call("POST", b, "/connections/requests/" + a.id() + "/accept")
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("ACCEPTED"))
                .andReturn().getResponse().getContentAsString();
        String connectionId = json.readTree(accepted).get("connectionId").asText();

        assertThat(idList("/connections", a)).containsExactly(b.id().toString());
        assertThat(idList("/connections", b)).containsExactly(a.id().toString());
        // Accepted pairs are no longer recommended.
        assertThat(idList("/recommendations", a)).doesNotContain(b.id().toString());

        // The chat exists for both participants, and only for them.
        call("GET", a, "/chats").andExpect(status().isOk())
                .andExpect(jsonPath("$[0].connectionId").value(connectionId))
                .andExpect(jsonPath("$[0].userId").value(b.id().toString()))
                .andExpect(jsonPath("$[0].unreadCount").value(0));
        call("GET", b, "/chats/" + connectionId + "/messages").andExpect(status().isOk())
                .andExpect(jsonPath("$.messages").isEmpty()).andExpect(jsonPath("$.hasOlder").value(false));
        String forbidden = call("GET", stranger, "/chats/" + connectionId + "/messages")
                .andExpect(status().isNotFound()).andReturn().getResponse().getContentAsString();
        String missing = call("GET", stranger, "/chats/" + UUID.randomUUID() + "/messages")
                .andExpect(status().isNotFound()).andReturn().getResponse().getContentAsString();
        assertThat(forbidden).isEqualTo(missing);

        // Disconnect: the pair never comes back, and the chat disappears from the list.
        call("DELETE", a, "/connections/" + b.id()).andExpect(status().isNoContent());
        assertThat(idList("/connections", a)).isEmpty();
        assertThat(idList("/recommendations", a)).doesNotContain(b.id().toString());
        call("GET", a, "/chats").andExpect(jsonPath("$").isEmpty());
        call("POST", a, "/connections/requests/" + b.id()).andExpect(status().isNotFound());
    }

    @Test
    void dismissedUsersDisappearForever() throws Exception {
        Account a = register();
        Account b = register();
        completeProfile(a);
        completeProfile(b);
        assertThat(idList("/recommendations", a)).contains(b.id().toString());
        call("POST", a, "/recommendations/" + b.id() + "/dismiss").andExpect(status().isNoContent());
        assertThat(idList("/recommendations", a)).doesNotContain(b.id().toString());
        call("POST", a, "/recommendations/not-a-uuid/dismiss").andExpect(status().isNotFound());
        assertThat(idList("/connections", a)).isEmpty();
    }
}
