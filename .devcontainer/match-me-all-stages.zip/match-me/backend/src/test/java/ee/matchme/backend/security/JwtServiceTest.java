package ee.matchme.backend.security;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JwtServiceTest {

    private static final String SECRET = "0123456789abcdef0123456789abcdef";

    private final JwtService service = new JwtService(new JwtProperties(SECRET, 60));

    @Test
    void roundTripsTheUserId() {
        UUID id = UUID.randomUUID();
        assertThat(service.parse(service.issueToken(id))).contains(id);
    }

    @Test
    void rejectsGarbageAndBlank() {
        assertThat(service.parse("garbage")).isEmpty();
        assertThat(service.parse("")).isEmpty();
        assertThat(service.parse("a.b.c")).isEmpty();
    }

    @Test
    void rejectsTokenSignedWithAnotherSecret() {
        JwtService other = new JwtService(new JwtProperties("ffffffffffffffffffffffffffffffff", 60));
        assertThat(service.parse(other.issueToken(UUID.randomUUID()))).isEmpty();
    }

    @Test
    void rejectsPayloadSwappedOntoAnotherUsersSignature() {
        String[] a = service.issueToken(UUID.randomUUID()).split("\\.");
        String[] b = service.issueToken(UUID.randomUUID()).split("\\.");
        // Header and signature of A with the payload of B: the signature no longer matches.
        assertThat(service.parse(a[0] + "." + b[1] + "." + a[2])).isEmpty();
    }

    @Test
    void rejectsExpiredToken() {
        JwtService expired = new JwtService(new JwtProperties(SECRET, -1));
        assertThat(service.parse(expired.issueToken(UUID.randomUUID()))).isEmpty();
    }

    @Test
    void rejectsUnsignedAlgNoneToken() {
        Base64.Encoder enc = Base64.getUrlEncoder().withoutPadding();
        String header = enc.encodeToString("{\"alg\":\"none\"}".getBytes(StandardCharsets.UTF_8));
        String payload = enc.encodeToString(
                ("{\"sub\":\"" + UUID.randomUUID() + "\"}").getBytes(StandardCharsets.UTF_8));
        assertThat(service.parse(header + "." + payload + ".")).isEmpty();
    }

    @Test
    void refusesToStartWithAWeakOrMissingSecret() {
        assertThatThrownBy(() -> new JwtService(new JwtProperties("short", 60)))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("JWT_SECRET");
        assertThatThrownBy(() -> new JwtService(new JwtProperties("", 60)))
                .isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new JwtService(new JwtProperties(null, 60)))
                .isInstanceOf(IllegalStateException.class);
    }
}
