package ee.matchme.backend.websocket;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PresenceRegistryTest {

    private final UUID alice = UUID.randomUUID();
    private final UUID bob = UUID.randomUUID();

    @Test
    void firstSessionBringsAUserOnlineAndLastOneTakesThemOffline() {
        PresenceRegistry registry = new PresenceRegistry();
        assertFalse(registry.isOnline(alice));

        assertTrue(registry.sessionOpened(alice, "tab-1"));   // came online
        assertFalse(registry.sessionOpened(alice, "tab-2"));  // already online
        assertTrue(registry.isOnline(alice));

        assertFalse(registry.sessionClosed(alice, "tab-1"));  // still has tab-2
        assertTrue(registry.isOnline(alice));
        assertTrue(registry.sessionClosed(alice, "tab-2"));   // went offline
        assertFalse(registry.isOnline(alice));
    }

    @Test
    void closingAnUnknownSessionChangesNothing() {
        PresenceRegistry registry = new PresenceRegistry();
        assertFalse(registry.sessionClosed(alice, "ghost"));
        registry.sessionOpened(alice, "tab-1");
        assertFalse(registry.sessionClosed(alice, "ghost"));
        assertTrue(registry.isOnline(alice));
    }

    @Test
    void reopeningAfterOfflineComesOnlineAgain() {
        PresenceRegistry registry = new PresenceRegistry();
        registry.sessionOpened(alice, "a");
        registry.sessionClosed(alice, "a");
        assertTrue(registry.sessionOpened(alice, "b"));
    }

    @Test
    void onlineAmongFiltersTheGivenUsers() {
        PresenceRegistry registry = new PresenceRegistry();
        registry.sessionOpened(alice, "a");
        assertEquals(List.of(alice), registry.onlineAmong(List.of(alice, bob)));
        assertEquals(List.of(), registry.onlineAmong(List.of(bob)));
    }
}
