package ee.matchme.backend.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.messaging.converter.StringMessageConverter;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Real STOMP over a real WebSocket: send, receive, unread counters, typing, presence, forgery. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@Testcontainers(disabledWithoutDocker = true)
class ChatStompIntegrationTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");

    @LocalServerPort
    int port;
    @Autowired
    TestRestTemplate rest;
    @Autowired
    ObjectMapper json;

    record Account(UUID id, String token) {
    }

    private JsonNode call(HttpMethod method, String path, String token, Object body) throws Exception {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        if (token != null) h.setBearerAuth(token);
        String res = rest.exchange(path, method, new HttpEntity<>(body, h), String.class).getBody();
        return res == null || res.isBlank() ? json.createObjectNode() : json.readTree(res);
    }

    private Account register() throws Exception {
        String token = call(HttpMethod.POST, "/auth/register", null,
                Map.of("email", "u-" + UUID.randomUUID() + "@example.ee", "password", "correct horse battery"))
                .get("token").asText();
        UUID id = UUID.fromString(call(HttpMethod.GET, "/me", token, null).get("id").asText());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("displayName", "Student");
        m.put("aboutMe", "Second-year student who loves pair programming and exam prep groups.");
        m.put("studyArea", "WEB_DEVELOPMENT");
        m.put("studyLevel", "INTERMEDIATE");
        m.put("skills", List.of("JAVA"));
        m.put("collaborationGoals", List.of("STUDY_PARTNER"));
        m.put("availability", List.of("WEEKDAY_EVENING"));
        m.put("workStyle", "FLEXIBLE");
        m.put("preferredLanguages", List.of("ENGLISH"));
        m.put("latitude", 59.437);
        m.put("longitude", 24.7536);
        m.put("maximumDistanceKm", 25);
        m.put("city", "Tallinn");
        m.put("priorityFields", List.of("SKILLS"));
        call(HttpMethod.PUT, "/me/profile", token, m);
        return new Account(id, token);
    }

    private StompSession connect(Account who) throws Exception {
        WebSocketStompClient client = new WebSocketStompClient(new StandardWebSocketClient());
        client.setMessageConverter(new StringMessageConverter());
        StompHeaders headers = new StompHeaders();
        headers.add("Authorization", "Bearer " + who.token());
        return client.connectAsync("ws://localhost:" + port + "/ws", new WebSocketHttpHeaders(), headers,
                new StompSessionHandlerAdapter() { }).get(10, TimeUnit.SECONDS);
    }

    private BlockingQueue<JsonNode> subscribe(StompSession s, String destination) {
        BlockingQueue<JsonNode> queue = new LinkedBlockingQueue<>();
        s.subscribe(destination, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return String.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                try {
                    queue.add(json.readTree((String) payload));
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }
            }
        });
        return queue;
    }

    private void send(StompSession s, String destination, String body) {
        StompHeaders h = new StompHeaders();
        h.setDestination(destination);
        h.setContentType(MediaType.APPLICATION_JSON);
        s.send(h, body);
    }

    @Test
    void chatMessagesUnreadTypingAndPresence() throws Exception {
        Account a = register();
        Account b = register();
        call(HttpMethod.POST, "/connections/requests/" + b.id(), a.token(), null); // 201
        String connectionId = call(HttpMethod.POST, "/connections/requests/" + a.id() + "/accept", b.token(), null)
                .get("connectionId").asText();

        StompSession sa = connect(a);
        StompSession sb = connect(b);
        BlockingQueue<JsonNode> aMessages = subscribe(sa, "/user/queue/messages");
        BlockingQueue<JsonNode> bMessages = subscribe(sb, "/user/queue/messages");
        BlockingQueue<JsonNode> bUnread = subscribe(sb, "/user/queue/unread");
        BlockingQueue<JsonNode> bTyping = subscribe(sb, "/user/queue/typing");
        BlockingQueue<JsonNode> aRead = subscribe(sa, "/user/queue/read");
        BlockingQueue<JsonNode> bSnapshot = subscribe(sb, "/app/presence/snapshot");

        // b's snapshot lists a, who is already online.
        JsonNode snapshot = bSnapshot.poll(5, TimeUnit.SECONDS);
        assertThat(snapshot).isNotNull();
        assertThat(snapshot.get("type").asText()).isEqualTo("SNAPSHOT");
        assertThat(snapshot.get("onlineUserIds").toString()).contains(a.id().toString());

        send(sa, "/app/chats/" + connectionId + "/typing", "{\"typing\":true}");
        JsonNode typing = bTyping.poll(5, TimeUnit.SECONDS);
        assertThat(typing).isNotNull();
        assertThat(typing.get("typing").asBoolean()).isTrue();
        assertThat(typing.get("userId").asText()).isEqualTo(a.id().toString());

        send(sa, "/app/chats/" + connectionId + "/send", "{\"content\":\"  hello b  \"}");
        JsonNode received = bMessages.poll(5, TimeUnit.SECONDS);
        JsonNode echoed = aMessages.poll(5, TimeUnit.SECONDS);
        assertThat(received).isNotNull();
        assertThat(received.get("content").asText()).isEqualTo("hello b");
        assertThat(received.get("senderId").asText()).isEqualTo(a.id().toString());
        assertThat(echoed).isNotNull();
        assertThat(echoed.get("id").asText()).isEqualTo(received.get("id").asText());

        JsonNode unread = bUnread.poll(5, TimeUnit.SECONDS);
        assertThat(unread).isNotNull();
        assertThat(unread.get("unreadCount").asLong()).isEqualTo(1);
        assertThat(unread.get("totalUnread").asLong()).isEqualTo(1);
        assertThat(call(HttpMethod.GET, "/chats", b.token(), null).get(0).get("unreadCount").asLong()).isEqualTo(1);

        send(sb, "/app/chats/" + connectionId + "/read", "");
        JsonNode read = aRead.poll(5, TimeUnit.SECONDS);
        assertThat(read).isNotNull();
        assertThat(read.get("readerId").asText()).isEqualTo(b.id().toString());
        assertThat(bUnread.poll(5, TimeUnit.SECONDS).get("unreadCount").asLong()).isZero();
        assertThat(call(HttpMethod.GET, "/chats/" + connectionId + "/messages", a.token(), null)
                .get("messages").get(0).get("readAt").isNull()).isFalse();

        // Blank and oversized messages are rejected and reported only to the sender.
        BlockingQueue<JsonNode> aErrors = subscribe(sa, "/user/queue/errors");
        send(sa, "/app/chats/" + connectionId + "/send", "{\"content\":\"   \"}");
        assertThat(aErrors.poll(5, TimeUnit.SECONDS).get("code").asText()).isEqualTo("validation_failed");
        assertThat(bMessages.poll(500, TimeUnit.MILLISECONDS)).isNull();

        // Clients cannot forge server events into someone else's queue, nor subscribe to others' queues.
        send(sa, "/user/" + b.id() + "/queue/messages", "{\"content\":\"forged\"}");
        assertThat(bMessages.poll(1, TimeUnit.SECONDS)).isNull();

        sa.disconnect();
        sb.disconnect();
    }

    @Test
    void connectWithoutValidTokenIsRejected() {
        WebSocketStompClient client = new WebSocketStompClient(new StandardWebSocketClient());
        StompHeaders headers = new StompHeaders();
        headers.add("Authorization", "Bearer not-a-jwt");
        assertThatThrownBy(() -> client.connectAsync("ws://localhost:" + port + "/ws",
                new WebSocketHttpHeaders(), headers, new StompSessionHandlerAdapter() { })
                .get(5, TimeUnit.SECONDS)).isNotNull();
    }
}
