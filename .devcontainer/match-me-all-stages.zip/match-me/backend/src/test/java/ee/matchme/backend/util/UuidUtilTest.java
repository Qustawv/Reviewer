package ee.matchme.backend.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class UuidUtilTest {

    private static final UUID LOW = UUID.fromString("00000000-0000-0000-0000-000000000001");
    private static final UUID HIGH = UUID.fromString("80000000-0000-0000-0000-000000000002");

    @Test
    void unsignedOrderMatchesPostgres() {
        // PostgreSQL: 0000...0001 < 8000...0002 (verified against a real server).
        assertThat(UuidUtil.compareUnsigned(LOW, HIGH)).isNegative();
        assertThat(UuidUtil.compareUnsigned(HIGH, LOW)).isPositive();
        assertThat(UuidUtil.compareUnsigned(LOW, LOW)).isZero();
    }

    @Test
    void javaCompareToDisagreesWithPostgres_whichIsWhyItMustNotBeUsed() {
        assertThat(LOW.compareTo(HIGH)).isPositive();
    }

    @Test
    void lowerAndHigherAreIndependentOfArgumentOrder() {
        assertThat(UuidUtil.lower(LOW, HIGH)).isEqualTo(LOW);
        assertThat(UuidUtil.lower(HIGH, LOW)).isEqualTo(LOW);
        assertThat(UuidUtil.higher(LOW, HIGH)).isEqualTo(HIGH);
        assertThat(UuidUtil.higher(HIGH, LOW)).isEqualTo(HIGH);
    }

    @Test
    void parseAcceptsCanonicalUuids() {
        assertThat(UuidUtil.parse("80000000-0000-0000-0000-000000000002")).contains(HIGH);
        assertThat(UuidUtil.parse("80000000-0000-0000-0000-00000000000A")).isPresent();
    }

    @ParameterizedTest
    @ValueSource(strings = {"", " ", "not-a-uuid", "1-1-1-1-1", "8000000000000000000000000000002",
            "80000000-0000-0000-0000-000000000002 ", "80000000-0000-0000-0000-00000000000g",
            "../me", "80000000-0000-0000-0000-000000000002/bio"})
    void parseRejectsEverythingElse(String raw) {
        assertThat(UuidUtil.parse(raw)).isEmpty();
    }

    @Test
    void parseRejectsNull() {
        assertThat(UuidUtil.parse(null)).isEmpty();
    }
}
