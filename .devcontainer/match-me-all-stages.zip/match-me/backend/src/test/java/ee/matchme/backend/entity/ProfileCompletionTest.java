package ee.matchme.backend.entity;

import ee.matchme.backend.util.ProfileRules;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/** The completion gate: all 12 mandatory fields, at their documented limits. */
class ProfileCompletionTest {

    static Profile complete() {
        Profile p = new Profile(UUID.randomUUID());
        p.setDisplayName("Mari Tamm");
        p.setAboutMe("Second-year student who loves pair programming and exam prep groups.");
        p.setStudyArea(StudyArea.WEB_DEVELOPMENT);
        p.setStudyLevel(StudyLevel.INTERMEDIATE);
        p.getSkills().add("JAVA");
        p.getCollaborationGoals().add(CollaborationGoal.STUDY_PARTNER);
        p.getAvailability().add(AvailabilitySlot.WEEKDAY_EVENING);
        p.setWorkStyle(WorkStyle.FLEXIBLE);
        p.getPreferredLanguages().add(PreferredLanguage.ESTONIAN);
        p.setLatitude(59.437);
        p.setLongitude(24.7536);
        p.setMaximumDistanceKm(25);
        p.setCity("Tallinn");
        return p;
    }

    @Test
    void fullyFilledProfileIsComplete() {
        assertThat(ProfileRules.isComplete(complete())).isTrue();
    }

    @Test
    void optionalFieldsNeverAffectCompleteness() {
        Profile p = complete();
        p.setProfileImageUrl(null);
        p.getPriorityFields().clear();
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setProfileImageUrl("https://example.ee/me.png");
        p.getPriorityFields().add(PriorityField.SKILLS);
        assertThat(ProfileRules.isComplete(p)).isTrue();
    }

    static Stream<Arguments> missingOrInvalidMandatoryField() {
        return Stream.of(
                breaker("1 displayName missing", p -> p.setDisplayName(null)),
                breaker("2 aboutMe missing", p -> p.setAboutMe(null)),
                breaker("3 studyArea missing", p -> p.setStudyArea(null)),
                breaker("4 studyLevel missing", p -> p.setStudyLevel(null)),
                breaker("5 skills empty", p -> p.getSkills().clear()),
                breaker("6 collaborationGoals empty", p -> p.getCollaborationGoals().clear()),
                breaker("7 availability empty", p -> p.getAvailability().clear()),
                breaker("8 workStyle missing", p -> p.setWorkStyle(null)),
                breaker("9 preferredLanguages empty", p -> p.getPreferredLanguages().clear()),
                breaker("10a latitude missing", p -> p.setLatitude(null)),
                breaker("10b longitude missing", p -> p.setLongitude(null)),
                breaker("11 maximumDistanceKm missing", p -> p.setMaximumDistanceKm(null)),
                breaker("12 city missing", p -> p.setCity(null)));
    }

    private static Arguments breaker(String name, Consumer<Profile> breakIt) {
        return Arguments.of(name, breakIt);
    }

    @ParameterizedTest(name = "incomplete when {0}")
    @MethodSource("missingOrInvalidMandatoryField")
    void anyMissingMandatoryFieldMakesProfileIncomplete(String name, Consumer<Profile> breakIt) {
        Profile p = complete();
        breakIt.accept(p);
        assertThat(ProfileRules.isComplete(p)).isFalse();
    }

    @Test
    void textLengthBoundaries() {
        Profile p = complete();
        p.setDisplayName("ab");
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setDisplayName("a");
        assertThat(ProfileRules.isComplete(p)).isFalse();
        p.setDisplayName("x".repeat(40));
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setDisplayName("x".repeat(41));
        assertThat(ProfileRules.isComplete(p)).isFalse();

        p = complete();
        p.setAboutMe("x".repeat(30));
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setAboutMe("x".repeat(29));
        assertThat(ProfileRules.isComplete(p)).isFalse();
        p.setAboutMe("x".repeat(500));
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setAboutMe("x".repeat(501));
        assertThat(ProfileRules.isComplete(p)).isFalse();
    }

    @Test
    void lengthsCountUnicodeCodePointsLikePostgres() {
        Profile p = complete();
        // 15 emoji = 30 UTF-16 units but only 15 code points: PostgreSQL char_length says 15, so too short.
        p.setAboutMe("😀".repeat(15));
        assertThat(ProfileRules.isComplete(p)).isFalse();
        p.setAboutMe("😀".repeat(30));
        assertThat(ProfileRules.isComplete(p)).isTrue();
    }

    @Test
    void severalPreferredLanguagesAreAllowed() {
        Profile p = complete();
        p.getPreferredLanguages().add(PreferredLanguage.ENGLISH);
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.getPreferredLanguages().add(PreferredLanguage.RUSSIAN);
        p.getPreferredLanguages().add(PreferredLanguage.OTHER);
        assertThat(p.getPreferredLanguages()).hasSize(4);
        assertThat(ProfileRules.isComplete(p)).isTrue();
    }

    @Test
    void collectionSizeBoundaries() {
        Profile p = complete();
        for (int i = 0; i < 7; i++) {
            p.getSkills().add("SKILL_" + i); // 1 + 7 = 8
        }
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.getSkills().add("SKILL_X"); // 9
        assertThat(ProfileRules.isComplete(p)).isFalse();

        p = complete();
        p.getCollaborationGoals().add(CollaborationGoal.CODE_REVIEW);
        p.getCollaborationGoals().add(CollaborationGoal.ACCOUNTABILITY); // 3
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.getCollaborationGoals().add(CollaborationGoal.EXAM_PREPARATION); // 4
        assertThat(ProfileRules.isComplete(p)).isFalse();
    }

    @Test
    void locationAndDistanceBoundaries() {
        Profile p = complete();
        p.setLatitude(90.0);
        p.setLongitude(-180.0);
        assertThat(ProfileRules.isComplete(p)).isTrue();
        p.setLatitude(90.0001);
        assertThat(ProfileRules.isComplete(p)).isFalse();
        p.setLatitude(0.0);
        p.setLongitude(180.0001);
        assertThat(ProfileRules.isComplete(p)).isFalse();
        p.setLongitude(Double.NaN);
        assertThat(ProfileRules.isComplete(p)).isFalse();

        p = complete();
        for (int ok : new int[]{5, 10, 25, 50, 100}) {
            p.setMaximumDistanceKm(ok);
            assertThat(ProfileRules.isComplete(p)).as("distance %d", ok).isTrue();
        }
        for (int bad : new int[]{0, 1, 7, 26, 101}) {
            p.setMaximumDistanceKm(bad);
            assertThat(ProfileRules.isComplete(p)).as("distance %d", bad).isFalse();
        }
    }

    @Test
    void blankCityIsIncomplete() {
        Profile p = complete();
        p.setCity("   ");
        assertThat(ProfileRules.isComplete(p)).isFalse();
    }
}
