package ee.matchme.backend.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import ee.matchme.backend.entity.Connection;
import ee.matchme.backend.entity.ConnectionStatus;
import ee.matchme.backend.entity.User;
import ee.matchme.backend.repository.ConnectionRepository;
import ee.matchme.backend.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * End-to-end tests against a real PostgreSQL 16 (Testcontainers, skipped when Docker is not
 * available). Starting the context also runs Flyway V1-V5 and Hibernate's schema validation.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Testcontainers(disabledWithoutDocker = true)
class UserAccessIntegrationTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");

    private static final String AUTH = "Authorization";
    private static final String PASSWORD = "correct horse battery";

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper json;
    @Autowired
    UserRepository users;
    @Autowired
    ConnectionRepository connections;

    record Account(UUID id, String email, String token) {
    }

    // ---- helpers -------------------------------------------------------------------------

    private Account register(String prefix) throws Exception {
        String email = prefix + "-" + UUID.randomUUID() + "@example.ee";
        String body = mvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", email, "password", PASSWORD))))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        String token = json.readTree(body).get("token").asText();
        String me = mvc.perform(MockMvcRequestBuilders.get("/me").header(AUTH, "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return new Account(UUID.fromString(json.readTree(me).get("id").asText()), email, token);
    }

    private ResultActions getAs(Account who, String path) throws Exception {
        return mvc.perform(MockMvcRequestBuilders.get(path).header(AUTH, "Bearer " + who.token()));
    }

    private ResultActions putProfile(Account who, Map<String, Object> body) throws Exception {
        return mvc.perform(MockMvcRequestBuilders.put("/me/profile")
                .header(AUTH, "Bearer " + who.token())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json.writeValueAsString(body)));
    }

    private String bodyOf(ResultActions r) throws Exception {
        return r.andReturn().getResponse().getContentAsString();
    }

    private Set<String> keys(String body) throws Exception {
        Set<String> keys = new TreeSet<>();
        json.readTree(body).fieldNames().forEachRemaining(keys::add);
        return keys;
    }

    private static Map<String, Object> completeProfile() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("displayName", "Mari Tamm");
        m.put("aboutMe", "Second-year student who loves pair programming and exam prep groups.");
        m.put("studyArea", "WEB_DEVELOPMENT");
        m.put("studyLevel", "INTERMEDIATE");
        m.put("skills", List.of("JAVA", "REACT"));
        m.put("collaborationGoals", List.of("STUDY_PARTNER", "CODE_REVIEW"));
        m.put("availability", List.of("WEEKDAY_EVENING", "WEEKEND_MORNING"));
        m.put("workStyle", "FLEXIBLE");
        m.put("preferredLanguages", List.of("ENGLISH"));
        m.put("latitude", 59.437);
        m.put("longitude", 24.7536);
        m.put("maximumDistanceKm", 25);
        m.put("city", "Tallinn");
        m.put("priorityFields", List.of("SKILLS"));
        return m;
    }

    private Connection link(Account requester, Account target, ConnectionStatus status) {
        Connection c = Connection.request(requester.id(), target.id());
        c.setStatus(status);
        return connections.save(c);
    }

    // ---- registration and login ----------------------------------------------------------

    @Test
    void registerStoresASaltedBcryptHashNeverThePassword() throws Exception {
        Account a = register("hash");
        String hash = users.findByEmail(a.email()).orElseThrow().getPasswordHash();
        assertThat(hash).startsWith("$2").isNotEqualTo(PASSWORD).doesNotContain(PASSWORD);

        Account b = register("hash2");
        // Same password, different hash: the salt is random per user.
        assertThat(users.findByEmail(b.email()).orElseThrow().getPasswordHash()).isNotEqualTo(hash);
    }

    @Test
    void registerRejectsDuplicateEmailCaseInsensitively() throws Exception {
        Account a = register("dup");
        mvc.perform(MockMvcRequestBuilders.post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(
                                Map.of("email", a.email().toUpperCase(), "password", PASSWORD))))
                .andExpect(status().isConflict());
    }

    @Test
    void registerRejectsBadInput() throws Exception {
        mvc.perform(MockMvcRequestBuilders.post("/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", "x@example.ee", "password", "short"))))
                .andExpect(status().isBadRequest());
        mvc.perform(MockMvcRequestBuilders.post("/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", "not-an-email", "password", PASSWORD))))
                .andExpect(status().isBadRequest());
        // 73 bytes: longer than BCrypt can use.
        mvc.perform(MockMvcRequestBuilders.post("/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", "y@example.ee", "password", "é".repeat(37)))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void loginWorksAndFailsUniformly() throws Exception {
        Account a = register("login");
        mvc.perform(MockMvcRequestBuilders.post("/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", a.email().toUpperCase(), "password", PASSWORD))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty());

        String wrongPassword = bodyOf(mvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", a.email(), "password", "wrong-password"))))
                .andExpect(status().isUnauthorized()));
        String unknownEmail = bodyOf(mvc.perform(MockMvcRequestBuilders.post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("email", "nobody@example.ee", "password", PASSWORD))))
                .andExpect(status().isUnauthorized()));
        assertThat(wrongPassword).isEqualTo(unknownEmail);
    }

    @Test
    void protectedEndpointsRequireAValidToken() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/me")).andExpect(status().isUnauthorized());
        mvc.perform(MockMvcRequestBuilders.get("/me").header(AUTH, "Bearer garbage"))
                .andExpect(status().isUnauthorized());
        mvc.perform(MockMvcRequestBuilders.get("/users/" + UUID.randomUUID())).andExpect(status().isUnauthorized());
        mvc.perform(MockMvcRequestBuilders.get("/connections")).andExpect(status().isUnauthorized());
    }

    // ---- privacy of account fields -------------------------------------------------------

    @Test
    void emailAppearsOnlyInMeNeverInPublicPayloads() throws Exception {
        Account a = register("privacy-a");
        Account b = register("privacy-b");
        putProfile(b, completeProfile()).andExpect(status().isOk());
        link(a, b, ConnectionStatus.ACCEPTED);

        assertThat(keys(bodyOf(getAs(a, "/me").andExpect(status().isOk()))))
                .containsExactlyInAnyOrder("id", "email", "displayName", "profileImageUrl");
        getAs(a, "/me").andExpect(jsonPath("$.email").value(a.email()));

        for (String path : List.of("/users/" + b.id(), "/users/" + b.id() + "/profile",
                "/users/" + b.id() + "/bio", "/me/profile", "/me/bio")) {
            assertThat(bodyOf(getAs(a, path).andExpect(status().isOk())))
                    .as(path).doesNotContain("email").doesNotContain("@example.ee");
        }
    }

    @Test
    void publicPayloadsHaveExactlyTheDocumentedShapes() throws Exception {
        Account a = register("shape-a");
        Account b = register("shape-b");
        putProfile(b, completeProfile()).andExpect(status().isOk());
        link(a, b, ConnectionStatus.PENDING);

        assertThat(keys(bodyOf(getAs(a, "/users/" + b.id()).andExpect(status().isOk()))))
                .containsExactlyInAnyOrder("id", "displayName", "profileImageUrl");
        assertThat(keys(bodyOf(getAs(a, "/users/" + b.id() + "/profile").andExpect(status().isOk()))))
                .containsExactlyInAnyOrder("id", "aboutMe");
        String bio = bodyOf(getAs(a, "/users/" + b.id() + "/bio").andExpect(status().isOk()));
        assertThat(keys(bio)).containsExactlyInAnyOrder("id", "studyArea", "studyLevel", "skills",
                "collaborationGoals", "availability", "workStyle", "preferredLanguages", "city");
        // Private: exact location, search radius and priority fields.
        assertThat(bio).doesNotContain("latitude").doesNotContain("longitude")
                .doesNotContain("maximumDistanceKm").doesNotContain("priorityFields");

        getAs(a, "/users/" + b.id()).andExpect(jsonPath("$.displayName").value("Mari Tamm"));
        getAs(a, "/users/" + b.id() + "/bio")
                .andExpect(jsonPath("$.skills[0]").value("JAVA"))
                .andExpect(jsonPath("$.city").value("Tallinn"));
    }

    // ---- the 404 guard -------------------------------------------------------------------

    @Test
    void unrelatedExistingUserIsIndistinguishableFromAMissingOne() throws Exception {
        Account a = register("guard-a");
        Account stranger = register("guard-stranger");
        putProfile(stranger, completeProfile()).andExpect(status().isOk());

        for (String suffix : List.of("", "/profile", "/bio")) {
            String forbidden = bodyOf(getAs(a, "/users/" + stranger.id() + suffix).andExpect(status().isNotFound()));
            String missing = bodyOf(getAs(a, "/users/" + UUID.randomUUID() + suffix).andExpect(status().isNotFound()));
            String malformed = bodyOf(getAs(a, "/users/not-a-uuid" + suffix).andExpect(status().isNotFound()));
            assertThat(forbidden).as("existing-but-forbidden vs missing %s", suffix).isEqualTo(missing);
            assertThat(malformed).as("malformed vs missing %s", suffix).isEqualTo(missing);
        }
    }

    @Test
    void pendingRequestGrantsAccessInBothDirections() throws Exception {
        Account a = register("pend-a");
        Account b = register("pend-b");
        getAs(a, "/users/" + b.id()).andExpect(status().isNotFound());
        getAs(b, "/users/" + a.id()).andExpect(status().isNotFound());

        link(a, b, ConnectionStatus.PENDING); // outgoing for a, incoming for b

        for (String suffix : List.of("", "/profile", "/bio")) {
            getAs(a, "/users/" + b.id() + suffix).andExpect(status().isOk());
            getAs(b, "/users/" + a.id() + suffix).andExpect(status().isOk());
        }
    }

    @Test
    void acceptedConnectionGrantsAccess() throws Exception {
        Account a = register("acc-a");
        Account b = register("acc-b");
        link(b, a, ConnectionStatus.ACCEPTED);
        getAs(a, "/users/" + b.id()).andExpect(status().isOk());
        getAs(b, "/users/" + a.id()).andExpect(status().isOk());
    }

    @Test
    void rejectedAndDisconnectedPairsAreHiddenAgain() throws Exception {
        Account a = register("rej-a");
        Account b = register("rej-b");
        Connection c = link(a, b, ConnectionStatus.PENDING);
        getAs(a, "/users/" + b.id()).andExpect(status().isOk());

        c.setStatus(ConnectionStatus.REJECTED);
        connections.save(c);
        getAs(a, "/users/" + b.id()).andExpect(status().isNotFound());
        getAs(b, "/users/" + a.id()).andExpect(status().isNotFound());

        c.setStatus(ConnectionStatus.DISCONNECTED);
        connections.save(c);
        getAs(a, "/users/" + b.id()).andExpect(status().isNotFound());
    }

    @Test
    void ownIdWorksThroughUsersEndpointToo() throws Exception {
        Account a = register("self");
        getAs(a, "/users/" + a.id()).andExpect(status().isOk());
    }

    // ---- connections list ----------------------------------------------------------------

    @Test
    void connectionsListsAcceptedUserIdsOnly() throws Exception {
        Account a = register("list-a");
        Account accepted = register("list-b");
        Account pending = register("list-c");
        Account rejected = register("list-d");
        getAs(a, "/connections").andExpect(status().isOk()).andExpect(jsonPath("$").isEmpty());

        link(a, accepted, ConnectionStatus.ACCEPTED);
        link(pending, a, ConnectionStatus.PENDING);
        link(a, rejected, ConnectionStatus.REJECTED);

        JsonNode forA = json.readTree(bodyOf(getAs(a, "/connections").andExpect(status().isOk())));
        assertThat(forA.isArray()).isTrue();
        assertThat(forA).hasSize(1);
        assertThat(forA.get(0).isTextual()).isTrue();
        assertThat(forA.get(0).asText()).isEqualTo(accepted.id().toString());

        JsonNode forB = json.readTree(bodyOf(getAs(accepted, "/connections").andExpect(status().isOk())));
        assertThat(forB.get(0).asText()).isEqualTo(a.id().toString());
    }

    /**
     * Regression test for the PostgreSQL-vs-Java UUID ordering difference: connections must be
     * storable for every pair of ids, including those whose first bit differs. The database CHECK
     * (user_one_id < user_two_id) would reject any pair ordered with UUID.compareTo.
     */
    @Test
    void everyPairOfUsersCanBeStoredInCanonicalOrder() {
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            ids.add(users.save(new User("pair-" + i + "-" + UUID.randomUUID() + "@example.ee", "x")).getId());
        }
        for (int i = 0; i < ids.size(); i++) {
            for (int j = i + 1; j < ids.size(); j++) {
                connections.saveAndFlush(Connection.request(ids.get(i), ids.get(j)));
            }
        }
        assertThat(connections.findAll().stream().filter(c -> ids.contains(c.getUserOneId())).count())
                .isEqualTo(66);
    }

    // ---- profile completion gate and validation ------------------------------------------

    @Test
    void profileCompleteIsComputedByTheServer() throws Exception {
        Account a = register("gate");
        getAs(a, "/me/settings").andExpect(jsonPath("$.profileComplete").value(false));

        putProfile(a, completeProfile())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.profileComplete").value(true))
                .andExpect(jsonPath("$.latitude").value(59.437))
                .andExpect(jsonPath("$.maximumDistanceKm").value(25))
                .andExpect(jsonPath("$.priorityFields[0]").value("SKILLS"));
        getAs(a, "/me/settings").andExpect(jsonPath("$.profileComplete").value(true));

        // Removing any mandatory field flips it back, and a client-sent flag is ignored.
        Map<String, Object> noCity = completeProfile();
        noCity.remove("city");
        noCity.put("profileComplete", true);
        putProfile(a, noCity).andExpect(status().isOk()).andExpect(jsonPath("$.profileComplete").value(false));

        Map<String, Object> noGoals = completeProfile();
        noGoals.put("collaborationGoals", List.of());
        putProfile(a, noGoals).andExpect(status().isOk()).andExpect(jsonPath("$.profileComplete").value(false));
    }

    @Test
    void profileUpdateRoundTripsThroughMeEndpoints() throws Exception {
        Account a = register("roundtrip");
        putProfile(a, completeProfile()).andExpect(status().isOk());

        getAs(a, "/me").andExpect(jsonPath("$.displayName").value("Mari Tamm"));
        getAs(a, "/me/profile").andExpect(jsonPath("$.aboutMe")
                .value("Second-year student who loves pair programming and exam prep groups."));
        getAs(a, "/me/bio")
                .andExpect(jsonPath("$.id").value(a.id().toString()))
                .andExpect(jsonPath("$.studyArea").value("WEB_DEVELOPMENT"))
                .andExpect(jsonPath("$.skills.length()").value(2))
                .andExpect(jsonPath("$.collaborationGoals[0]").value("STUDY_PARTNER"))
                .andExpect(jsonPath("$.availability[0]").value("WEEKDAY_EVENING"))
                .andExpect(jsonPath("$.workStyle").value("FLEXIBLE"))
                .andExpect(jsonPath("$.preferredLanguages[0]").value("ENGLISH"));
    }

    @Test
    void profileUpdateRejectsInvalidInput() throws Exception {
        Account a = register("invalid");

        Map<String, Object> shortAbout = completeProfile();
        shortAbout.put("aboutMe", "too short");
        putProfile(a, shortAbout).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fields.aboutMe").exists());

        Map<String, Object> unknownSkill = completeProfile();
        unknownSkill.put("skills", List.of("JAVA", "COBOL"));
        putProfile(a, unknownSkill).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fields.skills").exists());

        Map<String, Object> tooManySkills = completeProfile();
        tooManySkills.put("skills", List.of("JAVA", "PYTHON", "JAVASCRIPT", "TYPESCRIPT", "REACT",
                "NODE_JS", "SPRING_BOOT", "SQL", "GIT"));
        putProfile(a, tooManySkills).andExpect(status().isBadRequest());

        Map<String, Object> tooManyPriorities = completeProfile();
        tooManyPriorities.put("priorityFields", List.of("SKILLS", "AVAILABILITY", "STUDY_AREA"));
        putProfile(a, tooManyPriorities).andExpect(status().isBadRequest());

        Map<String, Object> badDistance = completeProfile();
        badDistance.put("maximumDistanceKm", 7);
        putProfile(a, badDistance).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fields.maximumDistanceKm").exists());

        Map<String, Object> badLatitude = completeProfile();
        badLatitude.put("latitude", 123.0);
        putProfile(a, badLatitude).andExpect(status().isBadRequest());

        Map<String, Object> badEnum = completeProfile();
        badEnum.put("studyArea", "COOKING");
        putProfile(a, badEnum).andExpect(status().isBadRequest());

        Map<String, Object> scriptUrl = completeProfile();
        scriptUrl.put("profileImageUrl", "javascript:alert(1)");
        putProfile(a, scriptUrl).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fields.profileImageUrl").exists());

        // Nothing invalid was stored.
        getAs(a, "/me/settings").andExpect(jsonPath("$.profileComplete").value(false));
    }

    @Test
    void lookupsExposeTheFixedOptionLists() throws Exception {
        Account a = register("lookups");
        getAs(a, "/lookups").andExpect(status().isOk())
                .andExpect(jsonPath("$.skills.length()").value(24))
                .andExpect(jsonPath("$.availabilitySlots.length()").value(6))
                .andExpect(jsonPath("$.maximumDistanceKmOptions[0]").value(5))
                .andExpect(jsonPath("$.maximumDistanceKmOptions[4]").value(100));
    }
}
