-- Match-Me demo data: 5 users with complete profiles, for trying out recommendations.
-- Every account has the password:  demo1234!
-- Safe to run more than once (it replaces the demo accounts, nothing else).
--
--   mari.demo@example.ee       Mari Tamm       Tallinn   English, Estonian  software dev, intermediate
--   kristjan.demo@example.ee   Kristjan Saar   Keila     English            web dev, beginner        (~30 km from Tallinn)
--   liis.demo@example.ee       Liis Kask       Rakvere   English, Russian   data science, advanced   (~90 km from Tallinn)
--   henri.demo@example.ee      Henri Mägi      Tartu     English            web dev, intermediate    (~190 km from Tallinn: filtered out by distance)
--   olga.demo@example.ee       Olga Petrova    Saue      Russian, Estonian  software dev             (shown only if you also pick Russian or Estonian)

BEGIN;

DELETE FROM users WHERE email IN (
  'mari.demo@example.ee','kristjan.demo@example.ee','liis.demo@example.ee','henri.demo@example.ee','olga.demo@example.ee');

INSERT INTO users (id, email, password_hash) VALUES
  ('d0000000-0000-4000-8000-000000000001', 'mari.demo@example.ee',     '$2a$10$DYlaIurryPSvlm1vf/To9.D3umjRgHpa40..sv4R36mSnLLGHRfZW'),
  ('d0000000-0000-4000-8000-000000000002', 'kristjan.demo@example.ee', '$2a$10$DYlaIurryPSvlm1vf/To9.D3umjRgHpa40..sv4R36mSnLLGHRfZW'),
  ('d0000000-0000-4000-8000-000000000003', 'liis.demo@example.ee',     '$2a$10$DYlaIurryPSvlm1vf/To9.D3umjRgHpa40..sv4R36mSnLLGHRfZW'),
  ('d0000000-0000-4000-8000-000000000004', 'henri.demo@example.ee',    '$2a$10$DYlaIurryPSvlm1vf/To9.D3umjRgHpa40..sv4R36mSnLLGHRfZW'),
  ('d0000000-0000-4000-8000-000000000005', 'olga.demo@example.ee',     '$2a$10$DYlaIurryPSvlm1vf/To9.D3umjRgHpa40..sv4R36mSnLLGHRfZW');

INSERT INTO profiles (user_id, display_name, about_me, study_area, study_level, work_style,
                      latitude, longitude, maximum_distance_km, city, profile_complete) VALUES
  ('d0000000-0000-4000-8000-000000000001', 'Mari Tamm',
   'Second-year software student who loves pair programming and Java. Looking for someone to review code with.',
   'SOFTWARE_DEVELOPMENT', 'INTERMEDIATE', 'FLEXIBLE', 59.4370, 24.7536, 50, 'Tallinn', TRUE),
  ('d0000000-0000-4000-8000-000000000002', 'Kristjan Saar',
   'Beginner web developer learning React and TypeScript. I like clear plans and regular study sessions.',
   'WEB_DEVELOPMENT', 'BEGINNER', 'STRUCTURED', 59.3036, 24.4136, 100, 'Keila', TRUE),
  ('d0000000-0000-4000-8000-000000000003', 'Liis Kask',
   'Data science student into Python and machine learning. Happy to prepare for exams together.',
   'DATA_SCIENCE', 'ADVANCED', 'INDEPENDENT_WITH_CHECK_INS', 59.3464, 26.3558, 100, 'Rakvere', TRUE),
  ('d0000000-0000-4000-8000-000000000004', 'Henri Mägi',
   'Full-stack student in Tartu who enjoys Java backends and React frontends. Open to study partners.',
   'WEB_DEVELOPMENT', 'INTERMEDIATE', 'FLEXIBLE', 58.3780, 26.7290, 100, 'Tartu', TRUE),
  ('d0000000-0000-4000-8000-000000000005', 'Olga Petrova',
   'Software student who prefers to study in Russian. Looking for a regular evening study partner.',
   'SOFTWARE_DEVELOPMENT', 'INTERMEDIATE', 'FLEXIBLE', 59.3225, 24.5497, 25, 'Saue', TRUE);

INSERT INTO profile_languages (user_id, language_code) VALUES
  ('d0000000-0000-4000-8000-000000000001','ENGLISH'),  ('d0000000-0000-4000-8000-000000000001','ESTONIAN'),
  ('d0000000-0000-4000-8000-000000000002','ENGLISH'),
  ('d0000000-0000-4000-8000-000000000003','ENGLISH'),  ('d0000000-0000-4000-8000-000000000003','RUSSIAN'),
  ('d0000000-0000-4000-8000-000000000004','ENGLISH'),
  ('d0000000-0000-4000-8000-000000000005','RUSSIAN'),  ('d0000000-0000-4000-8000-000000000005','ESTONIAN');

INSERT INTO profile_skills (user_id, skill_code) VALUES
  ('d0000000-0000-4000-8000-000000000001','JAVA'), ('d0000000-0000-4000-8000-000000000001','SPRING_BOOT'),
  ('d0000000-0000-4000-8000-000000000001','SQL'),  ('d0000000-0000-4000-8000-000000000001','GIT'),
  ('d0000000-0000-4000-8000-000000000002','JAVASCRIPT'), ('d0000000-0000-4000-8000-000000000002','TYPESCRIPT'),
  ('d0000000-0000-4000-8000-000000000002','REACT'),      ('d0000000-0000-4000-8000-000000000002','GIT'),
  ('d0000000-0000-4000-8000-000000000003','PYTHON'), ('d0000000-0000-4000-8000-000000000003','SQL'),
  ('d0000000-0000-4000-8000-000000000003','GIT'),    ('d0000000-0000-4000-8000-000000000003','DATA_ANALYSIS'),
  ('d0000000-0000-4000-8000-000000000004','JAVA'), ('d0000000-0000-4000-8000-000000000004','SQL'),
  ('d0000000-0000-4000-8000-000000000004','REACT'), ('d0000000-0000-4000-8000-000000000004','DOCKER'),
  ('d0000000-0000-4000-8000-000000000005','JAVA'), ('d0000000-0000-4000-8000-000000000005','SQL'),
  ('d0000000-0000-4000-8000-000000000005','GIT');

INSERT INTO profile_collaboration_goals (user_id, goal_code) VALUES
  ('d0000000-0000-4000-8000-000000000001','STUDY_PARTNER'), ('d0000000-0000-4000-8000-000000000001','CODE_REVIEW'),
  ('d0000000-0000-4000-8000-000000000002','STUDY_PARTNER'), ('d0000000-0000-4000-8000-000000000002','CODE_REVIEW'),
  ('d0000000-0000-4000-8000-000000000003','STUDY_PARTNER'), ('d0000000-0000-4000-8000-000000000003','EXAM_PREPARATION'),
  ('d0000000-0000-4000-8000-000000000004','STUDY_PARTNER'), ('d0000000-0000-4000-8000-000000000004','CODE_REVIEW'),
  ('d0000000-0000-4000-8000-000000000005','STUDY_PARTNER');

INSERT INTO profile_availability (user_id, slot_code) VALUES
  ('d0000000-0000-4000-8000-000000000001','WEEKDAY_EVENING'), ('d0000000-0000-4000-8000-000000000001','WEEKEND_MORNING'),
  ('d0000000-0000-4000-8000-000000000002','WEEKDAY_EVENING'), ('d0000000-0000-4000-8000-000000000002','WEEKEND_MORNING'),
  ('d0000000-0000-4000-8000-000000000003','WEEKEND_MORNING'), ('d0000000-0000-4000-8000-000000000003','WEEKDAY_EVENING'),
  ('d0000000-0000-4000-8000-000000000004','WEEKDAY_EVENING'),
  ('d0000000-0000-4000-8000-000000000005','WEEKDAY_EVENING');

COMMIT;
