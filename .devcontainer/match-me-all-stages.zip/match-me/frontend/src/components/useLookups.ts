import { useEffect, useState } from 'react';
import { api } from '../api';
import type { Lookups } from '../types';

let cached: Promise<Lookups> | null = null;

/** Lookup lists (fetched once per page load). Null until loaded. */
export function useLookups(): Lookups | null {
  const [lookups, setLookups] = useState<Lookups | null>(null);
  useEffect(() => {
    let cancelled = false;
    cached ??= api.lookups();
    cached.then((l) => { if (!cancelled) setLookups(l); }).catch(() => { cached = null; });
    return () => { cancelled = true; };
  }, []);
  return lookups;
}
