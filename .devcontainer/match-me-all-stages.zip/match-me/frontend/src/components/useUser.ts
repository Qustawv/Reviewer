import { useEffect, useState } from 'react';
import { api } from '../api';
import type { Bio, ProfileText, PublicUser } from '../types';

export interface UserDetails { user: PublicUser; profile?: ProfileText; bio?: Bio }

const userCache = new Map<string, Promise<PublicUser>>();

/** Public name + image of a user (cached for the session). Null while loading or when not viewable. */
export function useUser(id: string | undefined): PublicUser | null {
  const [user, setUser] = useState<PublicUser | null>(null);
  useEffect(() => {
    if (!id) { setUser(null); return; }
    let cancelled = false;
    let p = userCache.get(id);
    if (!p) {
      p = api.user(id);
      userCache.set(id, p);
      p.catch(() => userCache.delete(id));
    }
    p.then((u) => { if (!cancelled) setUser(u); }).catch(() => { if (!cancelled) setUser(null); });
    return () => { cancelled = true; };
  }, [id]);
  return user;
}

/** Everything viewable about a user: public data, about-me text and bio. */
export function useUserDetails(id: string): UserDetails | null {
  const [details, setDetails] = useState<UserDetails | null>(null);
  useEffect(() => {
    let cancelled = false;
    Promise.all([api.user(id), api.userProfile(id), api.userBio(id)])
      .then(([user, profile, bio]) => { if (!cancelled) setDetails({ user, profile, bio }); })
      .catch(() => { if (!cancelled) setDetails(null); });
    return () => { cancelled = true; };
  }, [id]);
  return details;
}
