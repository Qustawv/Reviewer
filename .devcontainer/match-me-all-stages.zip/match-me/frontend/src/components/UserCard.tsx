import type { ReactNode } from 'react';
import { useRealtime } from '../realtime';
import { Avatar } from './Avatar';
import { useLookups } from './useLookups';
import { useUserDetails } from './useUser';

export const pretty = (s: string | null | undefined) =>
  s ? s.toLowerCase().replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()) : '';

/** A user's public card (name, avatar, about me, bio) with caller-supplied action buttons. */
export function UserCard({ userId, actions, showPresence = false }: {
  userId: string; actions?: ReactNode; showPresence?: boolean;
}) {
  const details = useUserDetails(userId);
  const { online } = useRealtime();
  const lookups = useLookups();
  const skillLabel = (code: string) => lookups?.skills.find((s) => s.code === code)?.label ?? pretty(code);

  if (!details) return <div className="card muted">Loading…</div>;
  const { user, profile, bio } = details;
  return (
    <div className="card user-card">
      <div className="row">
        <Avatar url={user.profileImageUrl} name={user.displayName} size={56}
                online={showPresence ? online.has(userId) : undefined} />
        <div>
          <h3>{user.displayName ?? 'Unnamed'}</h3>
          <div className="muted small">
            {[pretty(bio?.studyArea), pretty(bio?.studyLevel), bio?.city].filter(Boolean).join(' · ')}
          </div>
        </div>
      </div>
      {profile?.aboutMe && <p>{profile.aboutMe}</p>}
      {bio && (
        <div className="chips">
          {bio.skills.map((s) => <span key={s} className="chip skill">{skillLabel(s)}</span>)}
          {bio.collaborationGoals.map((g) => <span key={g} className="chip goal">{pretty(g)}</span>)}
          {bio.workStyle && <span className="chip">{pretty(bio.workStyle)}</span>}
          {bio.preferredLanguages.map((l) => <span key={l} className="chip">{pretty(l)}</span>)}
        </div>
      )}
      {actions && <div className="actions">{actions}</div>}
    </div>
  );
}
