import { useState } from 'react';

/** Profile image, or the default 👤 when there is none (or it fails to load). */
export function Avatar({ url, name, size = 48, online }: {
  url?: string | null; name?: string | null; size?: number; online?: boolean;
}) {
  const [failed, setFailed] = useState<string | null>(null);
  const showImage = url && failed !== url;
  return (
    <span className="avatar" style={{ width: size, height: size, fontSize: size * 0.5 }}>
      {showImage
        ? <img src={url} alt={name ?? 'avatar'} onError={() => setFailed(url)} />
        : <span role="img" aria-label="default avatar">👤</span>}
      {online !== undefined && <span className={`dot ${online ? 'on' : 'off'}`} title={online ? 'Online' : 'Offline'} />}
    </span>
  );
}
