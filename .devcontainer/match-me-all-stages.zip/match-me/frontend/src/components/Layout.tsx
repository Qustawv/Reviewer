import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../auth';
import { useRealtime } from '../realtime';
import { Avatar } from './Avatar';

export function Layout() {
  const { me, logout } = useAuth();
  const { totalUnread, connected } = useRealtime();
  return (
    <div className="app">
      <header className="topbar">
        <strong className="brand">Match-Me</strong>
        <nav>
          <NavLink to="/recommendations">Discover</NavLink>
          <NavLink to="/connections">Connections</NavLink>
          <NavLink to="/chat">
            Chat{totalUnread > 0 && <span className="badge" aria-label={`${totalUnread} unread`}>{totalUnread}</span>}
          </NavLink>
          <NavLink to="/profile">Profile</NavLink>
        </nav>
        <div className="spacer" />
        <span className={`status ${connected ? 'on' : 'off'}`} title={connected ? 'Live' : 'Reconnecting…'}>●</span>
        <Avatar url={me?.profileImageUrl} name={me?.displayName} size={32} />
        <button className="link" onClick={logout}>Log out</button>
      </header>
      <main><Outlet /></main>
    </div>
  );
}
