import { useEffect, useState, type FormEvent } from 'react';
import { api, ApiError } from '../api';
import { useAuth } from '../auth';
import { Avatar } from '../components/Avatar';
import { pretty } from '../components/UserCard';
import type { Lookups, ProfileUpdate } from '../types';

const LIMITS = { skills: 8, collaborationGoals: 3, priorityFields: 2, preferredLanguages: 4 } as const;

const empty: ProfileUpdate = {
  displayName: '', aboutMe: '', studyArea: null, studyLevel: null, skills: [], collaborationGoals: [],
  availability: [], workStyle: null, preferredLanguages: [], latitude: null, longitude: null,
  maximumDistanceKm: null, city: '', profileImageUrl: '', priorityFields: [],
};

export function ProfilePage() {
  const { refreshMe } = useAuth();
  const [lookups, setLookups] = useState<Lookups | null>(null);
  const [form, setForm] = useState<ProfileUpdate>(empty);
  const [complete, setComplete] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([api.lookups(), api.me(), api.myProfile(), api.myBio(), api.mySettings()])
      .then(([lk, me, profile, bio, settings]) => {
        if (cancelled) return;
        setLookups(lk);
        setComplete(settings.profileComplete);
        setForm({
          displayName: me.displayName ?? '',
          aboutMe: profile.aboutMe ?? '',
          studyArea: bio.studyArea, studyLevel: bio.studyLevel, skills: bio.skills,
          collaborationGoals: bio.collaborationGoals, availability: bio.availability,
          workStyle: bio.workStyle, preferredLanguages: bio.preferredLanguages,
          latitude: settings.latitude, longitude: settings.longitude,
          maximumDistanceKm: settings.maximumDistanceKm, city: bio.city ?? '',
          profileImageUrl: me.profileImageUrl ?? '', priorityFields: settings.priorityFields,
        });
      })
      .catch(() => { if (!cancelled) setLoadError(true); });
    return () => { cancelled = true; };
  }, []);

  const set = <K extends keyof ProfileUpdate>(key: K, value: ProfileUpdate[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  function toggle(key: 'skills' | 'collaborationGoals' | 'availability' | 'priorityFields' | 'preferredLanguages', value: string, max?: number) {
    setForm((f) => {
      const list = f[key];
      if (list.includes(value)) return { ...f, [key]: list.filter((v) => v !== value) };
      if (max !== undefined && list.length >= max) return f;
      return { ...f, [key]: [...list, value] };
    });
  }

  function locate() {
    if (!navigator.geolocation) { setStatus('Your browser does not support geolocation.'); return; }
    setStatus('Locating…');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        // 4 decimals is ~11 m: precise enough for matching, not a street address.
        set('latitude', Math.round(pos.coords.latitude * 1e4) / 1e4);
        set('longitude', Math.round(pos.coords.longitude * 1e4) / 1e4);
        setStatus('Location set. Remember to save.');
      },
      () => setStatus('Could not get your location. You can type coordinates instead.'),
      { enableHighAccuracy: false, timeout: 10000 },
    );
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setErrors({}); setStatus(null);
    try {
      const settings = await api.updateProfile(form);
      setComplete(settings.profileComplete);
      setStatus(settings.profileComplete ? 'Saved. Your profile is complete.' : 'Saved, but the profile is not complete yet.');
      await refreshMe();
    } catch (err) {
      if (err instanceof ApiError && err.fields) { setErrors(err.fields); setStatus('Please fix the highlighted fields.'); }
      else setStatus('Could not save.');
    } finally { setBusy(false); }
  }

  if (loadError) return <p className="error">Could not load your profile.</p>;
  if (!lookups) return <p className="muted">Loading…</p>;

  const num = (v: string) => (v.trim() === '' ? null : Number(v));
  const err = (k: string) => errors[k] && <span className="error small">{errors[k]}</span>;
  const select = (key: 'studyArea' | 'studyLevel' | 'workStyle', label: string, options: string[]) => (
    <label>{label}
      <select value={form[key] ?? ''} onChange={(e) => set(key, e.target.value || null)}>
        <option value="">Select…</option>
        {options.map((o) => <option key={o} value={o}>{pretty(o)}</option>)}
      </select>
      {err(key)}
    </label>
  );

  return (
    <form className="profile" onSubmit={submit}>
      <div className={`banner ${complete ? 'ok' : 'warn'}`}>
        {complete
          ? 'Your profile is complete — you are visible to others and can use recommendations.'
          : 'Complete every field below to unlock recommendations and connection requests.'}
      </div>

      <section className="card">
        <h2>About you</h2>
        <div className="row">
          <Avatar url={form.profileImageUrl || null} name={form.displayName} size={72} />
          <label className="grow">Profile image URL (optional)
            <input value={form.profileImageUrl} onChange={(e) => set('profileImageUrl', e.target.value)} placeholder="https://…" />
            {err('profileImageUrl')}
          </label>
        </div>
        <label>Display name (2–40)
          <input value={form.displayName} onChange={(e) => set('displayName', e.target.value)} maxLength={40} />
          {err('displayName')}
        </label>
        <label>About me (30–500)
          <textarea value={form.aboutMe} onChange={(e) => set('aboutMe', e.target.value)} maxLength={500} rows={4} />
          <span className="muted small">{form.aboutMe.length}/500</span> {err('aboutMe')}
        </label>
      </section>

      <section className="card">
        <h2>Study</h2>
        <div className="grid">
          {select('studyArea', 'Study area', lookups.studyAreas)}
          {select('studyLevel', 'Study level', lookups.studyLevels)}
          {select('workStyle', 'Work style', lookups.workStyles)}
        </div>
        <fieldset>
          <legend>Preferred languages (pick one or more)</legend>
          <div className="chips">
            {lookups.preferredLanguages.map((l) => (
              <button type="button" key={l} className={`chip pick ${form.preferredLanguages.includes(l) ? 'selected' : ''}`}
                      aria-pressed={form.preferredLanguages.includes(l)}
                      onClick={() => toggle('preferredLanguages', l, LIMITS.preferredLanguages)}>{pretty(l)}</button>
            ))}
          </div>
          <span className="muted small">You are matched with people who share at least one of these.</span>
          {err('preferredLanguages')}
        </fieldset>
        <fieldset>
          <legend>Skills ({form.skills.length}/{LIMITS.skills})</legend>
          <div className="chips">
            {lookups.skills.map((s) => (
              <button type="button" key={s.code} className={`chip pick ${form.skills.includes(s.code) ? 'selected' : ''}`}
                      onClick={() => toggle('skills', s.code, LIMITS.skills)}>{s.label}</button>
            ))}
          </div>
          {err('skills')}
        </fieldset>
        <fieldset>
          <legend>Collaboration goals (up to {LIMITS.collaborationGoals})</legend>
          <div className="chips">
            {lookups.collaborationGoals.map((g) => (
              <button type="button" key={g} className={`chip pick ${form.collaborationGoals.includes(g) ? 'selected' : ''}`}
                      onClick={() => toggle('collaborationGoals', g, LIMITS.collaborationGoals)}>{pretty(g)}</button>
            ))}
          </div>
          {err('collaborationGoals')}
        </fieldset>
        <fieldset>
          <legend>Availability</legend>
          <div className="chips">
            {lookups.availabilitySlots.map((a) => (
              <button type="button" key={a} className={`chip pick ${form.availability.includes(a) ? 'selected' : ''}`}
                      onClick={() => toggle('availability', a)}>{pretty(a)}</button>
            ))}
          </div>
          {err('availability')}
        </fieldset>
      </section>

      <section className="card">
        <h2>Location</h2>
        <div className="grid">
          <label>City (optional)
            <input value={form.city} onChange={(e) => set('city', e.target.value)} maxLength={100} />
            {err('city')}
          </label>
          <label>Maximum distance
            <select value={form.maximumDistanceKm ?? ''} onChange={(e) => set('maximumDistanceKm', num(e.target.value))}>
              <option value="">Select…</option>
              {lookups.maximumDistanceKmOptions.map((d) => <option key={d} value={d}>{d} km</option>)}
            </select>
            {err('maximumDistanceKm')}
          </label>
          <label>Latitude
            <input type="number" step="any" value={form.latitude ?? ''} onChange={(e) => set('latitude', num(e.target.value))} />
            {err('latitude')}
          </label>
          <label>Longitude
            <input type="number" step="any" value={form.longitude ?? ''} onChange={(e) => set('longitude', num(e.target.value))} />
            {err('longitude')}
          </label>
        </div>
        <button type="button" onClick={locate}>📍 Use my current location</button>
      </section>

      <section className="card">
        <h2>Matching priorities</h2>
        <p className="muted small">Choose up to {LIMITS.priorityFields} areas that matter most; they count extra in your matches.</p>
        <div className="chips">
          {lookups.priorityFields.map((p) => (
            <button type="button" key={p} className={`chip pick ${form.priorityFields.includes(p) ? 'selected' : ''}`}
                    onClick={() => toggle('priorityFields', p, LIMITS.priorityFields)}>{pretty(p)}</button>
          ))}
        </div>
        {err('priorityFields')}
      </section>

      <div className="savebar">
        <button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save profile'}</button>
        {status && <span role="status">{status}</span>}
      </div>
    </form>
  );
}
