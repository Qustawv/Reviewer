import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api';
import { UserCard } from '../components/UserCard';

type Load = { state: 'loading' } | { state: 'incomplete' } | { state: 'error' } | { state: 'ready'; ids: string[] };

export function RecommendationsPage() {
  const [load, setLoad] = useState<Load>({ state: 'loading' });
  const [requested, setRequested] = useState<Set<string>>(new Set());
  const [message, setMessage] = useState<string | null>(null);

  const refresh = useCallback(() => {
    setLoad({ state: 'loading' });
    api.recommendations()
      .then((ids) => setLoad({ state: 'ready', ids }))
      .catch((e) => setLoad(e instanceof ApiError && e.code === 'profile_incomplete' ? { state: 'incomplete' } : { state: 'error' }));
  }, []);
  useEffect(refresh, [refresh]);

  const remove = (id: string) =>
    setLoad((l) => (l.state === 'ready' ? { state: 'ready', ids: l.ids.filter((x) => x !== id) } : l));

  async function connect(id: string) {
    setMessage(null);
    try {
      await api.sendRequest(id);
      setRequested((s) => new Set(s).add(id));
    } catch (e) {
      setMessage(e instanceof ApiError && e.code === 'conflict' ? 'You already have a request with this person.'
        : e instanceof ApiError && e.code === 'not_found' ? 'This recommendation is no longer available. Refresh to see new ones.'
        : 'Could not send the request.');
    }
  }

  async function dismiss(id: string) {
    setMessage(null);
    try { await api.dismiss(id); remove(id); }
    catch { setMessage('Could not dismiss this recommendation.'); }
  }

  if (load.state === 'loading') return <p className="muted">Finding matches…</p>;
  if (load.state === 'error') return <p className="error">Could not load recommendations.</p>;
  if (load.state === 'incomplete') {
    return (
      <div className="card center">
        <h2>Complete your profile first</h2>
        <p>Recommendations unlock once every profile field is filled in.</p>
        <Link className="button primary" to="/profile">Go to profile</Link>
      </div>
    );
  }

  return (
    <div>
      <div className="row between">
        <h1>Recommended for you</h1>
        <button onClick={refresh}>↻ Refresh</button>
      </div>
      {message && <p className="error" role="alert">{message}</p>}
      {load.ids.length === 0 && <p className="muted">No matches right now. Check back later or widen your distance and availability.</p>}
      <div className="list">
        {load.ids.map((id) => (
          <UserCard key={id} userId={id} actions={
            requested.has(id)
              ? <span className="muted">Request sent ✓</span>
              : <>
                  <button className="primary" onClick={() => connect(id)}>Connect</button>
                  <button onClick={() => dismiss(id)}>Not interested</button>
                </>
          } />
        ))}
      </div>
    </div>
  );
}
