import { useState, type FormEvent } from 'react';
import { ApiError } from '../api';
import { useAuth } from '../auth';

export function AuthPage() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await (mode === 'login' ? login : register)(email.trim(), password);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(
          err.code === 'invalid_credentials' ? 'Wrong email or password.'
          : err.code === 'conflict' ? 'That email is already registered.'
          : err.code === 'validation_failed' ? Object.values(err.fields ?? {}).join(' ') || 'Please check the form.'
          : err.code === 'network_error' ? 'Cannot reach the server.'
          : 'Something went wrong.');
      } else setError('Something went wrong.');
    } finally { setBusy(false); }
  }

  return (
    <div className="auth">
      <form className="card" onSubmit={submit}>
        <h1>Match-Me</h1>
        <p className="muted">Find students to study and build with.</p>
        <label>Email
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
        </label>
        <label>Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
                 minLength={mode === 'register' ? 8 : undefined} maxLength={72}
                 autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
        </label>
        {mode === 'register' && <p className="muted small">At least 8 characters.</p>}
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" disabled={busy}>{mode === 'login' ? 'Log in' : 'Create account'}</button>
        <button type="button" className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(null); }}>
          {mode === 'login' ? 'New here? Create an account' : 'Have an account? Log in'}
        </button>
      </form>
    </div>
  );
}
