import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { UserCard } from '../components/UserCard';
import { useRealtime } from '../realtime';

interface Lists { incoming: string[]; outgoing: string[]; connected: string[] }

export function ConnectionsPage() {
  const { connectionTick } = useRealtime();
  const [lists, setLists] = useState<Lists | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    Promise.all([api.incoming(), api.outgoing(), api.connections()])
      .then(([incoming, outgoing, connected]) => setLists({ incoming, outgoing, connected }))
      .catch(() => setError('Could not load connections.'));
  }, []);
  // Reload on mount and whenever a realtime connection event arrives.
  useEffect(load, [load, connectionTick]);

  async function act(fn: () => Promise<unknown>) {
    setError(null);
    try { await fn(); } catch { setError('That action is no longer possible.'); }
    load();
  }

  if (!lists) return error ? <p className="error">{error}</p> : <p className="muted">Loading…</p>;
  const { incoming, outgoing, connected } = lists;

  return (
    <div>
      {error && <p className="error" role="alert">{error}</p>}

      <h2>Requests for you {incoming.length > 0 && <span className="badge">{incoming.length}</span>}</h2>
      {incoming.length === 0 && <p className="muted">No pending requests.</p>}
      <div className="list">
        {incoming.map((id) => (
          <UserCard key={id} userId={id} actions={<>
            <button className="primary" onClick={() => act(() => api.accept(id))}>Accept</button>
            <button onClick={() => act(() => api.reject(id))}>Reject</button>
          </>} />
        ))}
      </div>

      <h2>Connected</h2>
      {connected.length === 0 && <p className="muted">No connections yet — try the Discover tab.</p>}
      <div className="list">
        {connected.map((id) => (
          <UserCard key={id} userId={id} showPresence actions={<>
            <Link className="button primary" to={`/chat?with=${id}`}>Message</Link>
            <button onClick={() => { if (confirm('Disconnect from this person? You cannot reconnect later.')) void act(() => api.disconnect(id)); }}>
              Disconnect
            </button>
          </>} />
        ))}
      </div>

      <h2>Sent requests</h2>
      {outgoing.length === 0 && <p className="muted">Nothing waiting for a reply.</p>}
      <div className="list">
        {outgoing.map((id) => <UserCard key={id} userId={id} actions={<span className="muted">Waiting for a reply…</span>} />)}
      </div>
    </div>
  );
}
