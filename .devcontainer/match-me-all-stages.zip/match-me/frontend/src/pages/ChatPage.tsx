import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../auth';
import { Avatar } from '../components/Avatar';
import { useUser } from '../components/useUser';
import { useRealtime } from '../realtime';
import type { ChatMessage, ChatSummary } from '../types';

const PAGE_SIZE = 30;
const MAX_LEN = 2000;

function ChatRow({ chat, active, onOpen }: { chat: ChatSummary; active: boolean; onOpen: () => void }) {
  const user = useUser(chat.userId);
  const { online, unread, typing } = useRealtime();
  const count = unread[chat.connectionId] ?? chat.unreadCount;
  return (
    <button className={`chat-row ${active ? 'active' : ''}`} onClick={onOpen}>
      <Avatar url={user?.profileImageUrl} name={user?.displayName} size={40} online={online.has(chat.userId)} />
      <span className="grow">
        <strong>{user?.displayName ?? '…'}</strong>
        <span className="muted small ellipsis">
          {typing[chat.connectionId] ? 'typing…' : chat.lastMessage ?? 'No messages yet'}
        </span>
      </span>
      {count > 0 && <span className="badge">{count}</span>}
    </button>
  );
}

function Thread({ chat }: { chat: ChatSummary }) {
  const { me } = useAuth();
  const { online, typing, onMessage, onRead, sendMessage, sendTyping, markRead } = useRealtime();
  const other = useUser(chat.userId);
  const connectionId = chat.connectionId;

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [page, setPage] = useState(0);
  const [hasOlder, setHasOlder] = useState(false);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);
  const typingStopTimer = useRef<number | undefined>(undefined);
  const isTyping = useRef(false);

  // Initial history (newest page); reset when switching chats.
  useEffect(() => {
    let cancelled = false;
    setMessages([]); setPage(0); setHasOlder(false); setLoading(true); stickToBottom.current = true;
    api.messages(connectionId, 0, PAGE_SIZE).then((p) => {
      if (cancelled) return;
      setMessages(p.messages); setHasOlder(p.hasOlder); setLoading(false);
    }).catch(() => { if (!cancelled) setLoading(false); });
    markRead(connectionId);
    return () => { cancelled = true; };
  }, [connectionId, markRead]);

  // Live messages for this chat; dedupe by id (the sender also receives an echo).
  useEffect(() => onMessage((m) => {
    if (m.connectionId !== connectionId) return;
    stickToBottom.current = true;
    setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
    if (m.senderId !== me?.id && document.visibilityState === 'visible') markRead(connectionId);
  }), [connectionId, me?.id, onMessage, markRead]);

  // The other side read my messages.
  useEffect(() => onRead((e) => {
    if (e.connectionId !== connectionId) return;
    const now = new Date().toISOString();
    setMessages((prev) => prev.map((m) => (m.senderId === me?.id && !m.readAt ? { ...m, readAt: now } : m)));
  }), [connectionId, me?.id, onRead]);

  useEffect(() => {
    if (stickToBottom.current) bottomRef.current?.scrollIntoView({ block: 'end' });
  }, [messages, typing]);

  // Leaving the thread: tell the other side we stopped typing.
  useEffect(() => () => {
    window.clearTimeout(typingStopTimer.current);
    if (isTyping.current) sendTyping(connectionId, false);
    isTyping.current = false;
  }, [connectionId, sendTyping]);

  async function loadOlder() {
    stickToBottom.current = false;
    const next = page + 1;
    const p = await api.messages(connectionId, next, PAGE_SIZE);
    setMessages((prev) => {
      const seen = new Set(prev.map((m) => m.id));
      return [...p.messages.filter((m) => !seen.has(m.id)), ...prev];
    });
    setPage(next); setHasOlder(p.hasOlder);
  }

  function onChange(value: string) {
    setText(value);
    if (!isTyping.current && value) { isTyping.current = true; sendTyping(connectionId, true); }
    window.clearTimeout(typingStopTimer.current);
    typingStopTimer.current = window.setTimeout(() => {
      if (isTyping.current) { isTyping.current = false; sendTyping(connectionId, false); }
    }, 2000);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const content = text.trim();
    if (!content) return;
    sendMessage(connectionId, content);
    setText('');
    window.clearTimeout(typingStopTimer.current);
    if (isTyping.current) { isTyping.current = false; sendTyping(connectionId, false); }
  }

  return (
    <div className="thread" onFocus={() => markRead(connectionId)}>
      <header className="thread-head">
        <Avatar url={other?.profileImageUrl} name={other?.displayName} size={40} online={online.has(chat.userId)} />
        <div>
          <strong>{other?.displayName ?? '…'}</strong>
          <div className="muted small">{online.has(chat.userId) ? 'Online' : 'Offline'}</div>
        </div>
      </header>
      <div className="messages" onScroll={(e) => {
        const el = e.currentTarget;
        stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
      }}>
        {hasOlder && <button className="link" onClick={() => void loadOlder()}>Load older messages</button>}
        {loading && <p className="muted center">Loading…</p>}
        {messages.map((m) => {
          const mine = m.senderId === me?.id;
          return (
            <div key={m.id} className={`bubble ${mine ? 'mine' : 'theirs'}`}>
              <div>{m.content}</div>
              <div className="meta">
                {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                {mine && <span title={m.readAt ? 'Read' : 'Sent'}> {m.readAt ? '✓✓' : '✓'}</span>}
              </div>
            </div>
          );
        })}
        {typing[connectionId] && <div className="typing muted small">{other?.displayName ?? 'They'} is typing…</div>}
        <div ref={bottomRef} />
      </div>
      <form className="composer" onSubmit={submit}>
        <input value={text} onChange={(e) => onChange(e.target.value)} maxLength={MAX_LEN}
               placeholder="Write a message…" aria-label="Message" />
        <button className="primary" disabled={!text.trim()}>Send</button>
      </form>
    </div>
  );
}

export function ChatPage() {
  const { connectionId } = useParams();
  const [search, setSearch] = useSearchParams();
  const navigate = useNavigate();
  const { connectionTick } = useRealtime();
  const [chats, setChats] = useState<ChatSummary[] | null>(null);

  const load = useCallback(() => {
    api.chats().then(setChats).catch(() => setChats([]));
  }, []);
  useEffect(load, [load, connectionTick]);

  // Last-message previews change as messages flow in; refresh the list when something new arrives.
  const { onMessage } = useRealtime();
  useEffect(() => onMessage(() => load()), [onMessage, load]);

  // /chat?with=<userId> (from the connections page) -> open that person's chat.
  const withUser = search.get('with');
  useEffect(() => {
    if (!withUser || !chats) return;
    const target = chats.find((c) => c.userId === withUser);
    setSearch({}, { replace: true });
    if (target) navigate(`/chat/${target.connectionId}`, { replace: true });
  }, [withUser, chats, navigate, setSearch]);

  if (!chats) return <p className="muted">Loading…</p>;
  const active = chats.find((c) => c.connectionId === connectionId);

  return (
    <div className="chat-layout">
      <aside className="chat-list">
        {chats.length === 0 && <p className="muted pad">No chats yet. Accept a request or get accepted to start one.</p>}
        {chats.map((c) => (
          <ChatRow key={c.connectionId} chat={c} active={c.connectionId === connectionId}
                   onOpen={() => navigate(`/chat/${c.connectionId}`)} />
        ))}
      </aside>
      <section className="chat-main">
        {active ? <Thread key={active.connectionId} chat={active} />
          : <p className="muted center pad">{connectionId ? 'This chat is not available.' : 'Select a chat'}</p>}
      </section>
    </div>
  );
}
