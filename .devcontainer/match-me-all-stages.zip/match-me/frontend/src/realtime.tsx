import { Client } from '@stomp/stompjs';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api, WS_URL } from './api';
import { useAuth } from './auth';
import type {
  ChatMessage, ConnectionEvent, PresenceEvent, ReadEvent, TypingEvent, UnreadEvent,
} from './types';

const TYPING_TIMEOUT_MS = 4000;

type Listener<T> = (event: T) => void;

interface RealtimeState {
  connected: boolean;
  online: ReadonlySet<string>;
  unread: Readonly<Record<string, number>>; // by connectionId
  totalUnread: number;
  typing: Readonly<Record<string, boolean>>; // by connectionId (the OTHER user typing)
  /** Bumps whenever a connection request/accept/disconnect event arrives; use as an effect dependency. */
  connectionTick: number;
  onMessage: (fn: Listener<ChatMessage>) => () => void;
  onRead: (fn: Listener<ReadEvent>) => () => void;
  sendMessage: (connectionId: string, content: string) => void;
  sendTyping: (connectionId: string, typing: boolean) => void;
  markRead: (connectionId: string) => void;
}

const RealtimeContext = createContext<RealtimeState | null>(null);

export function RealtimeProvider({ children }: { children: ReactNode }) {
  const { token } = useAuth();
  const clientRef = useRef<Client | null>(null);
  const messageListeners = useRef(new Set<Listener<ChatMessage>>());
  const readListeners = useRef(new Set<Listener<ReadEvent>>());
  const typingTimers = useRef(new Map<string, number>());

  const [connected, setConnected] = useState(false);
  const [online, setOnline] = useState<ReadonlySet<string>>(new Set());
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [totalUnread, setTotalUnread] = useState(0);
  const [typing, setTyping] = useState<Record<string, boolean>>({});
  const [connectionTick, setConnectionTick] = useState(0);

  useEffect(() => {
    if (!token) return;

    const loadUnread = () => api.chats().then((chats) => {
      setUnread(Object.fromEntries(chats.map((c) => [c.connectionId, c.unreadCount])));
      setTotalUnread(chats.reduce((sum, c) => sum + c.unreadCount, 0));
    }).catch(() => { /* will retry on next connect */ });

    const client = new Client({
      brokerURL: WS_URL,
      connectHeaders: { Authorization: `Bearer ${token}` },
      heartbeatIncoming: 10000,
      heartbeatOutgoing: 10000,
      reconnectDelay: 3000,
    });

    client.onConnect = () => {
      setConnected(true);
      const json = <T,>(fn: (e: T) => void) => (m: { body: string }) => fn(JSON.parse(m.body) as T);

      const applyPresence = (e: PresenceEvent) => {
        if (e.type === 'SNAPSHOT') setOnline(new Set(e.onlineUserIds));
        else setOnline((prev) => {
          const next = new Set(prev);
          if (e.online) next.add(e.userId); else next.delete(e.userId);
          return next;
        });
      };

      // The snapshot is answered directly to this subscription; later changes arrive as UPDATEs.
      client.subscribe('/user/queue/presence', json<PresenceEvent>(applyPresence));
      client.subscribe('/app/presence/snapshot', json<PresenceEvent>(applyPresence));

      client.subscribe('/user/queue/messages', json<ChatMessage>((m) => {
        messageListeners.current.forEach((fn) => fn(m));
      }));
      client.subscribe('/user/queue/unread', json<UnreadEvent>((e) => {
        setUnread((prev) => ({ ...prev, [e.connectionId]: e.unreadCount }));
        setTotalUnread(e.totalUnread);
      }));
      client.subscribe('/user/queue/read', json<ReadEvent>((e) => {
        readListeners.current.forEach((fn) => fn(e));
      }));
      client.subscribe('/user/queue/typing', json<TypingEvent>((e) => {
        const key = e.connectionId;
        window.clearTimeout(typingTimers.current.get(key));
        setTyping((prev) => ({ ...prev, [key]: e.typing }));
        if (e.typing) {
          // If the "stopped typing" frame is lost, do not show the indicator forever.
          typingTimers.current.set(key, window.setTimeout(
            () => setTyping((prev) => ({ ...prev, [key]: false })), TYPING_TIMEOUT_MS));
        }
      }));
      client.subscribe('/user/queue/connections', json<ConnectionEvent>(() => {
        setConnectionTick((n) => n + 1);
      }));
      client.subscribe('/user/queue/errors', (m) => console.warn('Server rejected a frame:', m.body));

      loadUnread(); // counters may have changed while we were disconnected
      setConnectionTick((n) => n + 1);
    };
    client.onWebSocketClose = () => setConnected(false);
    client.onStompError = (frame) => console.warn('STOMP error:', frame.headers['message']);

    clientRef.current = client;
    client.activate();

    const timers = typingTimers.current;
    return () => {
      timers.forEach((t) => window.clearTimeout(t));
      timers.clear();
      clientRef.current = null;
      setConnected(false);
      setOnline(new Set());
      setUnread({});
      setTotalUnread(0);
      setTyping({});
      void client.deactivate();
    };
  }, [token]);

  const publish = useCallback((destination: string, body?: unknown) => {
    const client = clientRef.current;
    if (!client?.connected) return;
    client.publish({
      destination,
      body: body === undefined ? '' : JSON.stringify(body),
      headers: { 'content-type': 'application/json' },
    });
  }, []);

  const value = useMemo<RealtimeState>(() => ({
    connected, online, unread, totalUnread, typing, connectionTick,
    onMessage: (fn) => { messageListeners.current.add(fn); return () => { messageListeners.current.delete(fn); }; },
    onRead: (fn) => { readListeners.current.add(fn); return () => { readListeners.current.delete(fn); }; },
    sendMessage: (id, content) => publish(`/app/chats/${id}/send`, { content }),
    sendTyping: (id, isTyping) => publish(`/app/chats/${id}/typing`, { typing: isTyping }),
    markRead: (id) => publish(`/app/chats/${id}/read`),
  }), [connected, online, unread, totalUnread, typing, connectionTick, publish]);

  return <RealtimeContext.Provider value={value}>{children}</RealtimeContext.Provider>;
}

export function useRealtime(): RealtimeState {
  const ctx = useContext(RealtimeContext);
  if (!ctx) throw new Error('useRealtime outside RealtimeProvider');
  return ctx;
}
