import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, setToken, setUnauthorizedHandler } from './api';
import type { Me } from './types';

const STORAGE_KEY = 'matchme.token';

function readStored(): string | null {
  try { return localStorage.getItem(STORAGE_KEY); } catch { return null; }
}
function writeStored(t: string | null) {
  try { if (t) localStorage.setItem(STORAGE_KEY, t); else localStorage.removeItem(STORAGE_KEY); } catch { /* storage unavailable */ }
}

interface AuthState {
  token: string | null;
  me: Me | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => void;
  refreshMe: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setTokenState] = useState<string | null>(() => {
    const t = readStored();
    setToken(t); // before any child effect fires its first request
    return t;
  });
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState<boolean>(token !== null);

  const logout = useCallback(() => {
    setToken(null);
    writeStored(null);
    setTokenState(null);
    setMe(null);
  }, []);

  useEffect(() => { setUnauthorizedHandler(logout); }, [logout]);

  useEffect(() => {
    if (!token) { setLoading(false); return; }
    let cancelled = false;
    setLoading(true);
    api.me().then((m) => { if (!cancelled) setMe(m); })
      .catch(() => { /* a 401 already logged us out */ })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [token]);

  const accept = useCallback((t: string) => {
    setToken(t);
    writeStored(t);
    setTokenState(t);
  }, []);

  const value = useMemo<AuthState>(() => ({
    token, me, loading,
    login: async (email, password) => accept((await api.login(email, password)).token),
    register: async (email, password) => accept((await api.register(email, password)).token),
    logout,
    refreshMe: async () => setMe(await api.me()),
  }), [token, me, loading, accept, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth outside AuthProvider');
  return ctx;
}
