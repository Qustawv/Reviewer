import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import { Layout } from './components/Layout';
import { RealtimeProvider } from './realtime';
import { AuthPage } from './pages/AuthPage';
import { ChatPage } from './pages/ChatPage';
import { ConnectionsPage } from './pages/ConnectionsPage';
import { ProfilePage } from './pages/ProfilePage';
import { RecommendationsPage } from './pages/RecommendationsPage';

export default function App() {
  const { token, loading } = useAuth();
  if (loading) return <p className="center muted">Loading…</p>;
  if (!token) return <AuthPage />;
  return (
    <RealtimeProvider>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/recommendations" element={<RecommendationsPage />} />
          <Route path="/connections" element={<ConnectionsPage />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/chat/:connectionId" element={<ChatPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="*" element={<Navigate to="/recommendations" replace />} />
        </Route>
      </Routes>
    </RealtimeProvider>
  );
}
