// Mirrors the backend DTOs. Enum values travel as plain strings.

export interface Me { id: string; email: string; displayName: string | null; profileImageUrl: string | null }
export interface PublicUser { id: string; displayName: string | null; profileImageUrl: string | null }
export interface ProfileText { id: string; aboutMe: string | null }
export interface Bio {
  id: string;
  studyArea: string | null;
  studyLevel: string | null;
  skills: string[];
  collaborationGoals: string[];
  availability: string[];
  workStyle: string | null;
  preferredLanguages: string[];
  city: string | null;
}
export interface Settings {
  profileComplete: boolean;
  latitude: number | null;
  longitude: number | null;
  maximumDistanceKm: number | null;
  priorityFields: string[];
}
export interface Lookups {
  skills: { code: string; label: string }[];
  collaborationGoals: string[];
  availabilitySlots: string[];
  studyAreas: string[];
  studyLevels: string[];
  workStyles: string[];
  preferredLanguages: string[];
  priorityFields: string[];
  maximumDistanceKmOptions: number[];
}
export interface ProfileUpdate {
  displayName: string;
  aboutMe: string;
  studyArea: string | null;
  studyLevel: string | null;
  skills: string[];
  collaborationGoals: string[];
  availability: string[];
  workStyle: string | null;
  preferredLanguages: string[];
  latitude: number | null;
  longitude: number | null;
  maximumDistanceKm: number | null;
  city: string;
  profileImageUrl: string;
  priorityFields: string[];
}
export interface ConnectionResponse { connectionId: string; userId: string; status: string }
export interface ChatSummary {
  connectionId: string;
  userId: string;
  unreadCount: number;
  lastMessage: string | null;
  lastMessageAt: string | null;
  lastSenderId: string | null;
}
export interface ChatMessage {
  id: string;
  connectionId: string;
  senderId: string;
  content: string;
  createdAt: string;
  readAt: string | null;
}
export interface MessagePage {
  messages: ChatMessage[];
  page: number;
  size: number;
  totalMessages: number;
  hasOlder: boolean;
}

// STOMP events (/user/queue/*)
export type PresenceEvent =
  | { type: 'SNAPSHOT'; onlineUserIds: string[] }
  | { type: 'UPDATE'; userId: string; online: boolean };
export interface TypingEvent { connectionId: string; userId: string; typing: boolean }
export interface UnreadEvent { connectionId: string; unreadCount: number; totalUnread: number }
export interface ReadEvent { connectionId: string; readerId: string }
export interface ConnectionEvent {
  type: 'REQUEST_RECEIVED' | 'REQUEST_ACCEPTED' | 'DISCONNECTED';
  userId: string;
  connectionId: string;
}
