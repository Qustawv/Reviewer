import type {
  Bio, ChatSummary, ConnectionResponse, Lookups, Me, MessagePage, ProfileText, ProfileUpdate,
  PublicUser, Settings,
} from './types';

export const API_URL: string = (import.meta.env.VITE_API_URL as string | undefined) ?? 'http://localhost:8080';

export class ApiError extends Error {
  constructor(public status: number, public code: string, public fields?: Record<string, string>) {
    super(code);
  }
}

let token: string | null = null;
let onUnauthorized: () => void = () => {};

export function setToken(t: string | null) { token = t; }
export function setUnauthorizedHandler(fn: () => void) { onUnauthorized = fn; }

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(API_URL + path, {
      method,
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'network_error');
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  const data = text ? JSON.parse(text) : undefined;
  if (!res.ok) {
    // A 401 on a protected call means the session is gone; login failures are handled by the caller.
    if (res.status === 401 && token) onUnauthorized();
    throw new ApiError(res.status, data?.error ?? 'error', data?.fields);
  }
  return data as T;
}

export const api = {
  register: (email: string, password: string) => request<{ token: string }>('POST', '/auth/register', { email, password }),
  login: (email: string, password: string) => request<{ token: string }>('POST', '/auth/login', { email, password }),
  lookups: () => request<Lookups>('GET', '/lookups'),

  me: () => request<Me>('GET', '/me'),
  myProfile: () => request<ProfileText>('GET', '/me/profile'),
  myBio: () => request<Bio>('GET', '/me/bio'),
  mySettings: () => request<Settings>('GET', '/me/settings'),
  updateProfile: (p: ProfileUpdate) => request<Settings>('PUT', '/me/profile', p),

  user: (id: string) => request<PublicUser>('GET', `/users/${id}`),
  userProfile: (id: string) => request<ProfileText>('GET', `/users/${id}/profile`),
  userBio: (id: string) => request<Bio>('GET', `/users/${id}/bio`),

  recommendations: () => request<string[]>('GET', '/recommendations'),
  dismiss: (id: string) => request<void>('POST', `/recommendations/${id}/dismiss`),

  connections: () => request<string[]>('GET', '/connections'),
  incoming: () => request<string[]>('GET', '/connections/requests/incoming'),
  outgoing: () => request<string[]>('GET', '/connections/requests/outgoing'),
  sendRequest: (id: string) => request<ConnectionResponse>('POST', `/connections/requests/${id}`),
  accept: (id: string) => request<ConnectionResponse>('POST', `/connections/requests/${id}/accept`),
  reject: (id: string) => request<ConnectionResponse>('POST', `/connections/requests/${id}/reject`),
  disconnect: (id: string) => request<void>('DELETE', `/connections/${id}`),

  chats: () => request<ChatSummary[]>('GET', '/chats'),
  messages: (connectionId: string, page: number, size = 30) =>
    request<MessagePage>('GET', `/chats/${connectionId}/messages?page=${page}&size=${size}`),
};

/** Ws(s) URL of the STOMP endpoint, derived from the REST base URL. */
export const WS_URL = API_URL.replace(/^http/, 'ws') + '/ws';
