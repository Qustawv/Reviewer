# Match-Me

Student recommendation and academic collaboration platform.
Monorepo: `backend/` (Java 17, Spring Boot 3.5, PostgreSQL, Flyway, JWT, STOMP) and `frontend/` (React + TypeScript + Vite).

## Status

| Stage | Scope | State |
|---|---|---|
| 1 | Backend scaffold: migrations V1-V5, entities, BCrypt + JWT auth, `/me*`, `/users/{id}*` with the 404 guard, profile completion gate | done |
| 2 | Recommendation engine, `GET /recommendations`, connection requests (send / accept / reject / disconnect), dismissals | done |
| 3 | Chat over STOMP `/ws`: messages, history, presence, typing, unread counters (no HTTP polling) | done |
| 4 | React + TypeScript frontend | done |

**What has and has not been run** (the package was built in a sandbox without access to Maven Central):

- Frontend: `npm run build` (typecheck + production build) and `npm run dev` were run, and the UI was driven in headless Chromium against a mocked API.
- SQL: migrations V1-V6 and every hand-written query (candidate pool, chat list, unread counts) were run on PostgreSQL 16 against seeded data.
- Recommendation engine, UUID ordering, presence registry and profile completion rules: unit tests were executed (with a stand-in test runner, not Maven).
- **Not run:** the Spring layer (controllers, services, security, WebSocket config) and the two Testcontainers integration tests. They are written and syntax-checked but have never been compiled against Spring or started. Run `./mvnw test` first; expect to fix a few compile or wiring errors.

## Run it

```bash
docker compose up -d                       # PostgreSQL 16 on :5432 (db/user/password: matchme)

cd backend
mvn wrapper:wrapper -Dmaven=3.9.11         # one-off: generates ./mvnw
SPRING_PROFILES_ACTIVE=dev ./mvnw spring-boot:run
./mvnw test                                # integration tests need Docker (Testcontainers); they skip without it

cd ../frontend
npm install
npm run dev                                # http://localhost:5173  (API URL: VITE_API_URL, default http://localhost:8080)
```

**Demo data (optional).** `seed-demo-data.sql` adds 5 users with complete profiles (password `demo1234!`; one in Tallinn, one in Keila, one in Rakvere, one in Tartu that is too far away, one Russian/Estonian-speaking that only matches if you also pick one of those languages). Load it after the backend has started once (Flyway has created the tables by then):

```powershell
docker compose cp seed-demo-data.sql db:/tmp/seed.sql
docker compose exec db psql -U matchme -d matchme -f /tmp/seed.sql
```

Without the `dev` profile, set `JWT_SECRET` (>= 32 bytes); the app refuses to start with a missing/weak secret.

## REST API

| Method & path | Response |
|---|---|
| `POST /auth/register` `{email, password}` (no auth) | `201 {token}` |
| `POST /auth/login` `{email, password}` (no auth) | `{token}` |
| `GET /me` | `{id, email, displayName, profileImageUrl}` (the only payload with `email`) |
| `GET /me/profile` | `{id, aboutMe}` |
| `GET /me/bio` | `{id, studyArea, studyLevel, skills, collaborationGoals, availability, workStyle, preferredLanguages, city}` |
| `GET /me/settings` | `{profileComplete, latitude, longitude, maximumDistanceKm, priorityFields}` (owner only) |
| `PUT /me/profile` | full replace of the editable profile; returns the settings with the recomputed `profileComplete` |
| `GET /users/{id}`, `/users/{id}/profile`, `/users/{id}/bio` | same shapes, for a visible user; otherwise **404** |
| `GET /recommendations` | `["uuid", ...]`, at most 10; **403** `{"error":"profile_incomplete"}` until the profile is complete |
| `POST /recommendations/{id}/dismiss` | `204`; the user is never recommended again |
| `GET /connections` | `["uuid", ...]` (ACCEPTED only) |
| `GET /connections/requests/incoming`, `/outgoing` | `["uuid", ...]` (PENDING only) |
| `POST /connections/requests/{id}` | `201 {connectionId, userId, status}`; target must be in your active recommendations; **409** if a row already exists |
| `POST /connections/requests/{id}/accept`, `/reject` | addressee only; accept opens the chat |
| `DELETE /connections/{id}` | `204`; ends an ACCEPTED connection |
| `GET /chats` | `[{connectionId, userId, unreadCount, lastMessage, lastMessageAt, lastSenderId}]` |
| `GET /chats/{connectionId}/messages?page=0&size=50` | `{messages, page, size, totalMessages, hasOlder}`; page 0 = newest, each page oldest-first; non-participant **404** |
| `GET /lookups` | fixed option lists for the profile form |

`/me/settings`, `PUT /me/profile`, `/lookups`, the request/dismiss/chat endpoints and `/connections/requests/*` go beyond the contract list; the UI needs them.

## WebSocket protocol (STOMP over `/ws`)

Connect with the STOMP header `Authorization: Bearer <jwt>` (a bad or missing token is refused). Heartbeats 10 s / 10 s.

| Direction | Destination | Payload |
|---|---|---|
| subscribe | `/app/presence/snapshot` | one reply: `{type:"SNAPSHOT", onlineUserIds}` for your connections |
| subscribe | `/user/queue/presence` | `{type:"UPDATE", userId, online}` |
| subscribe | `/user/queue/messages` | `{id, connectionId, senderId, content, createdAt, readAt}` (also echoed to the sender) |
| subscribe | `/user/queue/unread` | `{connectionId, unreadCount, totalUnread}` |
| subscribe | `/user/queue/read` | `{connectionId, readerId}`: the other side read your messages |
| subscribe | `/user/queue/typing` | `{connectionId, userId, typing}` |
| subscribe | `/user/queue/connections` | `{type: REQUEST_RECEIVED \| REQUEST_ACCEPTED \| DISCONNECTED, userId, connectionId}` |
| subscribe | `/user/queue/errors` | `{code: not_found \| validation_failed \| error}` (only to the sender of the bad frame) |
| send | `/app/chats/{connectionId}/send` | `{content}` (1-2000 chars after trim) |
| send | `/app/chats/{connectionId}/typing` | `{typing: true\|false}` |
| send | `/app/chats/{connectionId}/read` | empty |

Clients may only subscribe to `/user/queue/**` and `/app/presence/snapshot`, and only send to `/app/**`, so nobody can forge events into another user's queue.

## Design notes and assumptions

- **404 guard.** `/users/{id}*` returns the identical 404 for "no such user", "not allowed" and a malformed id. Visible = yourself, a PENDING/ACCEPTED connection, or a user in your active recommendations. Chats use the same rule: a stranger gets the same 404 as for a chat that does not exist.
- **Recommendations.** Hard filters (complete profile, at least one shared preferred language, shared goal, overlapping availability, within the smaller of both max distances, no existing relationship, not dismissed), then a 100-point score. Cut-off 60; top 3 stay pinned, ranks 4-20 are shuffled, at most 10 ids are returned. Ties: score, then distance, then recently updated, then id. The engine is a pure class (`RecommendationEngine`) with its own unit tests.
- **Interpretations you may want to change** (all in `RecommendationEngine`): work styles are compatible when either is FLEXIBLE or the pair is STRUCTURED/INDEPENDENT_WITH_CHECK_INS; SOFTWARE_DEVELOPMENT and WEB_DEVELOPMENT count as related study areas; a priority field "matches" when the candidate earns at least half of that dimension's points.
- **Active recommendations** are kept in memory per user (24 h, `matchme.recommendations.active-ttl-minutes`) and cleared when the profile changes. Consequence: they are lost on restart and not shared between server instances; use a shared store (Redis, or a table) before running more than one instance.
- **Languages.** A profile lists 1-4 preferred languages (`preferredLanguages`, stored in `profile_languages`; migration V6 carried over the old single value). Two people can be matched only if they share at least one; languages do not add to the score.
- **One row per pair, forever.** `connections` keeps rejected and disconnected pairs, so they are never recommended again and cannot re-request.
- **UUID ordering.** `connections` stores the lower id as `user_one_id`. PostgreSQL orders UUIDs as unsigned bytes but `java.util.UUID.compareTo` is signed; `UuidUtil.compareUnsigned` matches PostgreSQL.
- **Completion gate.** `profileComplete` is recomputed on every `PUT /me/profile` and never accepted from the client.
- **Availability slots.** The spec says "1-14 slots: weekday/weekend x morning/afternoon/evening", which is 6 distinct slots. The lookup table has those 6; the 14 limit stays as stated but cannot be reached.
- **Chats** may only reference ACCEPTED connections (a DB trigger enforces it). After a disconnect, sending and typing are refused, the chat disappears from `GET /chats`, and the history stays readable to both participants by connection id.
- **Frontend token storage.** The JWT is kept in `localStorage`; fine for a course project, but a production app would prefer an httpOnly cookie.
